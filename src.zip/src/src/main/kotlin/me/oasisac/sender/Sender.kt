package me.oasisac.sender

import java.util.UUID
import net.kyori.adventure.text.Component
import org.bukkit.command.CommandSender
import org.bukkit.entity.Player

interface Sender {
  companion object {
    @JvmField val CONSOLE_UUID: UUID = UUID(0L, 0L)
    @JvmField val CONSOLE_NAME: String = "Console"
  }

  val name: String

  val uniqueId: UUID

  fun sendMessage(message: String)

  fun sendMessage(message: Component)

  fun hasPermission(permission: String): Boolean

  val isConsole: Boolean

  val isPlayer: Boolean

  val nativeSender: CommandSender

  val player: Player?
}
