package me.oasisac.sender

import java.util.UUID
import me.oasisac.utils.MessageUtil
import net.kyori.adventure.platform.bukkit.BukkitAudiences
import net.kyori.adventure.text.Component
import org.bukkit.command.CommandSender
import org.bukkit.entity.Player
import org.incendo.cloud.SenderMapper

class SenderFactory(private val adventure: BukkitAudiences) : SenderMapper<CommandSender, Sender> {
  override fun map(base: CommandSender): Sender {
    return if (base is Player) {
      PlayerSender(base, adventure)
    } else {
      ConsoleSender(base, adventure)
    }
  }

  override fun reverse(mapped: Sender): CommandSender {
    return mapped.nativeSender
  }

  private class PlayerSender(
    private val bukkitPlayer: Player,
    private val adventure: BukkitAudiences,
  ) : Sender {
    override val name: String
      get() = bukkitPlayer.name

    override val uniqueId: UUID
      get() = bukkitPlayer.uniqueId

    override fun sendMessage(message: String) {
      adventure.player(bukkitPlayer).sendMessage(MessageUtil.deserializeRaw(message))
    }

    override fun sendMessage(message: Component) {
      adventure.player(bukkitPlayer).sendMessage(message)
    }

    override fun hasPermission(permission: String): Boolean = bukkitPlayer.hasPermission(permission)

    override val isConsole: Boolean
      get() = false

    override val isPlayer: Boolean
      get() = true

    override val nativeSender: CommandSender
      get() = bukkitPlayer

    override val player: Player
      get() = bukkitPlayer
  }

  private class ConsoleSender(
    private val sender: CommandSender,
    private val adventure: BukkitAudiences,
  ) : Sender {
    override val name: String
      get() = Sender.CONSOLE_NAME

    override val uniqueId: UUID
      get() = Sender.CONSOLE_UUID

    override fun sendMessage(message: String) {
      adventure.sender(sender).sendMessage(MessageUtil.deserializeRaw(message))
    }

    override fun sendMessage(message: Component) {
      adventure.sender(sender).sendMessage(message)
    }

    override fun hasPermission(permission: String): Boolean = sender.hasPermission(permission)

    override val isConsole: Boolean
      get() = true

    override val isPlayer: Boolean
      get() = false

    override val nativeSender: CommandSender
      get() = sender

    override val player: Player? = null
  }
}
