package me.oasisac.ai

import java.nio.ByteBuffer
import me.oasisac.data.TickData

interface AiSerializer {
  fun serialize(ticks: Array<TickData>, count: Int): ByteBuffer
}
