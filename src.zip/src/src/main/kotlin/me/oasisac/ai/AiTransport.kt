package me.oasisac.ai

import java.nio.ByteBuffer
import java.util.concurrent.CompletableFuture

interface AiTransport {
  fun send(payload: ByteBuffer): CompletableFuture<String>
}
