package me.oasisac.ai

class AiServiceException(cause: Throwable, val newSequence: Int?) :
  RuntimeException(cause.message, cause)
