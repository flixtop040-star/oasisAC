package me.oasisac.ai

import me.oasisac.server.AIServer

object InferenceRetryPolicy {
  fun shouldRetry(throwable: Throwable): Boolean {
    if (throwable !is AIServer.RequestException) return false
    return when (throwable.code) {
      AIServer.ResponseCode.TIMEOUT,
      AIServer.ResponseCode.NETWORK_ERROR,
      AIServer.ResponseCode.SERVER_ERROR,
      AIServer.ResponseCode.SERVICE_UNAVAILABLE,
      AIServer.ResponseCode.RATE_LIMITED -> true
      else -> false
    }
  }
}
