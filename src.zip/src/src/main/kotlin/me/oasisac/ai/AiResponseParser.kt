package me.oasisac.ai

import me.oasisac.server.AIResponse

interface AiResponseParser {
  fun parse(response: String): AIResponse
}
