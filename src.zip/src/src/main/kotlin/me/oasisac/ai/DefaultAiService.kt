package me.oasisac.ai

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import java.nio.ByteBuffer
import java.util.concurrent.CompletableFuture
import me.oasisac.data.TickData
import me.oasisac.server.AIServer
import me.oasisac.server.AIServerProvider

class DefaultAiService(
  private val transportProvider: AIServerProvider,
  private val serializer: AiSerializer,
  private val parser: AiResponseParser,
) : AiService {
  override val isEnabled: Boolean
    get() = transportProvider.get() != null

  override fun request(ticks: Array<TickData>, count: Int): CompletableFuture<AiResult> {
    val transport: AiTransport =
      transportProvider.get() ?: return CompletableFuture.completedFuture(AiResult.disabledResult())

    val payload: ByteBuffer = serializer.serialize(ticks, count)
    return transport.send(payload).thenApply(this::parse).exceptionallyCompose(this::handleError)
  }

  private fun parse(raw: String): AiResult {
    return try {
      AiResult(parser.parse(raw), raw, null, false)
    } catch (e: Exception) {
      AiResult(null, raw, e, false)
    }
  }

  private fun handleError(error: Throwable): CompletableFuture<AiResult> {
    val cause =
      if (error is java.util.concurrent.CompletionException && error.cause != null) {
        error.cause!!
      } else {
        error
      }

    if (
      cause is AIServer.RequestException && cause.code == AIServer.ResponseCode.INVALID_SEQUENCE
    ) {
      val sequence = parseSequence(cause.responseBody)
      if (sequence != null) {
        return CompletableFuture.failedFuture(AiServiceException(cause, sequence))
      }
    }

    return CompletableFuture.failedFuture(cause)
  }

  internal fun parseSequence(body: String?): Int? {
    if (body.isNullOrBlank()) return null
    return runCatching { OBJECT_MAPPER.readTree(body) }
      .getOrNull()
      ?.get("details")
      ?.takeIf { it.isObject }
      ?.let { details -> parseSequenceNode(details.get("expected_sequence")) }
  }

  private fun parseSequenceNode(sequence: JsonNode?): Int? {
    if (sequence == null) return null
    return when {
      sequence.isInt -> sequence.intValue()
      sequence.isLong -> sequence.longValue().toInt()
      sequence.isTextual -> sequence.textValue().toIntOrNull()
      else -> null
    }
  }

  companion object {
    private val OBJECT_MAPPER = ObjectMapper()
  }
}
