package me.oasisac.ai

import com.google.flatbuffers.FlatBufferBuilder
import java.nio.ByteBuffer
import me.oasisac.data.TickData
import me.oasisac.flatbuffers.TickDataSequence

class FlatBuffersAiSerializer : AiSerializer {
  override fun serialize(ticks: Array<TickData>, count: Int): ByteBuffer {
    val builder = BUILDER.get()
    builder.clear()

    var tickOffsets = OFFSETS_BUFFER.get()
    if (tickOffsets.size != count) {
      tickOffsets = IntArray(count)
      OFFSETS_BUFFER.set(tickOffsets)
    }

    for (i in count - 1 downTo 0) {
      val tick = ticks[i]
      me.oasisac.flatbuffers.TickData.startTickData(builder)
      me.oasisac.flatbuffers.TickData.addDeltaYaw(builder, tick.deltaYaw)
      me.oasisac.flatbuffers.TickData.addDeltaPitch(builder, tick.deltaPitch)
      me.oasisac.flatbuffers.TickData.addAccelYaw(builder, tick.accelYaw)
      me.oasisac.flatbuffers.TickData.addAccelPitch(builder, tick.accelPitch)
      me.oasisac.flatbuffers.TickData.addJerkYaw(builder, tick.jerkYaw)
      me.oasisac.flatbuffers.TickData.addJerkPitch(builder, tick.jerkPitch)
      me.oasisac.flatbuffers.TickData.addGcdErrorYaw(builder, tick.gcdErrorYaw)
      me.oasisac.flatbuffers.TickData.addGcdErrorPitch(builder, tick.gcdErrorPitch)
      tickOffsets[i] = me.oasisac.flatbuffers.TickData.endTickData(builder)
    }

    val ticksVector = TickDataSequence.createTicksVector(builder, tickOffsets)

    TickDataSequence.startTickDataSequence(builder)
    TickDataSequence.addTicks(builder, ticksVector)
    val sequenceOffset = TickDataSequence.endTickDataSequence(builder)
    builder.finish(sequenceOffset)

    val playerUuid = if (count > 0) ticks[0].playerUuid else ""
    val playerName = if (count > 0) ticks[0].playerName else ""

    val uuidBytes = playerUuid.toByteArray(Charsets.UTF_8)
    val nameBytes = playerName.toByteArray(Charsets.UTF_8)
    val fbBytes = builder.sizedByteArray()

    val totalSize = 1 + uuidBytes.size + 1 + nameBytes.size + fbBytes.size
    val outBuffer = ByteBuffer.allocate(totalSize)
    outBuffer.put(uuidBytes.size.toByte())
    outBuffer.put(uuidBytes)
    outBuffer.put(nameBytes.size.toByte())
    outBuffer.put(nameBytes)
    outBuffer.put(fbBytes)
    outBuffer.flip()

    return outBuffer
  }

  companion object {
    private val BUILDER: ThreadLocal<FlatBufferBuilder> =
      ThreadLocal.withInitial { FlatBufferBuilder(4096) }
    private val OFFSETS_BUFFER: ThreadLocal<IntArray> = ThreadLocal.withInitial { IntArray(0) }
  }
}
