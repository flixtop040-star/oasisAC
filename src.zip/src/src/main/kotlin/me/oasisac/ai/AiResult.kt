package me.oasisac.ai

import me.oasisac.server.AIResponse

data class AiResult(
  val response: AIResponse?,
  val raw: String,
  val parseError: Throwable?,
  val disabled: Boolean,
) {
  fun hasParseError(): Boolean = parseError != null

  companion object {
    @JvmStatic fun disabledResult(): AiResult = AiResult(null, "", null, true)
  }
}
