package me.oasisac.ai

import java.nio.ByteBuffer

internal fun ByteBuffer.snapshot(): ByteArray {
  if (hasArray()) {
    val from = arrayOffset() + position()
    return array().copyOfRange(from, from + remaining())
  }
  val out = ByteArray(remaining())
  duplicate().get(out)
  return out
}
