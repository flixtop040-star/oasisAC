package me.oasisac.ai

import java.util.concurrent.CompletableFuture
import me.oasisac.data.TickData

interface AiService {
  val isEnabled: Boolean

  fun request(ticks: Array<TickData>, count: Int): CompletableFuture<AiResult>
}
