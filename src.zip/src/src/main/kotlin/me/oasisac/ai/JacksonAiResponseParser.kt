package me.oasisac.ai

import com.fasterxml.jackson.databind.ObjectMapper
import me.oasisac.server.AIResponse

class JacksonAiResponseParser : AiResponseParser {
  override fun parse(response: String): AIResponse {
    val node = OBJECT_MAPPER.readTree(response).get("probability")
    val probability =
      when {
        node == null || node.isNull -> null
        node.isNumber -> node.doubleValue()
        node.isTextual -> node.textValue().toDoubleOrNull()
        else -> null
      } ?: throw IllegalArgumentException("AI response does not contain a valid probability")
    return AIResponse(probability)
  }

  companion object {
    private val OBJECT_MAPPER = ObjectMapper()
  }
}
