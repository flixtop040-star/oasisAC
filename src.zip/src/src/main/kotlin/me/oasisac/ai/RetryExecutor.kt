package me.oasisac.ai

import java.util.concurrent.CompletableFuture
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random
import me.oasisac.scheduler.SchedulerService

class RetryExecutor(private val scheduler: SchedulerService, private val config: RetryConfig) {
  fun <T> execute(
    operation: () -> CompletableFuture<T>,
    shouldRetry: (Throwable) -> Boolean,
  ): CompletableFuture<T> {
    val result = CompletableFuture<T>()
    attempt(1, operation, shouldRetry, result)
    return result
  }

  private fun <T> attempt(
    attemptNum: Int,
    operation: () -> CompletableFuture<T>,
    shouldRetry: (Throwable) -> Boolean,
    result: CompletableFuture<T>,
  ) {
    operation().whenComplete { value, throwable ->
      if (throwable == null) {
        result.complete(value)
        return@whenComplete
      }
      val cause = unwrap(throwable)
      if (attemptNum >= config.maxAttempts || !shouldRetry(cause)) {
        result.completeExceptionally(cause)
        return@whenComplete
      }
      val delayMs = computeDelayMs(attemptNum).coerceAtLeast(0L)
      scheduler.runLaterAsync({ attempt(attemptNum + 1, operation, shouldRetry, result) }, delayMs)
    }
  }

  private fun computeDelayMs(attemptNum: Int): Long {
    val base = (config.initialDelayMs.toDouble() * config.multiplier.pow(attemptNum - 1)).toLong()
    val capped = min(base, config.maxDelayMs)
    if (config.jitter <= 0.0) return capped
    val jitterRange = (capped * config.jitter).toLong().coerceAtLeast(1L)
    return (capped + Random.nextLong(-jitterRange, jitterRange + 1)).coerceAtLeast(0L)
  }

  private fun unwrap(throwable: Throwable): Throwable {
    return if (throwable is java.util.concurrent.CompletionException && throwable.cause != null) {
      throwable.cause!!
    } else {
      throwable
    }
  }

  data class RetryConfig(
    val maxAttempts: Int,
    val initialDelayMs: Long,
    val maxDelayMs: Long,
    val multiplier: Double,
    val jitter: Double,
  )
}
