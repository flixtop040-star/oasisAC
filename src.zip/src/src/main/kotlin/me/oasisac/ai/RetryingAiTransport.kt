package me.oasisac.ai

import java.nio.ByteBuffer
import java.util.concurrent.CompletableFuture

class RetryingAiTransport(
  private val delegate: AiTransport,
  private val retryExecutor: RetryExecutor,
) : AiTransport {
  override fun send(payload: ByteBuffer): CompletableFuture<String> {
    val snapshot = payload.snapshot()
    return retryExecutor.execute(
      operation = { delegate.send(ByteBuffer.wrap(snapshot)) },
      shouldRetry = InferenceRetryPolicy::shouldRetry,
    )
  }
}

class RetryingAiBatchTransport(
  private val delegate: AiBatchTransport,
  private val retryExecutor: RetryExecutor,
) : AiBatchTransport {
  override fun sendBatch(items: List<ByteArray>): CompletableFuture<String> {
    return retryExecutor.execute(
      operation = { delegate.sendBatch(items) },
      shouldRetry = InferenceRetryPolicy::shouldRetry,
    )
  }
}
