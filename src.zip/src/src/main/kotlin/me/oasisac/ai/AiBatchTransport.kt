package me.oasisac.ai

import java.util.concurrent.CompletableFuture

interface AiBatchTransport {
  fun sendBatch(items: List<ByteArray>): CompletableFuture<String>
}
