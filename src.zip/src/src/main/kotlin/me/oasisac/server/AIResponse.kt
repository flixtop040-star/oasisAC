package me.oasisac.server

data class AIResponse(val probability: Double)
