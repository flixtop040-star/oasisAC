package me.oasisac.server

import java.util.concurrent.atomic.AtomicLong

class ApiCooldown(initialDurationSeconds: Long, maxDurationSeconds: Long, multiplier: Double) {
  private val nextAttempt: AtomicLong = AtomicLong(0)
  private val currentBackoff: AtomicLong

  private val initialDuration: Long
  private val maxDuration: Long
  private val multiplier: Double

  init {
    initialDuration = initialDurationSeconds * 1000
    maxDuration = maxDurationSeconds * 1000
    this.multiplier = multiplier
    currentBackoff = AtomicLong(initialDuration)
  }

  fun isWaiting(): Boolean = System.currentTimeMillis() < nextAttempt.get()

  fun recordSuccess() {
    currentBackoff.set(initialDuration)
    nextAttempt.set(0)
  }

  fun recordFailure() {
    val currentDuration = currentBackoff.get()
    nextAttempt.set(System.currentTimeMillis() + currentDuration)

    val newDuration = (currentDuration * multiplier).toLong()
    currentBackoff.set(kotlin.math.min(newDuration, maxDuration))
  }
}
