package me.oasisac.event

import me.oasisac.player.PlayerDataManager
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.EventPriority
import org.bukkit.event.Listener
import org.bukkit.event.entity.EntityDamageByEntityEvent

class DamageEvent(private val playerDataManager: PlayerDataManager) : Listener {
  @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
  fun onEntityDamageByEntity(event: EntityDamageByEntityEvent) {
    val damager = event.damager
    if (damager !is Player) {
      return
    }
    val oasisacPlayer = playerDataManager.getPlayer(damager) ?: return
    val multiplier = oasisacPlayer.combat.damageMultiplier
    if (multiplier < 1.0) {
      event.damage = event.damage * multiplier
    }
  }
}
