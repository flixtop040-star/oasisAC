package me.oasisac.api.event

/** Base marker for Oasis events posted through [OasisEventBus]. */
interface OasisEvent

/** Marker for events that can be cancelled by listeners. */
interface OasisCancellableEvent : OasisEvent {
  var cancelled: Boolean
}
