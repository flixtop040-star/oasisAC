package me.oasisac.api

import me.oasisac.api.event.OasisEventBus
import me.oasisac.api.service.AiApi
import me.oasisac.api.service.CheckApi
import me.oasisac.api.service.MonitorApi
import me.oasisac.api.service.PunishmentApi

/**
 * Public API surface for OasisAC.
 *
 * Obtain an instance via [me.oasisac.api.OasisApiProvider.get].
 */
interface OasisApi {
  /** AI-related data access and status. */
  fun ai(): AiApi

  /** Check metadata and per-player check listing. */
  fun checks(): CheckApi

  /** Violation and punishment accessors. */
  fun punishments(): PunishmentApi

  /** Current monitor snapshot data (probability/buffer/ping/dmg). */
  fun monitor(): MonitorApi

  /** Oasis event bus for subscribing to internal events. */
  fun events(): OasisEventBus
}
