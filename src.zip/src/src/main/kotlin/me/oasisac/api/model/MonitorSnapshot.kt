package me.oasisac.api.model

/** Snapshot used by monitor UI and external integrations. */
data class MonitorSnapshot(
  val probability: Double,
  val buffer: Double,
  val ping: Int,
  val damageMultiplier: Double,
  val prob90: Int,
)
