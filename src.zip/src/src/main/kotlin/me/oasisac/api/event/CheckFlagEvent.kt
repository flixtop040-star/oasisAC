package me.oasisac.api.event

import java.util.UUID

/**
 * Fired when a check flags a player.
 *
 * This event is dispatched on the calling thread.
 */
data class CheckFlagEvent(
  val playerId: UUID,
  val playerName: String,
  val checkName: String,
  val configName: String,
  val debug: String,
  override var cancelled: Boolean = false,
) : OasisCancellableEvent
