package me.oasisac.api.model

/** Snapshot of the latest AI prediction values for a player. */
data class AiSnapshot(
  val probability: Double,
  val buffer: Double,
  val damageMultiplier: Double,
  val prob90: Int,
)
