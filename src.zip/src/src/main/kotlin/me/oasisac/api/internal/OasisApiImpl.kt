package me.oasisac.api.internal

import me.oasisac.api.OasisApi
import me.oasisac.api.event.OasisEventBus
import me.oasisac.api.service.AiApi
import me.oasisac.api.service.CheckApi
import me.oasisac.api.service.MonitorApi
import me.oasisac.api.service.PunishmentApi

class OasisApiImpl(
  private val aiApi: AiApi,
  private val checkApi: CheckApi,
  private val punishmentApi: PunishmentApi,
  private val monitorApi: MonitorApi,
  private val eventBus: OasisEventBus,
) : OasisApi {
  override fun ai(): AiApi = aiApi

  override fun checks(): CheckApi = checkApi

  override fun punishments(): PunishmentApi = punishmentApi

  override fun monitor(): MonitorApi = monitorApi

  override fun events(): OasisEventBus = eventBus
}
