package me.oasisac.api.internal

import java.util.Optional
import java.util.UUID
import me.oasisac.api.model.MonitorSnapshot
import me.oasisac.api.service.MonitorApi
import me.oasisac.checks.impl.ai.AiCheck
import me.oasisac.player.PlayerDataManager

class MonitorApiImpl(private val playerDataManager: PlayerDataManager) : MonitorApi {
  override fun getSnapshot(playerId: UUID): Optional<MonitorSnapshot> {
    val oasisacPlayer = playerDataManager.getPlayer(playerId) ?: return Optional.empty()
    val aiCheck =
      oasisacPlayer.checkManager.getCheck(AiCheck::class.java) ?: return Optional.empty()
    val ping = oasisacPlayer.player.ping
    return Optional.of(
      MonitorSnapshot(
        aiCheck.lastProbability,
        aiCheck.buffer,
        ping,
        oasisacPlayer.combat.damageMultiplier,
        aiCheck.prob90,
      )
    )
  }
}
