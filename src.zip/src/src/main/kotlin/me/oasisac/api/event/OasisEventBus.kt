package me.oasisac.api.event

/** Functional listener for [OasisEventBus] subscriptions. */
fun interface OasisEventListener<T : OasisEvent> {
  fun handle(event: T)
}

/**
 * Lightweight event bus for OasisAC events.
 *
 * Events are dispatched on the thread that calls [post].
 */
interface OasisEventBus {
  /** Post an event to all registered listeners. */
  fun post(event: OasisEvent)

  /** Subscribe with default priority (0) and ignoreCancelled=false. */
  fun <T : OasisEvent> subscribe(
    pluginContext: Any,
    eventType: Class<T>,
    listener: OasisEventListener<T>,
  )

  /** Subscribe with explicit priority and ignoreCancelled. */
  fun <T : OasisEvent> subscribe(
    pluginContext: Any,
    eventType: Class<T>,
    listener: OasisEventListener<T>,
    priority: Int,
    ignoreCancelled: Boolean,
  )

  /** Unregister a specific listener for a context. */
  fun unregisterListener(pluginContext: Any, listener: OasisEventListener<*>)

  /** Unregister all listeners for a context. */
  fun unregisterAll(pluginContext: Any)
}
