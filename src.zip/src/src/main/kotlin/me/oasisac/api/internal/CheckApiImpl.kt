package me.oasisac.api.internal

import java.util.Locale
import java.util.Optional
import java.util.UUID
import kotlinx.collections.immutable.ImmutableList
import kotlinx.collections.immutable.persistentListOf
import me.oasisac.api.model.CheckInfo
import me.oasisac.api.service.CheckApi
import me.oasisac.checks.AbstractCheck
import me.oasisac.checks.ICheck
import me.oasisac.player.PlayerDataManager

class CheckApiImpl(private val playerDataManager: PlayerDataManager) : CheckApi {
  override fun listChecks(playerId: UUID): ImmutableList<CheckInfo> {
    val player = playerDataManager.getPlayer(playerId) ?: return persistentListOf()
    val builder = persistentListOf<CheckInfo>().builder()
    for (check in player.checkManager.getAllChecks()) {
      builder.add(toInfo(check))
    }
    return builder.build()
  }

  override fun getCheck(playerId: UUID, checkName: String): Optional<CheckInfo> {
    if (checkName.isBlank()) {
      return Optional.empty()
    }
    val player = playerDataManager.getPlayer(playerId) ?: return Optional.empty()
    val needle = checkName.trim().lowercase(Locale.ROOT)
    for (check in player.checkManager.getAllChecks()) {
      val info = toInfo(check)
      if (info.name.lowercase(Locale.ROOT) == needle) {
        return Optional.of(info)
      }
      if (info.configName != null && info.configName.lowercase(Locale.ROOT) == needle) {
        return Optional.of(info)
      }
    }
    return Optional.empty()
  }

  private fun toInfo(check: ICheck): CheckInfo {
    val configName =
      if (check is AbstractCheck) {
        check.configName
      } else {
        null
      }
    return CheckInfo(check.checkName, configName)
  }
}
