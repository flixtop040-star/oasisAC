package me.oasisac.api.model

/** Lightweight check metadata for external integrations. */
data class CheckInfo(val name: String, val configName: String?)
