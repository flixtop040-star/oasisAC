package me.oasisac.api.event

import java.util.UUID

/**
 * Fired after an AI prediction is processed for a player.
 *
 * This event is dispatched on the calling thread.
 */
data class AiPredictionEvent(
  val playerId: UUID,
  val playerName: String,
  val checkName: String,
  val probability: Double,
  val bufferBefore: Double,
  val bufferAfter: Double,
  val damageMultiplier: Double,
  val prob90: Int,
  val flagged: Boolean,
) : OasisEvent
