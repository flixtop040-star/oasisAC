package me.oasisac.api.event

import java.util.UUID
import kotlinx.collections.immutable.ImmutableList

/**
 * Fired when a punish group actions set is selected for a player.
 *
 * This event is dispatched on the calling thread.
 */
data class PunishmentTriggeredEvent(
  val playerId: UUID,
  val playerName: String,
  val checkName: String,
  val groupName: String,
  val violationLevel: Int,
  val actions: ImmutableList<String>,
  val debug: String,
  override var cancelled: Boolean = false,
) : OasisCancellableEvent
