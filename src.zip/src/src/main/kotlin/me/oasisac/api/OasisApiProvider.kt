package me.oasisac.api

import java.util.Optional
import org.bukkit.Bukkit
import org.bukkit.plugin.RegisteredServiceProvider

/** Service loader for [OasisApi] via Bukkit ServicesManager. */
object OasisApiProvider {
  /**
   * Returns the Oasis API instance if OasisAC is present and registered.
   *
   * @return optional OasisApi
   */
  @JvmStatic
  fun get(): Optional<OasisApi> {
    val provider: RegisteredServiceProvider<OasisApi>? =
      Bukkit.getServicesManager().getRegistration(OasisApi::class.java)
    return if (provider == null) {
      Optional.empty()
    } else {
      Optional.ofNullable(provider.provider)
    }
  }
}
