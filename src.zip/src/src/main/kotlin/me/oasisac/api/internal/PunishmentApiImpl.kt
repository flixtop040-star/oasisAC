package me.oasisac.api.internal

import java.util.UUID
import java.util.concurrent.CompletableFuture
import me.oasisac.api.service.PunishmentApi
import me.oasisac.database.DatabaseManager
import me.oasisac.database.ViolationDatabase
import me.oasisac.scheduler.SchedulerService

class PunishmentApiImpl(databaseManager: DatabaseManager, private val scheduler: SchedulerService) :
  PunishmentApi {
  private val database: ViolationDatabase = databaseManager.database

  override fun getViolationLevel(playerId: UUID, groupName: String): CompletableFuture<Int> {
    if (groupName.isBlank()) {
      return CompletableFuture.completedFuture(0)
    }
    val future = CompletableFuture<Int>()
    scheduler.runAsync {
      try {
        future.complete(database.getViolationLevel(playerId, groupName))
      } catch (e: Exception) {
        future.completeExceptionally(e)
      }
    }
    return future
  }

  override fun resetViolationLevel(playerId: UUID, groupName: String): CompletableFuture<Void> {
    if (groupName.isBlank()) {
      return CompletableFuture.completedFuture(null)
    }
    val future = CompletableFuture<Void>()
    scheduler.runAsync {
      try {
        database.resetViolationLevel(playerId, groupName)
        future.complete(null)
      } catch (e: Exception) {
        future.completeExceptionally(e)
      }
    }
    return future
  }
}
