package me.oasisac.api.internal

import java.util.Optional
import java.util.UUID
import me.oasisac.ai.AiService
import me.oasisac.api.model.AiSnapshot
import me.oasisac.api.service.AiApi
import me.oasisac.checks.impl.ai.AiCheck
import me.oasisac.player.PlayerDataManager

class AiApiImpl(
  private val aiService: AiService,
  private val playerDataManager: PlayerDataManager,
) : AiApi {
  override fun isEnabled(): Boolean = aiService.isEnabled

  override fun getSnapshot(playerId: UUID): Optional<AiSnapshot> {
    val oasisacPlayer = playerDataManager.getPlayer(playerId) ?: return Optional.empty()
    val aiCheck =
      oasisacPlayer.checkManager.getCheck(AiCheck::class.java) ?: return Optional.empty()
    return Optional.of(
      AiSnapshot(
        aiCheck.lastProbability,
        aiCheck.buffer,
        oasisacPlayer.combat.damageMultiplier,
        aiCheck.prob90,
      )
    )
  }
}
