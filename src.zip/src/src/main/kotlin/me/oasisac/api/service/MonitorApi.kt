package me.oasisac.api.service

import java.util.Optional
import java.util.UUID
import me.oasisac.api.model.MonitorSnapshot
import org.bukkit.entity.Player

/** Access to current monitor data for a player. */
interface MonitorApi {
  /** Returns the latest monitor snapshot if available. */
  fun getSnapshot(playerId: UUID): Optional<MonitorSnapshot>

  /** Convenience overload for Bukkit [Player]. */
  fun getSnapshot(player: Player?): Optional<MonitorSnapshot> {
    if (player == null) {
      return Optional.empty()
    }
    return getSnapshot(player.uniqueId)
  }
}
