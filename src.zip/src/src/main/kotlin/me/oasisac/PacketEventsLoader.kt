package me.oasisac

import com.github.retrooper.packetevents.PacketEvents
import com.github.retrooper.packetevents.PacketEventsAPI
import io.github.retrooper.packetevents.factory.spigot.SpigotPacketEventsBuilder
import java.util.logging.Level

internal class PacketEventsLoader(private val plugin: OasisAC) {

  fun load() {
    PacketEvents.setAPI(SpigotPacketEventsBuilder.build(plugin))
    PacketEvents.getAPI()
      .settings
      .checkForUpdates(false)
      .debug(false)
      .fullStackTrace(false)
      .kickOnPacketException(false)
      .reEncodeByDefault(false)
    PacketEvents.getAPI().load()
  }

  fun shutdown() {
    val api = PacketEvents.getAPI() ?: return

    runCatching {
        when {
          api.isInitialized -> api.terminate()
          api.isLoaded && !api.isTerminated -> shutdownLoadedApi(api)
        }
      }
      .onFailure { exception ->
        plugin.logger.log(Level.WARNING, "Failed to shut down PacketEvents cleanly.", exception)
      }
  }

  private fun shutdownLoadedApi(api: PacketEventsAPI<*>) {
    api.injector.uninject()
    api.eventManager.unregisterAllListeners()
  }
}
