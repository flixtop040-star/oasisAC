package me.oasisac

import com.github.retrooper.packetevents.PacketEvents
import me.oasisac.alert.AlertManager
import me.oasisac.api.OasisApi
import me.oasisac.command.CommandManager
import me.oasisac.config.ConfigManager
import me.oasisac.config.LocaleManager
import me.oasisac.coroutines.OasisCoroutines
import me.oasisac.database.DatabaseManager
import me.oasisac.debug.DebugManager
import me.oasisac.event.DamageEvent
import me.oasisac.monitor.MonitorViewService
import me.oasisac.packet.PacketListener
import me.oasisac.player.PlayerDataManager
import me.oasisac.server.AIServerProvider
import me.oasisac.utils.MessageUtil
import net.kyori.adventure.platform.bukkit.BukkitAudiences
import org.bukkit.plugin.ServicePriority

class OasisCore
@Suppress("LongParameterList")
constructor(
  private val plugin: OasisAC,
  private val playerDataManager: PlayerDataManager,
  private val configManager: ConfigManager,
  private val localeManager: LocaleManager,
  private val aiServerProvider: AIServerProvider,
  private val commandManager: CommandManager,
  private val alertManager: AlertManager,
  private val databaseManager: DatabaseManager,
  private val debugManager: DebugManager,
  private val packetListener: PacketListener,
  private val monitorViewService: MonitorViewService,
  private val damageEvent: DamageEvent,
  private val oasisacApi: OasisApi,
  private val adventure: BukkitAudiences,
  private val coroutines: OasisCoroutines,
) {
  fun enable() {
    commandManager.registerCommands()

    MessageUtil.init(localeManager, adventure, plugin.logger)

    initializePacketRuntime()
    plugin.server.pluginManager.registerEvents(damageEvent, plugin)
    plugin.server.servicesManager.register(
      OasisApi::class.java,
      oasisacApi,
      plugin,
      ServicePriority.Normal,
    )
  }

  fun disable() {
    plugin.server.servicesManager.unregister(OasisApi::class.java, oasisacApi)
    runCatching { playerDataManager.saveAllBuffersSync() }
    runCatching { aiServerProvider.shutdownTransport() }
    adventure.close()
    coroutines.close()
    databaseManager.shutdown()
  }

  fun reload() {
    configManager.reloadConfig()
    localeManager.reload()
    debugManager.reload()
    alertManager.reload()
    aiServerProvider.reload()
    playerDataManager.reloadAllPlayers()
    monitorViewService.reload()
  }

  private fun initializePacketRuntime() {
    PacketEvents.getAPI().eventManager.registerListener(packetListener)
    monitorViewService.start()
    PacketEvents.getAPI().init()
  }
}
