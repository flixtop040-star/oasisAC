package me.oasisac.scheduler

import java.util.concurrent.TimeUnit
import me.oasisac.OasisAC
import me.oasisac.platform.scheduler.ImmediateTaskHandle
import me.oasisac.platform.scheduler.PlatformScheduler
import me.oasisac.platform.scheduler.PlatformSchedulerFactory
import me.oasisac.platform.scheduler.TaskHandle
import org.bukkit.Bukkit
import org.bukkit.entity.Player

class SchedulerService(private val plugin: OasisAC, private val scheduler: PlatformScheduler) {
  private val folia = PlatformSchedulerFactory.isFolia()

  fun runAsync(task: Runnable): TaskHandle {
    return scheduler.asyncScheduler.runNow(plugin, task)
  }

  fun runSync(task: Runnable): TaskHandle {
    if (!folia && Bukkit.isPrimaryThread()) {
      task.run()
      return ImmediateTaskHandle.sync()
    }
    return scheduler.globalRegionScheduler.run(plugin, task)
  }

  fun runSync(player: Player?, task: Runnable): TaskHandle {
    if (player == null) {
      return runSync(task)
    }
    if (!folia && Bukkit.isPrimaryThread()) {
      task.run()
      return ImmediateTaskHandle.sync()
    }
    val handle = scheduler.entityScheduler.run(player, plugin, task, null)
    return handle ?: runSync(task)
  }

  fun runLater(task: Runnable, delayTicks: Long): TaskHandle {
    return scheduler.globalRegionScheduler.runDelayed(plugin, task, delayTicks)
  }

  fun runLaterAsync(task: Runnable, delayMillis: Long): TaskHandle {
    return scheduler.asyncScheduler.runDelayed(plugin, task, delayMillis, TimeUnit.MILLISECONDS)
  }

  fun runLater(player: Player?, task: Runnable, delayTicks: Long): TaskHandle {
    if (player == null) {
      return runLater(task, delayTicks)
    }
    val handle = scheduler.entityScheduler.runDelayed(player, plugin, task, null, delayTicks)
    return handle ?: runLater(task, delayTicks)
  }

  fun runTimer(task: Runnable, initialDelayTicks: Long, periodTicks: Long): TaskHandle {
    return scheduler.globalRegionScheduler.runAtFixedRate(
      plugin,
      task,
      initialDelayTicks,
      periodTicks,
    )
  }

  fun runTimer(
    player: Player?,
    task: Runnable,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle {
    if (player == null) {
      return runTimer(task, initialDelayTicks, periodTicks)
    }
    val handle =
      scheduler.entityScheduler.runAtFixedRate(
        player,
        plugin,
        task,
        null,
        initialDelayTicks,
        periodTicks,
      )
    return handle ?: runTimer(task, initialDelayTicks, periodTicks)
  }

  fun cancelTasks() {
    scheduler.asyncScheduler.cancel(plugin)
    scheduler.globalRegionScheduler.cancel(plugin)
  }
}
