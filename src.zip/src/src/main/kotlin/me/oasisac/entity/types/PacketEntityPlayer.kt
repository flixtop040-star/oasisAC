package me.oasisac.entity.types

import com.github.retrooper.packetevents.protocol.entity.type.EntityTypes
import java.util.UUID
import me.oasisac.entity.PacketEntity
import me.oasisac.player.OasisPlayer

class PacketEntityPlayer(player: OasisPlayer, uuid: UUID) :
  PacketEntity(player, uuid, EntityTypes.PLAYER)
