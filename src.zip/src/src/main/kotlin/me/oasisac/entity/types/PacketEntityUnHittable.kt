package me.oasisac.entity.types

import com.github.retrooper.packetevents.protocol.entity.type.EntityType
import java.util.UUID
import me.oasisac.entity.PacketEntity
import me.oasisac.player.OasisPlayer

class PacketEntityUnHittable(player: OasisPlayer, uuid: UUID, type: EntityType) :
  PacketEntity(player, uuid, type)
