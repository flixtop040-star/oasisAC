package me.oasisac.entity.types

import com.github.retrooper.packetevents.protocol.entity.type.EntityType
import java.util.UUID
import me.oasisac.player.OasisPlayer

class PacketEntityHorse(player: OasisPlayer, uuid: UUID, type: EntityType) :
  PacketEntityTrackXRot(player, uuid, type)
