package me.oasisac.entity

import com.github.retrooper.packetevents.protocol.entity.type.EntityType
import com.github.retrooper.packetevents.protocol.entity.type.EntityTypes
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap
import java.util.UUID
import me.oasisac.entity.types.PacketEntityArmorStand
import me.oasisac.entity.types.PacketEntityHorse
import me.oasisac.entity.types.PacketEntityPlayer
import me.oasisac.entity.types.PacketEntitySelf
import me.oasisac.entity.types.PacketEntityTrackXRot
import me.oasisac.entity.types.PacketEntityUnHittable
import me.oasisac.player.OasisPlayer

class CompensatedEntities(private val player: OasisPlayer) {
  val entityMap: Int2ObjectOpenHashMap<PacketEntity> = Int2ObjectOpenHashMap()
  val self: PacketEntitySelf = PacketEntitySelf(player)

  fun addEntity(entityId: Int, uuid: UUID, type: EntityType) {
    val packetEntity =
      when {
        type == EntityTypes.PLAYER -> PacketEntityPlayer(player, uuid)
        EntityTypes.isTypeInstanceOf(type, EntityTypes.ABSTRACT_HORSE) ->
          PacketEntityHorse(player, uuid, type)
        EntityTypes.isTypeInstanceOf(type, EntityTypes.BOAT) || type == EntityTypes.CHICKEN ->
          PacketEntityTrackXRot(player, uuid, type)
        EntityTypes.isTypeInstanceOf(type, EntityTypes.ABSTRACT_ARROW) ||
          type == EntityTypes.FIREWORK_ROCKET ||
          type == EntityTypes.ITEM -> PacketEntityUnHittable(player, uuid, type)
        type == EntityTypes.ARMOR_STAND -> PacketEntityArmorStand(player, uuid, type)
        else -> PacketEntity(player, uuid, type)
      }

    entityMap.put(entityId, packetEntity)
  }

  fun getEntity(entityId: Int): PacketEntity? {
    if (entityId == player.entityId) {
      return self
    }
    return entityMap.get(entityId)
  }

  fun removeEntity(entityId: Int) {
    entityMap.remove(entityId)
  }

  fun clear() {
    entityMap.clear()
  }
}
