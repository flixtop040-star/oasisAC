package me.oasisac.entity.types

import com.github.retrooper.packetevents.protocol.entity.type.EntityTypes
import me.oasisac.entity.PacketEntity
import me.oasisac.player.OasisPlayer

class PacketEntitySelf(player: OasisPlayer) : PacketEntity(player, player.uuid, EntityTypes.PLAYER)
