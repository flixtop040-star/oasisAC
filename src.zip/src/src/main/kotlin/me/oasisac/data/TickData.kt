package me.oasisac.data

import kotlin.math.abs
import kotlin.math.roundToLong
import me.oasisac.checks.impl.combat.AimProcessor
import me.oasisac.player.OasisPlayer

class TickData(oasisacPlayer: OasisPlayer) {
  val playerUuid: String = oasisacPlayer.uuid.toString()
  val playerName: String = oasisacPlayer.player.name
  val deltaYaw: Float
  val deltaPitch: Float
  val accelYaw: Float
  val accelPitch: Float
  val jerkPitch: Float
  val jerkYaw: Float
  val gcdErrorYaw: Float
  val gcdErrorPitch: Float

  init {
    val aimProcessor =
      requireNotNull(oasisacPlayer.checkManager.getCheck(AimProcessor::class.java)) {
        "AimProcessor is not available for TickData"
      }

    deltaYaw = oasisacPlayer.movement.yaw - oasisacPlayer.movement.lastYaw
    deltaPitch = oasisacPlayer.movement.pitch - oasisacPlayer.movement.lastPitch

    accelYaw = aimProcessor.currentYawAccel
    accelPitch = aimProcessor.currentPitchAccel

    jerkYaw = accelYaw - aimProcessor.lastYawAccel
    jerkPitch = accelPitch - aimProcessor.lastPitchAccel

    gcdErrorYaw =
      if (aimProcessor.modeX > 0) {
        val errorX = kotlin.math.abs(deltaYaw.toDouble() % aimProcessor.modeX)
        kotlin.math.min(errorX, aimProcessor.modeX - errorX).toFloat()
      } else {
        0f
      }
    gcdErrorPitch =
      if (aimProcessor.modeY > 0) {
        val errorY = kotlin.math.abs(deltaPitch.toDouble() % aimProcessor.modeY)
        kotlin.math.min(errorY, aimProcessor.modeY - errorY).toFloat()
      } else {
        0f
      }
  }

  fun toCsv(status: String): String {
    return buildString { appendCsv(this, status) }
  }

  fun appendCsv(out: Appendable, status: String) {
    val cheatingStatus = if (status.equals("CHEAT", ignoreCase = true)) 1 else 0
    out.append(if (cheatingStatus == 1) '1' else '0')
    out.append(',')
    appendFixed6(out, deltaYaw)
    out.append(',')
    appendFixed6(out, deltaPitch)
    out.append(',')
    appendFixed6(out, accelYaw)
    out.append(',')
    appendFixed6(out, accelPitch)
    out.append(',')
    appendFixed6(out, jerkYaw)
    out.append(',')
    appendFixed6(out, jerkPitch)
    out.append(',')
    appendFixed6(out, gcdErrorYaw)
    out.append(',')
    appendFixed6(out, gcdErrorPitch)
  }

  companion object {
    @JvmStatic
    fun getHeader(): String {
      return "is_cheating,delta_yaw,delta_pitch,accel_yaw,accel_pitch,jerk_yaw,jerk_pitch," +
        "gcd_error_yaw,gcd_error_pitch"
    }

    private const val SCALE = 1_000_000L

    private fun appendFixed6(out: Appendable, value: Float) {
      if (!value.isFinite()) {
        out.append("0.000000")
        return
      }

      var v = value.toDouble()
      val negative = v < 0.0
      if (negative) {
        v = -v
      }
      val scaled = (v * SCALE).roundToLong()
      val integerPart = scaled / SCALE
      val fractionPart = (scaled % SCALE).toInt()

      if (negative) {
        out.append('-')
      }
      out.append(integerPart.toString())
      out.append('.')
      val fractionText = fractionPart.toString()
      for (i in fractionText.length until 6) {
        out.append('0')
      }
      out.append(fractionText)
    }
  }
}
