package me.oasisac.integration

import com.sk89q.worldguard.WorldGuard
import com.sk89q.worldguard.protection.flags.StateFlag
import com.sk89q.worldguard.protection.flags.registry.FlagConflictException
import java.util.logging.Level
import java.util.logging.Logger
import org.bukkit.Bukkit

object OasisFlags {
  const val CHECKS_FLAG_NAME = "oasisac-checks"

  @Volatile
  var checks: StateFlag? = null
    private set

  fun register(logger: Logger) {
    if (
      !Bukkit.getPluginManager().isPluginEnabled("WorldGuard") ||
        Bukkit.getPluginManager().getPlugin("WorldGuard") == null
    ) {
      return
    }

    val registry =
      try {
        WorldGuard.getInstance().flagRegistry
      } catch (failure: NoClassDefFoundError) {
        logger.log(
          Level.FINE,
          "WorldGuard classes unavailable, skipping flag registration",
          failure,
        )
        return
      }

    try {
      val flag = StateFlag(CHECKS_FLAG_NAME, true)
      registry.register(flag)
      checks = flag
    } catch (conflict: FlagConflictException) {
      val existing = registry.get(CHECKS_FLAG_NAME)
      if (existing is StateFlag) {
        checks = existing
      } else {
        logger.log(
          Level.WARNING,
          "Flag $CHECKS_FLAG_NAME already registered with incompatible type",
          conflict,
        )
      }
    } catch (illegal: IllegalStateException) {
      logger.log(Level.WARNING, "Failed to register WorldGuard flag $CHECKS_FLAG_NAME", illegal)
    }
  }
}
