package me.oasisac.di

import java.util.logging.Logger
import me.oasisac.OasisAC
import me.oasisac.OasisCore
import me.oasisac.ai.AiResponseParser
import me.oasisac.ai.AiSerializer
import me.oasisac.ai.AiService
import me.oasisac.ai.DefaultAiService
import me.oasisac.ai.FlatBuffersAiSerializer
import me.oasisac.ai.JacksonAiResponseParser
import me.oasisac.alert.AlertManager
import me.oasisac.api.OasisApi
import me.oasisac.api.event.OasisEventBus
import me.oasisac.api.event.internal.OasisEventBusImpl
import me.oasisac.api.internal.AiApiImpl
import me.oasisac.api.internal.CheckApiImpl
import me.oasisac.api.internal.MonitorApiImpl
import me.oasisac.api.internal.OasisApiImpl
import me.oasisac.api.internal.PunishmentApiImpl
import me.oasisac.api.service.AiApi
import me.oasisac.api.service.CheckApi
import me.oasisac.api.service.MonitorApi
import me.oasisac.api.service.PunishmentApi
import me.oasisac.checks.CheckFactory
import me.oasisac.checks.CheckManager
import me.oasisac.checks.impl.ai.ActionManager
import me.oasisac.checks.impl.ai.AiCheck
import me.oasisac.checks.impl.ai.DataCollectorCheck
import me.oasisac.checks.impl.ai.DataCollectorManager
import me.oasisac.checks.impl.ai.PersistentBufferService
import me.oasisac.checks.impl.combat.AimProcessor
import me.oasisac.checks.impl.misc.ClientBrand
import me.oasisac.command.CommandManager
import me.oasisac.command.CommandRegister
import me.oasisac.command.OasisCommand
import me.oasisac.command.commands.admin.AlertsCommand
import me.oasisac.command.commands.admin.BrandsCommand
import me.oasisac.command.commands.admin.DataCollectCommand
import me.oasisac.command.commands.admin.ExemptCommand
import me.oasisac.command.commands.admin.PunishCommand
import me.oasisac.command.commands.admin.ReloadCommand
import me.oasisac.command.commands.admin.SuspiciousCommand
import me.oasisac.command.commands.info.HelpCommand
import me.oasisac.command.commands.info.HistoryCommand
import me.oasisac.command.commands.info.LogsCommand
import me.oasisac.command.commands.info.MonitorCommand
import me.oasisac.command.commands.info.ProfileCommand
import me.oasisac.command.commands.info.StatsCommand
import me.oasisac.command.commands.info.ViewCommand
import me.oasisac.command.handler.OasisCommandFailureHandler
import me.oasisac.config.ConfigManager
import me.oasisac.config.LocaleManager
import me.oasisac.coroutines.OasisCoroutines
import me.oasisac.damage.AiDamageProcessor
import me.oasisac.damage.DamageProcessor
import me.oasisac.database.DatabaseManager
import me.oasisac.debug.DebugManager
import me.oasisac.event.DamageEvent
import me.oasisac.integration.WorldGuardManager
import me.oasisac.monitor.MonitorSettingsService
import me.oasisac.monitor.MonitorViewService
import me.oasisac.packet.PacketListener
import me.oasisac.platform.scheduler.PlatformScheduler
import me.oasisac.platform.scheduler.PlatformSchedulerFactory
import me.oasisac.player.ExemptManager
import me.oasisac.player.PlayerDataManager
import me.oasisac.punishment.PunishmentManager
import me.oasisac.region.RegionProvider
import me.oasisac.scheduler.SchedulerService
import me.oasisac.sender.Sender
import me.oasisac.sender.SenderFactory
import me.oasisac.server.AIServerProvider
import net.kyori.adventure.platform.bukkit.BukkitAudiences
import org.bukkit.command.CommandSender
import org.incendo.cloud.SenderMapper
import org.koin.core.module.dsl.singleOf
import org.koin.core.qualifier.named
import org.koin.dsl.bind
import org.koin.dsl.module

fun oasisacModules(plugin: OasisAC) =
  listOf(coreModule(plugin), aiModule(), apiModule(), commandModule(), checkModule())

private fun coreModule(plugin: OasisAC) = module {
  single { plugin }
  single { BukkitAudiences.create(plugin) }
  single<Logger> { plugin.logger }
  single<PlatformScheduler> { PlatformSchedulerFactory.create() }
  single<OasisEventBus> { OasisEventBusImpl() }

  singleOf(::SchedulerService)
  singleOf(::OasisCoroutines)
  singleOf(::ConfigManager)
  singleOf(::LocaleManager)
  singleOf(::DatabaseManager)
  singleOf(::DebugManager)
  singleOf(::AIServerProvider)
  singleOf(::AlertManager)
  singleOf(::MonitorSettingsService)
  singleOf(::MonitorViewService)
  singleOf(::ExemptManager)
  singleOf(::DataCollectorManager)
  singleOf(::PersistentBufferService)
  singleOf(::WorldGuardManager)
  single<RegionProvider> { get<WorldGuardManager>() }
  single<DamageProcessor> { AiDamageProcessor(get()) }

  singleOf(::SenderFactory).bind<SenderMapper<CommandSender, Sender>>()

  singleOf(::OasisCommandFailureHandler)

  singleOf(::PlayerDataManager)
  singleOf(::PacketListener)
  singleOf(::DamageEvent)

  singleOf(::OasisCore)
}

private fun aiModule() = module {
  singleOf(::FlatBuffersAiSerializer).bind<AiSerializer>()
  singleOf(::JacksonAiResponseParser).bind<AiResponseParser>()
  singleOf(::DefaultAiService).bind<AiService>()
}

private fun apiModule() = module {
  singleOf(::AiApiImpl).bind<AiApi>()
  singleOf(::CheckApiImpl).bind<CheckApi>()
  singleOf(::MonitorApiImpl).bind<MonitorApi>()
  singleOf(::PunishmentApiImpl).bind<PunishmentApi>()
  singleOf(::OasisApiImpl).bind<OasisApi>()
}

private fun commandModule() = module {
  includes(adminCommandsModule(), infoCommandsModule())

  single { CommandRegister(getAll(), get()) }
  singleOf(::CommandManager)
}

private fun adminCommandsModule() = module {
  singleOf(::AlertsCommand).bind<OasisCommand>()
  singleOf(::BrandsCommand).bind<OasisCommand>()
  singleOf(::DataCollectCommand).bind<OasisCommand>()
  singleOf(::ExemptCommand).bind<OasisCommand>()
  singleOf(::PunishCommand).bind<OasisCommand>()
  singleOf(::ReloadCommand).bind<OasisCommand>()
  singleOf(::SuspiciousCommand).bind<OasisCommand>()
}

private fun infoCommandsModule() = module {
  singleOf(::HelpCommand).bind<OasisCommand>()
  singleOf(::HistoryCommand).bind<OasisCommand>()
  singleOf(::LogsCommand).bind<OasisCommand>()
  singleOf(::MonitorCommand).bind<OasisCommand>()
  singleOf(::ProfileCommand).bind<OasisCommand>()
  singleOf(::StatsCommand).bind<OasisCommand>()
  singleOf(::ViewCommand).bind<OasisCommand>()
}

private fun checkModule() = module {
  single<CheckFactory>(named("aim")) { CheckFactory { player -> AimProcessor(player) } }
  single<CheckFactory>(named("action")) { CheckFactory { player -> ActionManager(player, get()) } }
  single<CheckFactory>(named("ai")) {
    CheckFactory { player ->
      AiCheck(player, get(), get(), get(), get(), get(), get(), get(), get())
    }
  }
  single<CheckFactory>(named("collector")) {
    CheckFactory { player -> DataCollectorCheck(player, get(), get(), get()) }
  }
  single<CheckFactory>(named("brand")) {
    CheckFactory { player -> ClientBrand(player, get(), get()) }
  }

  single<Set<CheckFactory>> { getAll<CheckFactory>().toSet() }

  single<CheckManager.Factory> { CheckManager.Factory { player -> CheckManager(player, get()) } }
  single<PunishmentManager.Factory> {
    PunishmentManager.Factory { player ->
      PunishmentManager(player, get(), get(), get(), get(), get(), get(), get())
    }
  }
}
