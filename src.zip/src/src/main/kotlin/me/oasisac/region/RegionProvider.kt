package me.oasisac.region

import org.bukkit.entity.Player

interface RegionProvider {
  fun isPlayerInDisabledRegion(player: Player): Boolean
}
