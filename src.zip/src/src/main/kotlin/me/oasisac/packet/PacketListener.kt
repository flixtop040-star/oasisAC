package me.oasisac.packet

import com.github.retrooper.packetevents.PacketEvents
import com.github.retrooper.packetevents.event.PacketListenerAbstract
import com.github.retrooper.packetevents.event.PacketReceiveEvent
import com.github.retrooper.packetevents.event.PacketSendEvent
import com.github.retrooper.packetevents.event.UserDisconnectEvent
import com.github.retrooper.packetevents.event.UserLoginEvent
import com.github.retrooper.packetevents.manager.server.ServerVersion
import com.github.retrooper.packetevents.protocol.entity.type.EntityTypes
import com.github.retrooper.packetevents.protocol.packettype.PacketType
import com.github.retrooper.packetevents.protocol.player.ClientVersion
import com.github.retrooper.packetevents.protocol.teleport.RelativeFlag
import com.github.retrooper.packetevents.protocol.world.Location
import com.github.retrooper.packetevents.util.Vector3d
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerFlying
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPong
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientWindowConfirmation
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerDestroyEntities
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerJoinGame
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPing
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerPositionAndLook
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPlayerRotation
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSpawnEntity
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSpawnLivingEntity
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSpawnPainting
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerSpawnPlayer
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWindowConfirmation
import me.oasisac.player.OasisPlayer
import me.oasisac.player.PlayerDataManager
import me.oasisac.player.TransactionStamp
import me.oasisac.utils.update.RotationUpdate
import org.bukkit.entity.Player

class PacketListener(private val playerDataManager: PlayerDataManager) : PacketListenerAbstract() {
  override fun onUserLogin(event: UserLoginEvent) {
    val user: com.github.retrooper.packetevents.protocol.player.User? = event.user
    if (user == null) {
      return
    }
    val player: Player? = event.getPlayer()
    if (player == null) {
      return
    }
    playerDataManager.handleUserLogin(user, player)
  }

  override fun onUserDisconnect(event: UserDisconnectEvent) {
    playerDataManager.handleUserDisconnect(event.user)
  }

  private fun checkTeleportQueue(
    player: OasisPlayer,
    flying: WrapperPlayClientPlayerFlying,
  ): Boolean {
    if (!flying.hasPositionChanged() || player.pendingTeleports.isEmpty()) {
      return false
    }

    val movement = player.movement
    while (player.pendingTeleports.isNotEmpty()) {
      val teleport = player.pendingTeleports.peek() ?: break
      val lastTransaction = player.transactions.lastTransactionReceived.get()
      if (lastTransaction < teleport.transactionId) {
        return false
      }

      val flyingLocation = flying.location
      val flags = teleport.flags

      val expectedX =
        if (flags.has(RelativeFlag.X)) {
          movement.x + teleport.location.x
        } else {
          teleport.location.x
        }
      val expectedY =
        if (flags.has(RelativeFlag.Y)) {
          movement.y + teleport.location.y
        } else {
          teleport.location.y
        }
      val expectedZ =
        if (flags.has(RelativeFlag.Z)) {
          movement.z + teleport.location.z
        } else {
          teleport.location.z
        }

      val epsilon = 1.0E-7
      if (
        kotlin.math.abs(flyingLocation.x - expectedX) < epsilon &&
          kotlin.math.abs(flyingLocation.y - expectedY) < epsilon &&
          kotlin.math.abs(flyingLocation.z - expectedZ) < epsilon
      ) {
        player.pendingTeleports.poll()
        return true
      }

      if (lastTransaction > teleport.transactionId) {
        player.pendingTeleports.poll()
        continue
      }
      return false
    }
    return false
  }

  private fun checkRotationQueue(
    player: OasisPlayer,
    flying: WrapperPlayClientPlayerFlying,
  ): Boolean {
    if (
      !flying.hasRotationChanged() ||
        flying.hasPositionChanged() ||
        player.pendingRotations.isEmpty()
    ) {
      return false
    }

    while (player.pendingRotations.isNotEmpty()) {
      val rotation = player.pendingRotations.peek() ?: break
      val lastTransaction = player.transactions.lastTransactionReceived.get()
      if (lastTransaction < rotation.transactionId) {
        return false
      }

      if (flying.location.yaw == rotation.yaw && flying.location.pitch == rotation.pitch) {
        player.pendingRotations.poll()
        return true
      }

      if (lastTransaction > rotation.transactionId) {
        player.pendingRotations.poll()
        continue
      }
      return false
    }
    return false
  }

  override fun onPacketReceive(event: PacketReceiveEvent) {
    val player: Player? = event.getPlayer<Player>()
    if (player == null) {
      return
    }

    val oasisacPlayer = playerDataManager.getPlayer(player) ?: return

    if (handleTransaction(event, oasisacPlayer)) {
      return
    }

    if (WrapperPlayClientPlayerFlying.isFlying(event.packetType)) {
      handleFlying(event, oasisacPlayer)
    }

    if (event.isCancelled) {
      resetFlags(oasisacPlayer)
      return
    }

    if (
      oasisacPlayer.packetStateData.lastPacketWasTeleport ||
        oasisacPlayer.packetStateData.lastPacketWasServerRotation
    ) {
      updatePlayerState(oasisacPlayer, WrapperPlayClientPlayerFlying(event))
    }

    oasisacPlayer.checkManager.onPacketReceive(event)

    resetFlags(oasisacPlayer)
  }

  private fun handleTransaction(event: PacketReceiveEvent, oasisacPlayer: OasisPlayer): Boolean {
    if (event.packetType == PacketType.Play.Client.WINDOW_CONFIRMATION) {
      val transaction = WrapperPlayClientWindowConfirmation(event)
      val id = transaction.actionId
      if (id <= 0 && addTransactionResponse(oasisacPlayer, id)) {
        event.isCancelled = true
      }
      return true
    } else if (event.packetType == PacketType.Play.Client.PONG) {
      val pong = WrapperPlayClientPong(event)
      val id = pong.id.toShort()
      if (addTransactionResponse(oasisacPlayer, id)) {
        event.isCancelled = true
      }
      return true
    }
    return false
  }

  private fun handleFlying(event: PacketReceiveEvent, oasisacPlayer: OasisPlayer) {
    val flying = WrapperPlayClientPlayerFlying(event)

    val teleported = checkTeleportQueue(oasisacPlayer, flying)
    val serverRotated = !teleported && checkRotationQueue(oasisacPlayer, flying)

    oasisacPlayer.packetStateData.lastPacketWasTeleport = teleported
    oasisacPlayer.packetStateData.lastPacketWasServerRotation = serverRotated

    isMojangStupid(oasisacPlayer, flying, event)

    if (!event.isCancelled) {
      processRotation(oasisacPlayer, flying)
    }
  }

  private fun processRotation(oasisacPlayer: OasisPlayer, packet: WrapperPlayClientPlayerFlying) {
    val ignoreRotation =
      oasisacPlayer.packetStateData.lastPacketWasOnePointSeventeenDuplicate &&
        oasisacPlayer.isIgnoreDuplicatePacketRotation()
    val movement = oasisacPlayer.movement

    if (packet.hasPositionChanged()) {
      movement.x = packet.location.x
      movement.y = packet.location.y
      movement.z = packet.location.z
      if (!oasisacPlayer.packetStateData.lastPacketWasOnePointSeventeenDuplicate) {
        oasisacPlayer.packetStateData.duplicatePacketFilterPosition = packet.location.position
      }
    }

    if (packet.hasRotationChanged() && !ignoreRotation) {
      val newYaw = packet.location.yaw
      val newPitch = packet.location.pitch
      val deltaYaw = newYaw - movement.yaw
      val deltaPitch = newPitch - movement.pitch

      val update: RotationUpdate = oasisacPlayer.rotationUpdate

      update.from.yaw = movement.yaw
      update.from.pitch = movement.pitch
      update.to.yaw = newYaw
      update.to.pitch = newPitch
      update.deltaYaw = deltaYaw
      update.deltaPitch = deltaPitch

      oasisacPlayer.checkManager.onRotationUpdate(update)

      movement.lastYaw = movement.yaw
      movement.lastPitch = movement.pitch
      movement.yaw = newYaw
      movement.pitch = newPitch
    }
  }

  private fun updatePlayerState(oasisacPlayer: OasisPlayer, flying: WrapperPlayClientPlayerFlying) {
    val movement = oasisacPlayer.movement
    if (flying.hasPositionChanged()) {
      movement.x = flying.location.x
      movement.y = flying.location.y
      movement.z = flying.location.z
    }
    if (flying.hasRotationChanged()) {
      movement.yaw = flying.location.yaw
      movement.pitch = flying.location.pitch
    }
  }

  private fun resetFlags(oasisacPlayer: OasisPlayer) {
    oasisacPlayer.packetStateData.lastPacketWasOnePointSeventeenDuplicate = false
    oasisacPlayer.packetStateData.lastPacketWasTeleport = false
    oasisacPlayer.packetStateData.lastPacketWasServerRotation = false
  }

  override fun onPacketSend(event: PacketSendEvent) {
    val player: Player? = event.getPlayer<Player>()
    if (player != null) {
      val oasisacPlayer = playerDataManager.getPlayer(player) ?: return
      (event.packetType as? PacketType.Play.Server)?.let { packetType ->
        when (packetType) {
          PacketType.Play.Server.WINDOW_CONFIRMATION ->
            handleWindowConfirmation(WrapperPlayServerWindowConfirmation(event), oasisacPlayer)
          PacketType.Play.Server.PING -> handlePing(WrapperPlayServerPing(event), oasisacPlayer)
          PacketType.Play.Server.SPAWN_ENTITY ->
            handleSpawnEntity(WrapperPlayServerSpawnEntity(event), oasisacPlayer)
          PacketType.Play.Server.SPAWN_LIVING_ENTITY ->
            handleSpawnLivingEntity(WrapperPlayServerSpawnLivingEntity(event), oasisacPlayer)
          PacketType.Play.Server.SPAWN_PAINTING ->
            handleSpawnPainting(WrapperPlayServerSpawnPainting(event), oasisacPlayer)
          PacketType.Play.Server.SPAWN_PLAYER ->
            handleSpawnPlayer(WrapperPlayServerSpawnPlayer(event), oasisacPlayer)
          PacketType.Play.Server.DESTROY_ENTITIES ->
            handleDestroyEntities(WrapperPlayServerDestroyEntities(event), oasisacPlayer)
          PacketType.Play.Server.JOIN_GAME ->
            handleJoinGame(WrapperPlayServerJoinGame(event), oasisacPlayer)
          PacketType.Play.Server.RESPAWN -> handleRespawn(oasisacPlayer)
          PacketType.Play.Server.PLAYER_POSITION_AND_LOOK ->
            handlePositionAndLook(WrapperPlayServerPlayerPositionAndLook(event), oasisacPlayer)
          PacketType.Play.Server.PLAYER_ROTATION ->
            handlePlayerRotation(WrapperPlayServerPlayerRotation(event), oasisacPlayer)
          else -> Unit
        }
      }
    }
  }

  private fun handleWindowConfirmation(
    confirmation: WrapperPlayServerWindowConfirmation,
    oasisacPlayer: OasisPlayer,
  ) {
    val id = confirmation.actionId
    val transactions = oasisacPlayer.transactions
    if (id <= 0 && transactions.didWeSendThatTrans.remove(id)) {
      transactions.entitiesDespawnedThisTransaction.clear()
      transactions.transactionsSent.add(TransactionStamp(id, System.nanoTime()))
      transactions.lastTransactionSent.getAndIncrement()
    }
  }

  private fun handlePing(ping: WrapperPlayServerPing, oasisacPlayer: OasisPlayer) {
    val id = ping.id
    val transactions = oasisacPlayer.transactions
    if (id == id.toShort().toInt() && transactions.didWeSendThatTrans.remove(id.toShort())) {
      transactions.entitiesDespawnedThisTransaction.clear()
      transactions.transactionsSent.add(TransactionStamp(id.toShort(), System.nanoTime()))
      transactions.lastTransactionSent.getAndIncrement()
    }
  }

  private fun handleSpawnEntity(spawn: WrapperPlayServerSpawnEntity, oasisacPlayer: OasisPlayer) {
    if (oasisacPlayer.transactions.entitiesDespawnedThisTransaction.contains(spawn.entityId)) {
      oasisacPlayer.sendTransaction()
    }
    oasisacPlayer.latencyUtils.addRealTimeTask(
      oasisacPlayer.transactions.lastTransactionSent.get(),
      Runnable {
        oasisacPlayer.compensatedEntities.addEntity(
          spawn.entityId,
          spawn.uuid.orElse(null),
          spawn.entityType,
        )
      },
    )
  }

  private fun handleSpawnLivingEntity(
    spawn: WrapperPlayServerSpawnLivingEntity,
    oasisacPlayer: OasisPlayer,
  ) {
    if (oasisacPlayer.transactions.entitiesDespawnedThisTransaction.contains(spawn.entityId)) {
      oasisacPlayer.sendTransaction()
    }
    oasisacPlayer.latencyUtils.addRealTimeTask(
      oasisacPlayer.transactions.lastTransactionSent.get(),
      Runnable {
        oasisacPlayer.compensatedEntities.addEntity(
          spawn.entityId,
          spawn.entityUUID,
          spawn.entityType,
        )
      },
    )
  }

  private fun handleSpawnPainting(
    spawn: WrapperPlayServerSpawnPainting,
    oasisacPlayer: OasisPlayer,
  ) {
    if (oasisacPlayer.transactions.entitiesDespawnedThisTransaction.contains(spawn.entityId)) {
      oasisacPlayer.sendTransaction()
    }
    oasisacPlayer.latencyUtils.addRealTimeTask(
      oasisacPlayer.transactions.lastTransactionSent.get(),
      Runnable {
        oasisacPlayer.compensatedEntities.addEntity(
          spawn.entityId,
          spawn.uuid,
          EntityTypes.PAINTING,
        )
      },
    )
  }

  private fun handleSpawnPlayer(spawn: WrapperPlayServerSpawnPlayer, oasisacPlayer: OasisPlayer) {
    if (oasisacPlayer.transactions.entitiesDespawnedThisTransaction.contains(spawn.entityId)) {
      oasisacPlayer.sendTransaction()
    }
    oasisacPlayer.latencyUtils.addRealTimeTask(
      oasisacPlayer.transactions.lastTransactionSent.get(),
      Runnable {
        oasisacPlayer.compensatedEntities.addEntity(spawn.entityId, spawn.uuid, EntityTypes.PLAYER)
      },
    )
  }

  private fun handleDestroyEntities(
    destroy: WrapperPlayServerDestroyEntities,
    oasisacPlayer: OasisPlayer,
  ) {
    for (id in destroy.entityIds) {
      oasisacPlayer.transactions.entitiesDespawnedThisTransaction.add(id)
    }
    oasisacPlayer.latencyUtils.addRealTimeTask(
      oasisacPlayer.transactions.lastTransactionSent.get() + 1,
      Runnable {
        for (id in destroy.entityIds) {
          oasisacPlayer.compensatedEntities.removeEntity(id)
        }
      },
    )
  }

  private fun handleJoinGame(join: WrapperPlayServerJoinGame, oasisacPlayer: OasisPlayer) {
    oasisacPlayer.latencyUtils.addRealTimeTask(
      oasisacPlayer.transactions.lastTransactionSent.get(),
      Runnable {
        oasisacPlayer.entityId = join.entityId
        oasisacPlayer.gameMode = join.gameMode
        oasisacPlayer.compensatedEntities.clear()
      },
    )
  }

  private fun handleRespawn(oasisacPlayer: OasisPlayer) {
    oasisacPlayer.latencyUtils.addRealTimeTask(
      oasisacPlayer.transactions.lastTransactionSent.get(),
      Runnable { oasisacPlayer.compensatedEntities.clear() },
    )
  }

  private fun handlePositionAndLook(
    wrapper: WrapperPlayServerPlayerPositionAndLook,
    oasisacPlayer: OasisPlayer,
  ) {
    oasisacPlayer.sendTransaction()
    val transactionId = oasisacPlayer.transactions.lastTransactionSent.get()
    val location = Vector3d(wrapper.x, wrapper.y, wrapper.z)
    val flags = wrapper.relativeFlags
    oasisacPlayer.pendingTeleports.add(OasisPlayer.TeleportData(location, flags, transactionId))
  }

  private fun handlePlayerRotation(
    wrapper: WrapperPlayServerPlayerRotation,
    oasisacPlayer: OasisPlayer,
  ) {
    oasisacPlayer.sendTransaction()
    val transactionId = oasisacPlayer.transactions.lastTransactionSent.get()
    oasisacPlayer.pendingRotations.add(
      OasisPlayer.RotationData(wrapper.yaw, wrapper.pitch, transactionId)
    )
  }

  private fun addTransactionResponse(player: OasisPlayer, id: Short): Boolean {
    var data: TransactionStamp? = null
    var hasId = false

    for (entry in player.transactions.transactionsSent) {
      if (entry.id == id) {
        hasId = true
        break
      }
    }

    if (hasId) {
      do {
        data = player.transactions.transactionsSent.poll()
        if (data == null) break
        player.transactions.lastTransactionReceived.incrementAndGet()
      } while (data.id != id)

      player.latencyUtils.handleNettySyncTransaction(
        player.transactions.lastTransactionReceived.get()
      )
    }
    return data != null
  }

  private fun isMojangStupid(
    player: OasisPlayer,
    flying: WrapperPlayClientPlayerFlying,
    event: PacketReceiveEvent,
  ) {
    if (
      player.packetStateData.lastPacketWasTeleport ||
        player.user.clientVersion.isNewerThanOrEquals(ClientVersion.V_1_21)
    ) {
      return
    }

    val location: Location = flying.location
    if (shouldProcessDuplicate(player, flying, location)) {
      handleDuplicatePacketAction(player, flying, location, event)
      player.packetStateData.lastPacketWasOnePointSeventeenDuplicate = true
      applyDuplicateRotation(player, location)
    }
  }

  private fun shouldProcessDuplicate(
    player: OasisPlayer,
    flying: WrapperPlayClientPlayerFlying,
    location: Location,
  ): Boolean {
    val threshold = player.getMovementThreshold()
    val inVehicle = player.compensatedEntities.self.riding != null
    val hasMovementAndRotation = flying.hasPositionChanged() && flying.hasRotationChanged()
    val sameGroundAndCloseClaim =
      flying.isOnGround == player.packetStateData.packetPlayerOnGround &&
        player.user.clientVersion.isNewerThanOrEquals(ClientVersion.V_1_17) &&
        player.packetStateData.duplicatePacketFilterPosition.distanceSquared(location.position) <
          threshold * threshold
    return hasMovementAndRotation && (sameGroundAndCloseClaim || inVehicle)
  }

  private fun handleDuplicatePacketAction(
    player: OasisPlayer,
    flying: WrapperPlayClientPlayerFlying,
    location: Location,
    event: PacketReceiveEvent,
  ) {
    val serverVersion = PacketEvents.getAPI().serverManager.version
    if (player.isForceCancelDuplicatePacket()) {
      event.isCancelled = true
      return
    }

    if (serverVersion.isOlderThanOrEquals(ServerVersion.V_1_9)) {
      if (player.isCancelDuplicatePacket()) {
        event.isCancelled = true
      }
      return
    }

    flying.location =
      Location(player.packetStateData.duplicatePacketFilterPosition, location.yaw, location.pitch)
    event.markForReEncode(true)
  }

  private fun applyDuplicateRotation(player: OasisPlayer, location: Location) {
    if (player.isIgnoreDuplicatePacketRotation()) return

    val movement = player.movement
    if (movement.yaw != location.yaw || movement.pitch != location.pitch) {
      movement.lastYaw = movement.yaw
      movement.lastPitch = movement.pitch
    }
    movement.yaw = location.yaw
    movement.pitch = location.pitch
  }
}
