package me.oasisac.checks.impl.ai

import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.logging.Level
import me.oasisac.OasisAC
import me.oasisac.data.DataSession
import me.oasisac.scheduler.SchedulerService

class DataCollectorManager(private val plugin: OasisAC, private val scheduler: SchedulerService) {
  val activeSessions: MutableMap<UUID, DataSession> = ConcurrentHashMap()

  fun startCollecting(uuid: UUID, playerName: String, status: String): Boolean {
    val existingSession = activeSessions[uuid]
    if (existingSession != null) {
      if (existingSession.status == status) {
        return false
      }
      stopCollecting(uuid)
    }
    activeSessions[uuid] = DataSession(uuid, playerName, status)
    return true
  }

  fun stopCollecting(uuid: UUID): Boolean {
    val session = activeSessions.remove(uuid)
    if (session != null) {
      scheduler.runAsync {
        try {
          session.saveAndClose(plugin)
        } catch (e: IOException) {
          plugin.logger.log(Level.SEVERE, "Failed to save data for $uuid", e)
        }
      }
      return true
    }
    return false
  }

  fun getSession(uuid: UUID): DataSession? {
    return activeSessions[uuid]
  }
}
