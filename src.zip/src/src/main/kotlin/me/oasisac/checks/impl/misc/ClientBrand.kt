package me.oasisac.checks.impl.misc

import com.github.retrooper.packetevents.PacketEvents
import com.github.retrooper.packetevents.event.PacketReceiveEvent
import com.github.retrooper.packetevents.manager.server.ServerVersion
import com.github.retrooper.packetevents.protocol.packettype.PacketType
import com.github.retrooper.packetevents.protocol.player.ClientVersion
import com.github.retrooper.packetevents.wrapper.configuration.client.WrapperConfigClientPluginMessage
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPluginMessage
import java.nio.charset.StandardCharsets
import me.oasisac.alert.AlertManager
import me.oasisac.alert.AlertType
import me.oasisac.checks.AbstractCheck
import me.oasisac.checks.CheckData
import me.oasisac.checks.CheckFactory
import me.oasisac.checks.type.PacketCheck
import me.oasisac.config.ConfigManager
import me.oasisac.player.OasisPlayer
import me.oasisac.utils.ChatUtil
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import net.kyori.adventure.text.Component

@CheckData(name = "ClientBrand_Internal")
class ClientBrand(
  oasisacPlayer: OasisPlayer,
  private val configManager: ConfigManager,
  private val alertManager: AlertManager,
) : AbstractCheck(oasisacPlayer), PacketCheck {
  companion object {
    private val CHANNEL =
      if (PacketEvents.getAPI().serverManager.version.isNewerThanOrEquals(ServerVersion.V_1_13)) {
        "minecraft:brand"
      } else {
        "MC|Brand"
      }
  }

  var brand: String = "vanilla"
    private set

  private var hasBrand = false

  interface Factory : CheckFactory {
    override fun create(player: OasisPlayer): ClientBrand
  }

  override fun onPacketReceive(event: PacketReceiveEvent) {
    if (event.packetType == PacketType.Play.Client.PLUGIN_MESSAGE) {
      val packet = WrapperPlayClientPluginMessage(event)
      handle(packet.channelName, packet.data)
    } else if (event.packetType == PacketType.Configuration.Client.PLUGIN_MESSAGE) {
      val packet = WrapperConfigClientPluginMessage(event)
      handle(packet.channelName, packet.data)
    }
  }

  private fun handle(channel: String, data: ByteArray) {
    if (channel != CHANNEL || hasBrand) {
      return
    }

    val oasisacPlayer = oasisacPlayer
    hasBrand = true

    if (data.size > 64 || data.isEmpty()) {
      brand = "invalid (${data.size} bytes)"
    } else {
      val brandBytes = ByteArray(data.size - 1)
      System.arraycopy(data, 1, brandBytes, 0, brandBytes.size)

      brand = String(brandBytes, StandardCharsets.UTF_8).replace(" (Velocity)", "")
      brand = ChatUtil.stripColor(brand) ?: brand
    }

    oasisacPlayer.brand = brand

    if (!configManager.isClientIgnored(brand)) {
      val component: Component =
        MessageUtil.getMessage(
          Message.BRAND_NOTIFICATION,
          "player",
          oasisacPlayer.player.name,
          "brand",
          brand,
        )
      alertManager.send(component, AlertType.BRAND)
    }

    val hasReachExploit =
      brand.contains("forge") &&
        oasisacPlayer.user.clientVersion.isNewerThanOrEquals(ClientVersion.V_1_18_2) &&
        oasisacPlayer.user.clientVersion.isOlderThan(ClientVersion.V_1_19_4)

    if (hasReachExploit && configManager.isDisconnectBlacklistedForge()) {
      oasisacPlayer.disconnect(MessageUtil.getMessage(Message.BRAND_DISCONNECT_FORGE))
    }
  }
}
