package me.oasisac.checks.impl.ai

import com.github.retrooper.packetevents.event.PacketReceiveEvent
import com.github.retrooper.packetevents.protocol.packettype.PacketType
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientInteractEntity
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerFlying
import me.oasisac.checks.AbstractCheck
import me.oasisac.checks.CheckData
import me.oasisac.checks.CheckFactory
import me.oasisac.checks.type.PacketCheck
import me.oasisac.config.ConfigManager
import me.oasisac.entity.PacketEntity
import me.oasisac.player.OasisPlayer

@CheckData(name = "ActionManager_Internal")
class ActionManager(player: OasisPlayer, configManager: ConfigManager) :
  AbstractCheck(player), PacketCheck {
  init {
    val sequence = configManager.aiSequence
    player.combat.ticksSinceAttack = sequence + 1
  }

  interface Factory : CheckFactory {
    override fun create(player: OasisPlayer): ActionManager
  }

  override fun onPacketReceive(event: PacketReceiveEvent) {
    if (event.packetType == PacketType.Play.Client.INTERACT_ENTITY) {
      val action = WrapperPlayClientInteractEntity(event)
      if (action.action == WrapperPlayClientInteractEntity.InteractAction.ATTACK) {
        val entity: PacketEntity =
          oasisacPlayer.compensatedEntities.getEntity(action.entityId) ?: return

        if (entity.isPlayer) {
          oasisacPlayer.combat.ticksSinceAttack = 0
        }
      }
    } else if (WrapperPlayClientPlayerFlying.isFlying(event.packetType)) {
      oasisacPlayer.combat.ticksSinceAttack = oasisacPlayer.combat.ticksSinceAttack + 1
    }
  }
}
