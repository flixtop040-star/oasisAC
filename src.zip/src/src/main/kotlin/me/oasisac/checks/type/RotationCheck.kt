package me.oasisac.checks.type

import me.oasisac.checks.ICheck
import me.oasisac.utils.update.RotationUpdate

interface RotationCheck : ICheck {
  fun process(rotationUpdate: RotationUpdate)
}
