package me.oasisac.checks

import com.github.retrooper.packetevents.event.PacketReceiveEvent
import me.oasisac.checks.type.PacketCheck
import me.oasisac.checks.type.RotationCheck
import me.oasisac.player.OasisPlayer
import me.oasisac.utils.update.RotationUpdate

class CheckManager(private val player: OasisPlayer, checkFactories: Set<CheckFactory>) {
  private val rotationChecks = ArrayList<RotationCheck>()
  private val packetChecks = ArrayList<PacketCheck>()
  private val checks = HashMap<Class<out ICheck>, ICheck>()

  init {
    for (factory in checkFactories) {
      registerCheck(factory.create(player))
    }
  }

  private fun checksDisabled(): Boolean = player.exemptManager.isDisabled(player.player)

  private fun registerCheck(check: ICheck) {
    checks[check.javaClass] = check

    if (check is RotationCheck) {
      rotationChecks.add(check)
    }

    if (check is PacketCheck) {
      packetChecks.add(check)
    }
  }

  fun reloadChecks() {
    for (check in checks.values) {
      if (check is Reloadable) {
        check.reload()
      }
    }
  }

  fun onRotationUpdate(update: RotationUpdate) {
    if (checksDisabled()) {
      return
    }
    for (check in rotationChecks) {
      check.process(update)
    }
  }

  fun onPacketReceive(event: PacketReceiveEvent) {
    if (checksDisabled()) {
      return
    }
    for (check in packetChecks) {
      check.onPacketReceive(event)
    }
  }

  @Suppress("UNCHECKED_CAST")
  fun <T : ICheck> getCheck(clazz: Class<T>): T? {
    return checks[clazz] as T?
  }

  fun getAllChecks(): Collection<ICheck> = checks.values

  fun interface Factory {
    fun create(player: OasisPlayer): CheckManager
  }
}
