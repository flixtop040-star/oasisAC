package me.oasisac.checks

interface Reloadable {
  fun reload()
}
