package me.oasisac.checks.impl.combat

import me.oasisac.checks.AbstractCheck
import me.oasisac.checks.CheckData
import me.oasisac.checks.CheckFactory
import me.oasisac.checks.type.RotationCheck
import me.oasisac.player.OasisPlayer
import me.oasisac.utils.lists.RunningMode
import me.oasisac.utils.math.OasisMath
import me.oasisac.utils.update.RotationUpdate

@CheckData(name = "AimProcessor_Internal")
class AimProcessor(oasisacPlayer: OasisPlayer) : AbstractCheck(oasisacPlayer), RotationCheck {
  var sensitivityX: Double = 0.0
  var sensitivityY: Double = 0.0
  var divisorX: Double = 0.0
  var divisorY: Double = 0.0
  var modeX: Double = 0.0
  var modeY: Double = 0.0
  var deltaDotsX: Double = 0.0
  var deltaDotsY: Double = 0.0
  private val xRotMode = RunningMode(TOTAL_SAMPLES_THRESHOLD)
  private val yRotMode = RunningMode(TOTAL_SAMPLES_THRESHOLD)
  private var lastXRot = 0.0
  private var lastYRot = 0.0

  private var lastDeltaYaw = 0.0f
  private var lastDeltaPitch = 0.0f

  var lastYawAccel = 0.0f
    private set

  var lastPitchAccel = 0.0f
    private set

  var currentYawAccel = 0.0f
    private set

  var currentPitchAccel = 0.0f
    private set

  interface Factory : CheckFactory {
    override fun create(player: OasisPlayer): AimProcessor
  }

  override fun process(rotationUpdate: RotationUpdate) {
    val deltaYaw = rotationUpdate.deltaYaw
    val deltaPitch = rotationUpdate.deltaPitch
    val deltaYawAbs = kotlin.math.abs(deltaYaw).toDouble()
    val deltaPitchAbs = kotlin.math.abs(deltaPitch).toDouble()
    lastYawAccel = currentYawAccel
    lastPitchAccel = currentPitchAccel
    currentYawAccel = (deltaYawAbs - kotlin.math.abs(lastDeltaYaw)).toFloat()
    currentPitchAccel = (deltaPitchAbs - kotlin.math.abs(lastDeltaPitch)).toFloat()
    lastDeltaYaw = deltaYaw
    lastDeltaPitch = deltaPitch

    divisorX = OasisMath.gcd(deltaYawAbs, lastXRot)
    if (deltaYawAbs > 0 && deltaYawAbs < 5 && divisorX > OasisMath.getMinimumDivisor()) {
      xRotMode.add(divisorX)
      lastXRot = deltaYawAbs
    }

    divisorY = OasisMath.gcd(deltaPitchAbs, lastYRot)
    if (deltaPitchAbs > 0 && deltaPitchAbs < 5 && divisorY > OasisMath.getMinimumDivisor()) {
      yRotMode.add(divisorY)
      lastYRot = deltaPitchAbs
    }

    if (xRotMode.size() > SIGNIFICANT_SAMPLES_THRESHOLD) {
      xRotMode.updateMode()
      if (xRotMode.modeCount > SIGNIFICANT_SAMPLES_THRESHOLD) {
        modeX = xRotMode.modeValue
        sensitivityX = convertToSensitivity(modeX)
      }
    }

    if (yRotMode.size() > SIGNIFICANT_SAMPLES_THRESHOLD) {
      yRotMode.updateMode()
      if (yRotMode.modeCount > SIGNIFICANT_SAMPLES_THRESHOLD) {
        modeY = yRotMode.modeValue
        sensitivityY = convertToSensitivity(modeY)
      }
    }

    if (modeX > 0) {
      deltaDotsX = deltaYawAbs / modeX
    }
    if (modeY > 0) {
      deltaDotsY = deltaPitchAbs / modeY
    }
  }

  companion object {
    private const val SIGNIFICANT_SAMPLES_THRESHOLD = 15
    private const val TOTAL_SAMPLES_THRESHOLD = 80

    fun convertToSensitivity(value: Double): Double {
      val normalized = value / 0.15F / 8.0
      val cubic = Math.cbrt(normalized)
      return (cubic - 0.2f) / 0.6f
    }
  }
}
