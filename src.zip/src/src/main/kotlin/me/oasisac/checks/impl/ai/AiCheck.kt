package me.oasisac.checks.impl.ai

import com.github.retrooper.packetevents.event.PacketReceiveEvent
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerFlying
import java.util.ArrayDeque
import java.util.Arrays
import java.util.concurrent.atomic.AtomicReference
import me.oasisac.OasisAC
import me.oasisac.ai.AiResult
import me.oasisac.ai.AiService
import me.oasisac.ai.AiServiceException
import me.oasisac.alert.AlertManager
import me.oasisac.alert.AlertType
import me.oasisac.api.event.AiPredictionEvent
import me.oasisac.checks.AbstractCheck
import me.oasisac.checks.CheckData
import me.oasisac.checks.CheckFactory
import me.oasisac.checks.Reloadable
import me.oasisac.checks.type.PacketCheck
import me.oasisac.config.ConfigManager
import me.oasisac.damage.DamageProcessor
import me.oasisac.data.TickData
import me.oasisac.debug.DebugCategory
import me.oasisac.debug.DebugManager
import me.oasisac.player.OasisPlayer
import me.oasisac.region.RegionProvider
import me.oasisac.scheduler.SchedulerService
import me.oasisac.server.AIServer
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil

@CheckData(name = "AI (Aim)")
class AiCheck(
  oasisacPlayer: OasisPlayer,
  private val plugin: OasisAC,
  private val aiService: AiService,
  private val configManager: ConfigManager,
  private val regionProvider: RegionProvider,
  private val alertManager: AlertManager,
  private val damageProcessor: DamageProcessor,
  private val debugManager: DebugManager,
  private val scheduler: SchedulerService,
) : AbstractCheck(oasisacPlayer), PacketCheck, Reloadable {
  private var step: Int = 0
  private var aiEnabled = false
  private var ticks: ArrayDeque<TickData> = ArrayDeque()
  private val snapshotBuffer: AtomicReference<Array<TickData?>?> = AtomicReference()
  private var ticksStep = 0

  var buffer: Double = 0.0
    private set

  fun restoreBuffer(value: Double) {
    val sanitized = kotlin.math.max(0.0, value)
    buffer = kotlin.math.max(buffer, sanitized)
  }

  var lastProbability: Double = 0.0
    private set

  var prob90: Int = 0

  private var flag = 0.0
  private var bufferResetOnFlag = 0.0
  private var bufferMultiplier = 0.0
  private var bufferDecrease = 0.0
  private var suspiciousAlertBuffer = 0.0

  init {
    reload()
  }

  interface Factory : CheckFactory {
    override fun create(player: OasisPlayer): AiCheck
  }

  override fun reload() {
    aiEnabled = aiService.isEnabled

    if (ticks.isEmpty() || ticks.size != configManager.aiSequence) {
      ticks = ArrayDeque(configManager.aiSequence)
    }

    step = configManager.aiStep
    flag = configManager.aiFlag
    bufferResetOnFlag = configManager.aiResetOnFlag
    bufferMultiplier = configManager.aiBufferMultiplier
    bufferDecrease = configManager.aiBufferDecrease
    suspiciousAlertBuffer = configManager.suspiciousAlertsBuffer
  }

  override fun onPacketReceive(event: PacketReceiveEvent) {
    if (!aiEnabled) return
    if (!WrapperPlayClientPlayerFlying.isFlying(event.packetType)) return
    val oasisacPlayer = oasisacPlayer

    val sequence = configManager.aiSequence

    if (oasisacPlayer.packetStateData.lastPacketWasOnePointSeventeenDuplicate) {
      debugManager.log(
        DebugCategory.PACKET_DUPLICATION,
        "Mojang failed IQ Test for: ${oasisacPlayer.player.name}.",
      )
      return
    }

    if (
      oasisacPlayer.packetStateData.lastPacketWasTeleport ||
        oasisacPlayer.packetStateData.lastPacketWasServerRotation
    ) {
      return
    }

    if (!configManager.aiContinuous && oasisacPlayer.combat.ticksSinceAttack > sequence) {
      if (ticks.isNotEmpty()) {
        ticks.clear()
      }
      ticksStep = 0
      return
    }

    ticks.addLast(TickData(oasisacPlayer))
    ticksStep++

    while (ticks.size > sequence) {
      ticks.removeFirst()
    }

    if (ticks.size == sequence && ticksStep >= step) {
      if (
        configManager.isAiWorldGuardEnabled() &&
          regionProvider.isPlayerInDisabledRegion(oasisacPlayer.player)
      ) {
        debugManager.log(
          DebugCategory.WORLDGUARD,
          "Player ${oasisacPlayer.player.name} is in a disabled region. Skipping AI check.",
        )
        ticksStep = 0
        return
      }
      sendData()
      ticksStep = 0
    }
  }

  private fun sendData() {
    if (ticks.isEmpty() || !aiEnabled) {
      return
    }

    val oasisacPlayer = oasisacPlayer
    val count = ticks.size
    val snapshot = borrowSnapshot(count)
    var index = 0
    for (tick in ticks) {
      snapshot[index++] = tick
    }

    val player = oasisacPlayer.player
    val playerName = player.name

    scheduler.runAsync {
      try {
        @Suppress("UNCHECKED_CAST") val requestTicks = snapshot as Array<TickData>
        aiService
          .request(requestTicks, count)
          .thenAcceptAsync({ parsed -> onResponse(parsed) }) { runnable ->
            scheduler.runSync(player, runnable)
          }
          .exceptionally { error ->
            scheduler.runSync(player, Runnable { onError(error) })
            null
          }
      } catch (e: Exception) {
        plugin.logger.warning("[AiCheck] Failed to send data for $playerName: ${e.message}")
      } finally {
        releaseSnapshot(snapshot, count)
      }
    }
  }

  private fun onResponse(parsed: AiResult) {
    val oasisacPlayer = oasisacPlayer
    if (parsed.disabled) {
      lastProbability = 0.0
      damageProcessor.reset(oasisacPlayer)
      return
    }

    if (parsed.hasParseError()) {
      plugin.logger.warning(
        "[AiCheck] Error parsing API response: ${parsed.parseError?.message}. Response Body: ${parsed.raw}"
      )
      lastProbability = 0.0
      damageProcessor.reset(oasisacPlayer)
      return
    }

    val apiResponse = parsed.response

    if (apiResponse == null) {
      plugin.logger.warning(
        "[AiCheck] API response is missing probability. Response: ${parsed.raw}"
      )
      lastProbability = 0.0
      damageProcessor.reset(oasisacPlayer)
      return
    }

    val probability = apiResponse.probability
    lastProbability = probability
    damageProcessor.applyProbability(oasisacPlayer, probability)

    if (probability > 0.9) {
      prob90++
    }

    val oldBuffer = buffer

    if (probability > CHEAT_PROBABILITY) {
      buffer += (probability - CHEAT_PROBABILITY) * bufferMultiplier
    } else if (probability < LEGIT_PROBABILITY) {
      buffer = kotlin.math.max(0.0, buffer - bufferDecrease)
    }

    if (buffer > suspiciousAlertBuffer && oldBuffer <= suspiciousAlertBuffer) {
      alertManager.send(
        MessageUtil.getMessage(
          Message.SUSPICIOUS_ALERT_TRIGGERED,
          "player",
          oasisacPlayer.player.name,
          "buffer",
          formatAiBuffer(buffer),
        ),
        AlertType.SUSPICIOUS,
      )
    }

    if (debugManager.isEnabled(DebugCategory.AI_PROBABILITY)) {
      debugManager.log(
        DebugCategory.AI_PROBABILITY,
        buildAiProbabilityDebugMessage(
          playerName = oasisacPlayer.player.name,
          probability = probability,
          oldBuffer = oldBuffer,
          newBuffer = buffer,
          damageMultiplier = oasisacPlayer.combat.damageMultiplier,
        ),
      )
    }

    var flagged = false
    if (buffer > flag) {
      flagged = true
      flag(buildAiFlagDebug(probability, buffer))
      buffer = bufferResetOnFlag
    }

    oasisacPlayer.eventBus.post(
      AiPredictionEvent(
        oasisacPlayer.uuid,
        oasisacPlayer.player.name,
        checkName,
        probability,
        oldBuffer,
        buffer,
        oasisacPlayer.combat.damageMultiplier,
        prob90,
        flagged,
      )
    )
  }

  private fun onError(error: Throwable): Void? {
    lastProbability = 0.0
    val oasisacPlayer = oasisacPlayer
    damageProcessor.reset(oasisacPlayer)

    val cause = (error as? java.util.concurrent.CompletionException)?.cause ?: error

    val newSequence = (cause as? AiServiceException)?.newSequence
    if (newSequence != null) {
      if (newSequence < MIN_SEQUENCE) {
        plugin.logger.warning(
          "[AiCheck] Ignored invalid sequence length $newSequence (allowed: >= $MIN_SEQUENCE)"
        )
        return null
      }

      if (configManager.aiSequence != newSequence) {
        val oldSequence = configManager.aiSequence
        plugin.logger.info(
          "[AiCheck] Received new sequence length $newSequence (old: $oldSequence)"
        )
        configManager.aiSequence = newSequence
        ticks = ArrayDeque(newSequence)
      }
      return null
    }

    if (cause is AIServer.RequestException) {
      if (cause.code == AIServer.ResponseCode.WAITING) {
        return null
      }

      val logMessage =
        "[AiCheck] API Error ${cause.code} for player ${oasisacPlayer.player.name}: ${cause.message}"

      val transientCategory = transientCategoryFor(cause.code)
      if (transientCategory != null) {
        debugManager.log(transientCategory, logMessage)
      } else {
        plugin.logger.warning(logMessage)
      }
    } else {
      plugin.logger.warning(
        "[AiCheck] Unknown API Error for ${oasisacPlayer.player.name}: ${cause.message}"
      )
    }
    return null
  }

  private fun transientCategoryFor(code: AIServer.ResponseCode): DebugCategory? =
    when (code) {
      AIServer.ResponseCode.TIMEOUT -> DebugCategory.AI_API_TIMEOUT
      AIServer.ResponseCode.NETWORK_ERROR -> DebugCategory.AI_API_NETWORK
      AIServer.ResponseCode.RATE_LIMITED -> DebugCategory.AI_API_RATE_LIMITED
      AIServer.ResponseCode.SERVICE_UNAVAILABLE -> DebugCategory.AI_API_SERVICE_UNAVAILABLE
      else -> null
    }

  private fun borrowSnapshot(size: Int): Array<TickData?> {
    val buffer = snapshotBuffer.getAndSet(null)
    if (buffer == null || buffer.size < size) {
      return arrayOfNulls(size)
    }
    return buffer
  }

  private fun releaseSnapshot(buffer: Array<TickData?>, used: Int) {
    Arrays.fill(buffer, 0, used, null)
    snapshotBuffer.set(buffer)
  }

  companion object {
    private const val CHEAT_PROBABILITY = 0.90
    private const val LEGIT_PROBABILITY = 0.10
    private const val MIN_SEQUENCE = 1
  }
}
