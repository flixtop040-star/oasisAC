package me.oasisac.checks

interface ICheck {
  val checkName: String
}
