package me.oasisac.checks.impl.ai

import java.util.Locale
import java.util.logging.Logger
import kotlin.math.max
import kotlin.math.min
import me.oasisac.config.ConfigManager
import me.oasisac.database.DatabaseManager
import me.oasisac.debug.DebugCategory
import me.oasisac.debug.DebugManager
import me.oasisac.player.OasisPlayer
import me.oasisac.scheduler.SchedulerService

private const val MILLIS_PER_HOUR = 3_600_000.0

class PersistentBufferService(
  private val configManager: ConfigManager,
  private val databaseManager: DatabaseManager,
  private val scheduler: SchedulerService,
  private val debugManager: DebugManager,
  private val logger: Logger,
) {
  fun restoreOnLogin(oasisacPlayer: OasisPlayer) {
    if (!configManager.persistentBufferEnabled) return
    val aiCheck = oasisacPlayer.checkManager.getCheck(AiCheck::class.java) ?: return

    scheduler.runAsync {
      val state = databaseManager.database.loadAiBuffer(oasisacPlayer.uuid) ?: return@runAsync
      val now = System.currentTimeMillis()
      val ageMillis = now - state.updatedAt
      val playerName = oasisacPlayer.player.name

      if (ageMillis < 0L) {
        logger.warning(
          "[PersistentBuffer] Skipped restore for $playerName: stored timestamp is in the future"
        )
        return@runAsync
      }

      if (!oasisacPlayer.player.isOnline) return@runAsync

      if (ageMillis < configManager.persistentBufferDisconnectWindowMillis) {
        scheduler.runSync(oasisacPlayer.player) {
          if (oasisacPlayer.player.isOnline) aiCheck.restoreBuffer(state.buffer)
        }
        debugManager.log(
          DebugCategory.AI_PERSISTENT_BUFFER,
          "$playerName reconnected within disconnect window; buffer ${format(state.buffer)} kept",
        )
        return@runAsync
      }

      if (ageMillis > configManager.persistentBufferTtlMillis) {
        debugManager.log(
          DebugCategory.AI_PERSISTENT_BUFFER,
          "$playerName buffer expired (offline ${format(ageMillis / MILLIS_PER_HOUR)}h), discarded",
        )
        return@runAsync
      }

      val ageHours = ageMillis / MILLIS_PER_HOUR
      val decayed = state.buffer - configManager.persistentBufferDecayPerHour * ageHours
      val capped = min(decayed, configManager.persistentBufferCap)
      val finalBuffer = max(0.0, capped)

      scheduler.runSync(oasisacPlayer.player) {
        if (oasisacPlayer.player.isOnline) aiCheck.restoreBuffer(finalBuffer)
      }
      debugManager.log(
        DebugCategory.AI_PERSISTENT_BUFFER,
        "$playerName restored buffer ${format(state.buffer)} → ${format(finalBuffer)} (offline ${format(ageHours)}h)",
      )
    }
  }

  fun saveOnQuit(oasisacPlayer: OasisPlayer) {
    val buffer = bufferToPersist(oasisacPlayer) ?: return
    databaseManager.database.saveAiBuffer(oasisacPlayer.uuid, buffer, System.currentTimeMillis())
  }

  fun saveOnShutdown(oasisacPlayer: OasisPlayer) {
    saveOnQuit(oasisacPlayer)
  }

  private fun bufferToPersist(oasisacPlayer: OasisPlayer): Double? {
    val buffer = oasisacPlayer.checkManager.getCheck(AiCheck::class.java)?.buffer
    return when {
      !configManager.persistentBufferEnabled -> null
      buffer == null || buffer < configManager.persistentBufferSaveThreshold -> null
      else -> buffer
    }
  }

  private fun format(value: Double): String = String.format(Locale.US, "%.2f", value)
}
