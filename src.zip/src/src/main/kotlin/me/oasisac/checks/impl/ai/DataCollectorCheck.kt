package me.oasisac.checks.impl.ai

import com.github.retrooper.packetevents.event.PacketReceiveEvent
import com.github.retrooper.packetevents.wrapper.play.client.WrapperPlayClientPlayerFlying
import me.oasisac.OasisAC
import me.oasisac.checks.AbstractCheck
import me.oasisac.checks.CheckData
import me.oasisac.checks.CheckFactory
import me.oasisac.checks.type.PacketCheck
import me.oasisac.config.ConfigManager
import me.oasisac.data.DataSession
import me.oasisac.data.TickData
import me.oasisac.player.OasisPlayer

@CheckData(name = "DataCollector_Internal")
class DataCollectorCheck(
  oasisacPlayer: OasisPlayer,
  private val dataCollectorManager: DataCollectorManager,
  private val plugin: OasisAC,
  private val configManager: ConfigManager,
) : AbstractCheck(oasisacPlayer), PacketCheck {
  interface Factory : CheckFactory {
    override fun create(player: OasisPlayer): DataCollectorCheck
  }

  override fun onPacketReceive(event: PacketReceiveEvent) {
    val oasisacPlayer = oasisacPlayer
    val session: DataSession = dataCollectorManager.getSession(oasisacPlayer.uuid) ?: return
    if (WrapperPlayClientPlayerFlying.isFlying(event.packetType)) {
      if (
        oasisacPlayer.packetStateData.lastPacketWasTeleport ||
          oasisacPlayer.packetStateData.lastPacketWasServerRotation
      ) {
        plugin.logger.info(
          "Skipping server-side rotation packet in data collection for player: ${oasisacPlayer.player.name}"
        )
        return
      }

      if (
        configManager.aiContinuous ||
          oasisacPlayer.combat.ticksSinceAttack < configManager.aiSequence
      ) {
        session.addTick(TickData(oasisacPlayer))
      }
    }
  }
}
