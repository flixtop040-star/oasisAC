package me.oasisac.checks.type

import com.github.retrooper.packetevents.event.PacketReceiveEvent
import me.oasisac.checks.ICheck

interface PacketCheck : ICheck {
  fun onPacketReceive(event: PacketReceiveEvent) {}
}
