package me.oasisac.checks

import me.oasisac.player.OasisPlayer

fun interface CheckFactory {
  fun create(player: OasisPlayer): ICheck
}
