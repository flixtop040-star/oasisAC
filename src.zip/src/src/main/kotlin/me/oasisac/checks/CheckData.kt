package me.oasisac.checks

@Retention(AnnotationRetention.RUNTIME)
@Target(AnnotationTarget.CLASS)
annotation class CheckData(val name: String, val configName: String = "DEFAULT")
