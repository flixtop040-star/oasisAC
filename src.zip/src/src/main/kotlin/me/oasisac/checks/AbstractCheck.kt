package me.oasisac.checks

import me.oasisac.api.event.CheckFlagEvent
import me.oasisac.player.OasisPlayer

abstract class AbstractCheck(protected val oasisacPlayer: OasisPlayer) : ICheck {
  private val checkNameInternal: String
  val configName: String

  override val checkName: String
    get() = checkNameInternal

  init {
    val data = javaClass.getAnnotation(CheckData::class.java)
    checkNameInternal = data.name
    configName = if (data.configName == "DEFAULT") data.name else data.configName
  }

  protected fun flag(debug: String) {
    val event =
      CheckFlagEvent(oasisacPlayer.uuid, oasisacPlayer.player.name, checkName, configName, debug)
    oasisacPlayer.eventBus.post(event)
    if (event.cancelled) {
      return
    }
    oasisacPlayer.punishmentManager.handleFlag(this, debug)
  }
}
