package me.oasisac.monitor

import com.github.retrooper.packetevents.event.PacketListenerAbstract
import com.github.retrooper.packetevents.event.PacketListenerPriority
import com.github.retrooper.packetevents.event.PacketSendEvent
import com.github.retrooper.packetevents.protocol.packettype.PacketType
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerDisplayScoreboard
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerScoreboardObjective
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerTeams
import java.util.UUID
import me.oasisac.scheduler.SchedulerService
import org.bukkit.entity.Player

internal class ViewConflictObserver(
  private val scheduler: SchedulerService,
  private val coordinator: ViewSessionCoordinator,
  private val belowNameConflicts: ViewBelowNameConflictCoordinator,
  private val viewerResolver: (UUID) -> Player?,
) : PacketListenerAbstract(PacketListenerPriority.MONITOR) {
  override fun onPacketSend(event: PacketSendEvent) {
    val viewer = event.getPlayer<Any>() as? Player ?: return
    val session = coordinator.session(viewer.uniqueId) ?: return

    when (event.packetType) {
      PacketType.Play.Server.DISPLAY_SCOREBOARD -> observeDisplayScoreboard(event, viewer, session)
      PacketType.Play.Server.SCOREBOARD_OBJECTIVE ->
        observeScoreboardObjective(event, viewer, session)
      PacketType.Play.Server.TEAMS -> observeTeams(event, session)
    }
  }

  private fun observeDisplayScoreboard(
    event: PacketSendEvent,
    viewer: Player,
    session: ViewSession,
  ) {
    if (session.usesBelowName()) {
      val objectiveName = session.belowObjectiveName
      if (objectiveName != null) {
        val wrapper = WrapperPlayServerDisplayScoreboard(event)
        val shouldReassert =
          wrapper.position == BELOW_NAME_DISPLAY_SLOT &&
            wrapper.scoreName.isNotBlank() &&
            wrapper.scoreName != objectiveName
        if (shouldReassert) {
          event.tasksAfterSend.add(
            Runnable {
              scheduler.runSync(
                viewer,
                Runnable {
                  belowNameConflicts.reassertDisplay(
                    viewer.uniqueId,
                    wrapper.scoreName,
                    viewerResolver,
                  )
                },
              )
            }
          )
        }
      }
    }
  }

  private fun observeScoreboardObjective(
    event: PacketSendEvent,
    viewer: Player,
    session: ViewSession,
  ) {
    if (session.usesBelowName()) {
      val objectiveName = session.belowObjectiveName
      if (objectiveName != null) {
        val wrapper = WrapperPlayServerScoreboardObjective(event)
        val shouldRecreate =
          wrapper.name == objectiveName &&
            wrapper.mode == WrapperPlayServerScoreboardObjective.ObjectiveMode.REMOVE
        if (shouldRecreate) {
          event.tasksAfterSend.add(
            Runnable {
              scheduler.runSync(
                viewer,
                Runnable {
                  belowNameConflicts.recreateObjective(
                    viewer.uniqueId,
                    objectiveName,
                    viewerResolver,
                  )
                },
              )
            }
          )
        }
      }
    }
  }

  private fun observeTeams(event: PacketSendEvent, session: ViewSession) {
    if (session.placement != ViewPlacement.ABOVE_NAME) {
      return
    }

    val wrapper = WrapperPlayServerTeams(event)
    if (wrapper.teamName.startsWith("slv_")) {
      return
    }

    when (wrapper.teamMode) {
      WrapperPlayServerTeams.TeamMode.CREATE,
      WrapperPlayServerTeams.TeamMode.ADD_ENTITIES -> {
        for (playerName in wrapper.players) {
          val targetId = session.targetIdByName(playerName) ?: continue
          session.targetTeams[targetId]?.markRebindNeeded()
        }
      }
      else -> Unit
    }
  }
}
