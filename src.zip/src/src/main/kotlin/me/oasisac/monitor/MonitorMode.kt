package me.oasisac.monitor

import java.util.Locale

enum class MonitorMode {
  COMPACT,
  FULL;

  companion object {
    @JvmStatic
    fun fromConfig(value: String?): MonitorMode {
      if (value == null) {
        return COMPACT
      }
      return try {
        valueOf(value.trim().uppercase(Locale.ROOT))
      } catch (e: IllegalArgumentException) {
        COMPACT
      }
    }
  }
}
