package me.oasisac.monitor

import com.github.retrooper.packetevents.PacketEvents
import java.util.UUID
import me.oasisac.OasisAC
import me.oasisac.config.ConfigManager
import me.oasisac.player.PlayerDataManager
import me.oasisac.scheduler.SchedulerService
import org.bukkit.Bukkit
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerQuitEvent
import org.bukkit.event.server.PluginDisableEvent

class MonitorViewService(
  private val plugin: OasisAC,
  playerDataManager: PlayerDataManager,
  private val configManager: ConfigManager,
  scheduler: SchedulerService,
) : Listener {
  private val coordinator = ViewSessionCoordinator(plugin, playerDataManager, scheduler)
  private val trackingObserver =
    ViewTrackingObserver(scheduler, coordinator) { viewerId ->
      resolveActiveViewViewer(viewerId, coordinator)
    }
  private val conflictObserver =
    ViewConflictObserver(scheduler, coordinator, coordinator.belowNameConflicts) { viewerId ->
      resolveActiveViewViewer(viewerId, coordinator)
    }

  @Volatile private var runtimeConfig = ViewRuntimeConfig.from(configManager.monitorConfig)
  private var packetHooksRegistered = false

  init {
    plugin.server.pluginManager.registerEvents(this, plugin)
  }

  fun start() {
    if (packetHooksRegistered) {
      return
    }
    PacketEvents.getAPI().eventManager.registerListener(trackingObserver)
    PacketEvents.getAPI().eventManager.registerListener(conflictObserver)
    packetHooksRegistered = true
  }

  fun toggle(viewer: Player): Boolean {
    val viewerId = viewer.uniqueId
    return if (coordinator.session(viewerId) != null) {
      coordinator.disable(viewerId, viewer)
      false
    } else {
      enable(viewer)
      true
    }
  }

  fun enable(viewer: Player) {
    coordinator.enable(viewer, runtimeConfig)
  }

  fun reload() {
    runtimeConfig = ViewRuntimeConfig.from(configManager.monitorConfig)
    coordinator.reload(runtimeConfig)
  }

  @EventHandler
  fun onPlayerQuit(event: PlayerQuitEvent) {
    val left = event.player
    coordinator.disable(left.uniqueId, left)
    coordinator.removeTargetFromAllSessions(left.uniqueId, left.name)
  }

  @EventHandler
  fun onPluginDisable(event: PluginDisableEvent) {
    if (event.plugin !== plugin) {
      return
    }
    for (viewerId in coordinator.activeViewerIds) {
      coordinator.disable(viewerId, Bukkit.getPlayer(viewerId))
    }
  }
}

internal const val VIEW_PERMISSION = "oasisac.view"

internal fun isTrackableViewTarget(viewer: Player, target: Player): Boolean {
  return target.isOnline && viewer.world.uid == target.world.uid && viewer.canSee(target)
}

private fun resolveActiveViewViewer(viewerId: UUID, coordinator: ViewSessionCoordinator): Player? {
  val viewer = Bukkit.getPlayer(viewerId)
  return when {
    viewer == null || !viewer.isOnline -> {
      coordinator.disable(viewerId, null)
      null
    }
    !viewer.hasPermission(VIEW_PERMISSION) -> {
      coordinator.disable(viewerId, viewer)
      null
    }
    else -> viewer
  }
}
