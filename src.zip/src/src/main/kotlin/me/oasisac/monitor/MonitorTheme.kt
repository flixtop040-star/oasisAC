package me.oasisac.monitor

import java.util.Locale

enum class MonitorTheme {
  CALM,
  VIVID,
  MINIMAL;

  companion object {
    @JvmStatic
    fun fromConfig(value: String?): MonitorTheme {
      if (value == null) {
        return CALM
      }
      return try {
        valueOf(value.trim().uppercase(Locale.ROOT))
      } catch (e: IllegalArgumentException) {
        CALM
      }
    }
  }
}
