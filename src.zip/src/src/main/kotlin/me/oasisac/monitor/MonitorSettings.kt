package me.oasisac.monitor

data class MonitorSettings(
  var mode: MonitorMode,
  var theme: MonitorTheme,
  var showPing: Boolean,
  var showDmg: Boolean,
  var showTrend: Boolean,
  var showName: MonitorNameMode,
)
