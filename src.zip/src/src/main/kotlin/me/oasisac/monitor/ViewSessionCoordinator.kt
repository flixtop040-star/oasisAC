package me.oasisac.monitor

import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import me.oasisac.OasisAC
import me.oasisac.player.PlayerDataManager
import me.oasisac.scheduler.SchedulerService
import org.bukkit.Bukkit
import org.bukkit.entity.Player

internal class ViewSessionCoordinator(
  private val plugin: OasisAC,
  playerDataManager: PlayerDataManager,
  private val scheduler: SchedulerService,
) {
  private val sessions = ConcurrentHashMap<UUID, ViewSession>()
  private val componentCache = ViewComponentCache()
  private val teamBridge = ViewTeamPacketBridge(componentCache)
  private val belowNameBridge = ViewBelowNamePacketBridge(componentCache)
  private val tracker =
    ViewTargetTracker(ViewTagRenderer(playerDataManager), teamBridge, belowNameBridge)
  internal val belowNameConflicts =
    ViewBelowNameConflictCoordinator(plugin, tracker, belowNameBridge) { viewerId ->
      sessions[viewerId]
    }

  fun session(viewerId: UUID): ViewSession? = sessions[viewerId]

  val activeViewerIds: List<UUID>
    get() = sessions.keys.toList()

  fun enable(viewer: Player, config: ViewRuntimeConfig) {
    val viewerId = viewer.uniqueId
    if (sessions.containsKey(viewerId)) {
      return
    }

    val objectiveName =
      if (config.placement == ViewPlacement.BELOW_NAME) {
        objectiveNameForViewer(viewerId)
      } else {
        null
      }

    val session = ViewSession(config, config.placement, objectiveName)
    sessions[viewerId] = session

    if (session.usesBelowName()) {
      belowNameBridge.createObjective(
        viewer,
        objectiveName!!,
        config.belowTitle,
        config.defaultBelowText,
      )
    }

    tracker.bootstrapTrackedTargets(viewer, session)
    tracker.refreshTrackedTargets(viewer, session)
    session.task =
      scheduler.runTimer(
        viewer,
        Runnable { refreshViewer(viewerId, ::resolveViewSessionViewer) },
        1L,
        config.updateTicks,
      )
  }

  fun reload(config: ViewRuntimeConfig) {
    for (viewerId in activeViewerIds) {
      val viewer = Bukkit.getPlayer(viewerId)
      disable(viewerId, viewer)
      if (viewer != null && viewer.isOnline && viewer.hasPermission(VIEW_PERMISSION)) {
        enable(viewer, config)
      }
    }
  }

  fun refreshViewer(viewerId: UUID, viewerResolver: (UUID) -> Player?) {
    val session = sessions[viewerId] ?: return
    val viewer = viewerResolver(viewerId) ?: return

    if (session.shouldResync()) {
      tracker.resyncTrackedTargets(viewer, session)
    }
    tracker.refreshTrackedTargets(viewer, session)
  }

  fun trackTarget(viewerId: UUID, target: Player) {
    val session = sessions[viewerId] ?: return
    tracker.trackTarget(session, target)
  }

  fun removeTrackedTarget(viewerId: UUID, targetId: UUID, fallbackTargetName: String?) {
    val session = sessions[viewerId] ?: return
    val viewer = resolveViewSessionViewer(viewerId) ?: return
    tracker.removeTrackedTarget(viewer, session, targetId, fallbackTargetName)
  }

  fun removeTrackedEntities(viewerId: UUID, entityIds: IntArray) {
    val session = sessions[viewerId] ?: return
    val viewer = resolveViewSessionViewer(viewerId) ?: return
    for (entityId in entityIds) {
      val targetId = session.targetIdByEntityId(entityId) ?: continue
      tracker.removeTrackedTarget(viewer, session, targetId, session.targetNameFor(targetId))
    }
  }

  fun removeTargetFromAllSessions(targetId: UUID, targetName: String) {
    for ((viewerId, session) in sessions.entries) {
      val viewer = Bukkit.getPlayer(viewerId)
      if (viewer != null && viewer.isOnline) {
        tracker.removeTrackedTarget(viewer, session, targetId, targetName)
      } else {
        tracker.dropTrackedTarget(session, targetId, targetName)
      }
    }
  }

  fun disable(viewerId: UUID, viewerHint: Player?) {
    val session = sessions.remove(viewerId) ?: return
    session.task?.cancel()

    val viewer = viewerHint ?: Bukkit.getPlayer(viewerId)
    if (viewer != null && viewer.isOnline) {
      if (session.usesBelowName()) {
        session.belowObjectiveName?.let { belowNameBridge.removeObjective(viewer, it) }
      } else {
        tracker.clearTrackedTargets(viewer, session)
      }
    }

    session.clearTargets()
  }
}

private fun resolveViewSessionViewer(viewerId: UUID): Player? = Bukkit.getPlayer(viewerId)
