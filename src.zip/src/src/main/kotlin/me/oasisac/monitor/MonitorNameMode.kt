package me.oasisac.monitor

import java.util.Locale

enum class MonitorNameMode {
  AUTO,
  ALWAYS,
  NEVER;

  companion object {
    @JvmStatic
    fun fromConfig(value: String?): MonitorNameMode {
      if (value == null) {
        return AUTO
      }
      return try {
        valueOf(value.trim().uppercase(Locale.ROOT))
      } catch (ex: IllegalArgumentException) {
        AUTO
      }
    }
  }
}
