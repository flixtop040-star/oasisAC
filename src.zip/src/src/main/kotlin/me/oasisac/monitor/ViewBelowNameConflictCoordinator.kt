package me.oasisac.monitor

import java.util.UUID
import me.oasisac.OasisAC
import org.bukkit.entity.Player

internal class ViewBelowNameConflictCoordinator(
  private val plugin: OasisAC,
  private val tracker: ViewTargetTracker,
  private val belowNameBridge: ViewBelowNamePacketBridge,
  private val sessionProvider: (UUID) -> ViewSession?,
) {
  fun reassertDisplay(
    viewerId: UUID,
    conflictingObjective: String,
    viewerResolver: (UUID) -> Player?,
  ) {
    val session = sessionProvider(viewerId)?.takeIf(ViewSession::usesBelowName)
    val viewer = viewerResolver(viewerId)
    val objectiveName = session?.belowObjectiveName
    if (session != null && viewer != null && objectiveName != null) {
      logFirstConflict(session, viewer, conflictingObjective)
      belowNameBridge.displayObjective(viewer, objectiveName)
      tracker.refreshTrackedTargets(viewer, session)
    }
  }

  fun recreateObjective(viewerId: UUID, objectiveName: String, viewerResolver: (UUID) -> Player?) {
    val session = sessionProvider(viewerId)
    val viewer = viewerResolver(viewerId)
    val shouldRecreate =
      session != null && session.usesBelowName() && session.belowObjectiveName == objectiveName

    if (shouldRecreate && viewer != null) {
      session.targetTeams.values.forEach(TargetTeamState::invalidateBelowName)
      belowNameBridge.createObjective(
        viewer,
        objectiveName,
        session.config.belowTitle,
        session.config.defaultBelowText,
      )
      tracker.refreshTrackedTargets(viewer, session)
    }
  }

  private fun logFirstConflict(session: ViewSession, viewer: Player, conflictingObjective: String) {
    if (session.belowNameConflictLogged) {
      return
    }

    plugin.logger.warning(
      "[View] Viewer ${viewer.name} reasserted Oasis below-name display after " +
        "'$conflictingObjective' attempted to claim the slot."
    )
    session.belowNameConflictLogged = true
  }
}
