package me.oasisac.monitor

import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt
import me.oasisac.checks.impl.ai.AiCheck
import me.oasisac.player.PlayerDataManager
import org.bukkit.entity.Player

internal class ViewTagRenderer(private val playerDataManager: PlayerDataManager) {
  fun render(target: Player, state: TargetTeamState, config: ViewRuntimeConfig): RenderedTag {
    val oasisacTarget = playerDataManager.getPlayer(target)
    if (oasisacTarget == null) {
      val fallbackValues =
        mapOf(
          "prob" to config.fallbackProb,
          "buffer" to config.fallbackBuffer,
          "ping" to state.resolvePingDisplay(target.ping, config),
        )
      return RenderedTag(
        applyTemplate(config.prefixTemplate, fallbackValues),
        applyTemplate(config.suffixTemplate, fallbackValues),
        applyTemplate(config.belowTemplate, fallbackValues),
        ZERO_BELOW_SCORE,
      )
    }
    val aiCheck = oasisacTarget.checkManager.getCheck(AiCheck::class.java)

    val probabilityValue =
      if (aiCheck == null) {
        config.fallbackProb
      } else {
        formatDecimal(aiCheck.lastProbability * PERCENT_MULTIPLIER, config.probDecimals)
      }
    val belowScore =
      if (aiCheck == null) {
        ZERO_BELOW_SCORE
      } else {
        (aiCheck.lastProbability * PERCENT_MULTIPLIER).roundToInt().coerceAtLeast(ZERO_BELOW_SCORE)
      }

    val bufferValue =
      if (aiCheck == null) {
        config.fallbackBuffer
      } else {
        formatDecimal(aiCheck.buffer, config.bufferDecimals)
      }

    val values =
      mapOf(
        "prob" to probabilityValue,
        "buffer" to bufferValue,
        "ping" to state.resolvePingDisplay(target.ping, config),
      )

    return RenderedTag(
      applyTemplate(config.prefixTemplate, values),
      applyTemplate(config.suffixTemplate, values),
      applyTemplate(config.belowTemplate, values),
      belowScore,
    )
  }

  private fun applyTemplate(template: String, values: Map<String, String>): String {
    return renderViewTemplate(template, values)
  }

  private fun formatDecimal(value: Double, decimals: Int): String {
    val safeDecimals = decimals.coerceAtLeast(0)
    val normalized = if (abs(value) < DECIMAL_EPSILON) 0.0 else value
    return String.format(Locale.US, "%.${safeDecimals}f", normalized)
  }

  private companion object {
    const val ZERO_BELOW_SCORE = 0
    const val PERCENT_MULTIPLIER = 100.0
    const val DECIMAL_EPSILON = 0.0000001
  }
}
