package me.oasisac.config

import java.io.File
import me.oasisac.OasisAC
import me.oasisac.utils.Message
import org.spongepowered.configurate.CommentedConfigurationNode
import org.spongepowered.configurate.ConfigurationNode
import org.spongepowered.configurate.serialize.SerializationException
import org.spongepowered.configurate.yaml.YamlConfigurationLoader

class LocaleManager(private val plugin: OasisAC, private val configManager: ConfigManager) {
  private var messagesConfig: ConfigView = ConfigView(CommentedConfigurationNode.root())
  private var defaultMessages: ConfigView? = null

  init {
    reload()
  }

  fun reload() {
    val locale = configManager.config.getString("locale", "en")
    val messagesDir = File(plugin.dataFolder, "messages")
    if (!messagesDir.exists()) {
      messagesDir.mkdirs()
    }

    saveDefaultLocale("en")
    if (!"en".equals(locale, ignoreCase = true)) {
      saveDefaultLocale(locale)
    }

    var messagesFile = File(messagesDir, "messages_$locale.yml")
    if (!messagesFile.exists()) {
      plugin.logger.warning("Locale $locale not found.")
      messagesFile = File(messagesDir, "messages_en.yml")
    }

    messagesConfig = loadMessages(messagesFile)
    defaultMessages = loadDefaultsFromJar("messages/messages_en.yml")
  }

  private fun saveDefaultLocale(locale: String) {
    val dir = File(plugin.dataFolder, "messages")
    val file = File(dir, "messages_$locale.yml")
    if (!file.exists()) {
      plugin.saveResource("messages/messages_$locale.yml", false)
    }
  }

  private fun loadDefaultsFromJar(resourcePath: String): ConfigView? {
    val resource = plugin.getResource(resourcePath) ?: return null
    return try {
      val node =
        YamlConfigurationLoader.builder().source { resource.bufferedReader() }.build().load()
      ConfigView(node)
    } catch (e: java.io.IOException) {
      plugin.logger.warning("Failed to load default locale from JAR ($resourcePath): ${e.message}")
      null
    }
  }

  fun getRawMessage(key: Message): String {
    val node = resolveNode(key)
    return node.getString("Missing message: ${key.path}")
  }

  fun getRawMessageList(key: Message): List<String> {
    val node = resolveNode(key)
    return try {
      node.getList(String::class.java) ?: emptyList()
    } catch (_: SerializationException) {
      emptyList()
    }
  }

  private fun loadMessages(file: File): ConfigView {
    return try {
      val loader = YamlConfigurationLoader.builder().path(file.toPath()).build()
      ConfigView(loader.load())
    } catch (_: Exception) {
      plugin.logger.warning("Failed to load locale file ${file.name}")
      ConfigView(CommentedConfigurationNode.root())
    }
  }

  private fun resolveNode(key: Message): ConfigurationNode {
    val path = key.path
    val node = messagesConfig.node(path)
    if (node.empty() && defaultMessages != null) {
      return defaultMessages!!.node(path)
    }
    return node
  }
}
