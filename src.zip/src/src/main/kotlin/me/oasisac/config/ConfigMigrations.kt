package me.oasisac.config

import java.io.File

internal object ConfigMigrations {
  const val LATEST_VERSION = 1

  private val VERSION_RE = Regex("""^\s*config-version:\s*(\d+)""", RegexOption.MULTILINE)

  fun readVersion(file: File): Int {
    val text = runCatching { file.readText(Charsets.UTF_8) }.getOrNull() ?: return LATEST_VERSION
    return VERSION_RE.find(text)?.groupValues?.get(1)?.toIntOrNull() ?: 0
  }

  // yaml-config-updater uses `/` as the path separator because `.` is valid inside key names.
  fun forcedDropsForUpgradeFrom(currentVersion: Int): List<String> {
    if (currentVersion >= LATEST_VERSION) return emptyList()
    val drops = mutableListOf("config-version")
    // if (currentVersion < 2) drops += "ai/legacy-path"
    return drops
  }
}
