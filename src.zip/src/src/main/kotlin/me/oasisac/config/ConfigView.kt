package me.oasisac.config

import org.spongepowered.configurate.CommentedConfigurationNode
import org.spongepowered.configurate.ConfigurationNode
import org.spongepowered.configurate.serialize.SerializationException

class ConfigView(private val rootNode: CommentedConfigurationNode) {
  fun node(path: String): ConfigurationNode = rootNode.node(*path.split('.').toTypedArray())

  fun root(): CommentedConfigurationNode = rootNode

  fun getString(path: String, def: String): String = node(path).getString(def)

  fun getBoolean(path: String, def: Boolean): Boolean = node(path).getBoolean(def)

  fun getInt(path: String, def: Int): Int = node(path).getInt(def)

  fun getLong(path: String, def: Long): Long = node(path).getLong(def)

  fun getDouble(path: String, def: Double): Double = node(path).getDouble(def)

  fun getStringList(path: String): List<String> {
    return try {
      node(path).getList(String::class.java) ?: emptyList()
    } catch (ex: SerializationException) {
      emptyList()
    }
  }

  fun getStringListMap(path: String): Map<String, List<String>> {
    val sectionNode = node(path)
    if (sectionNode.virtual() || !sectionNode.isMap) return emptyMap()
    val result = mutableMapOf<String, List<String>>()
    for ((key, child) in sectionNode.childrenMap()) {
      val keyStr = key.toString()
      val list =
        try {
          child.getList(String::class.java) ?: emptyList()
        } catch (ex: SerializationException) {
          emptyList()
        }
      result[keyStr] = list
    }
    return result
  }
}
