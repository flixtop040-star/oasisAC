package me.oasisac.damage

import kotlin.math.min
import me.oasisac.config.ConfigManager
import me.oasisac.player.OasisPlayer

class AiDamageProcessor(private val configManager: ConfigManager) : DamageProcessor {
  override fun reset(oasisacPlayer: OasisPlayer) {
    oasisacPlayer.combat.damageMultiplier = 1.0
  }

  override fun applyProbability(oasisacPlayer: OasisPlayer, probability: Double) {
    if (!configManager.isAiDamageReductionEnabled()) {
      oasisacPlayer.combat.damageMultiplier = 1.0
      return
    }

    oasisacPlayer.combat.damageMultiplier =
      computeMultiplier(
        probability,
        configManager.aiDamageReductionProb,
        configManager.aiDamageReductionMultiplier,
      )
  }

  companion object {
    internal fun computeMultiplier(
      probability: Double,
      threshold: Double,
      multiplier: Double,
    ): Double {
      if (probability < threshold) return 1.0
      val ratio = (probability - threshold) / (1.0 - threshold)
      val reduction = min(1.0, ratio * multiplier)
      return 1.0 - reduction
    }
  }
}
