package me.oasisac.damage

import me.oasisac.player.OasisPlayer

interface DamageProcessor {
  fun reset(oasisacPlayer: OasisPlayer)

  fun applyProbability(oasisacPlayer: OasisPlayer, probability: Double)
}
