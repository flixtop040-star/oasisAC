package me.oasisac

import java.util.logging.Level
import me.oasisac.di.oasisacModules
import me.oasisac.integration.OasisFlags
import org.bstats.bukkit.Metrics
import org.bukkit.plugin.java.JavaPlugin
import org.koin.core.context.startKoin
import org.koin.core.context.stopKoin

class OasisAC : JavaPlugin() {
  private var core: OasisCore? = null
  private val packetEventsLoader = PacketEventsLoader(this)
  private var packetEventsLoadFailure: Throwable? = null
  private var runtimeStopped = false

  override fun onLoad() {
    packetEventsLoadFailure = runCatching { packetEventsLoader.load() }.exceptionOrNull()
    runCatching { OasisFlags.register(logger) }
      .onFailure { logger.log(Level.WARNING, "Failed to register WorldGuard flags", it) }
  }

  override fun onEnable() {
    runtimeStopped = false
    packetEventsLoadFailure?.let { failure ->
      handleEnableFailure(failure)
      return
    }

    runCatching(::enableRuntime).onFailure(::handleEnableFailure)
  }

  override fun onDisable() {
    shutdownRuntime()
  }

  fun onReload() {
    core?.reload()
  }

  private companion object {
    const val BSTATS_PLUGIN_ID = 30367
  }

  private fun enableRuntime() {
    val koinApp = startKoin { modules(oasisacModules(this@OasisAC)) }
    core = koinApp.koin.get()
    core?.enable()
    Metrics(this, BSTATS_PLUGIN_ID)
  }

  private fun handleEnableFailure(failure: Throwable) {
    logger.log(Level.SEVERE, "Oasis failed to start and will disable itself safely.", failure)
    shutdownRuntime()
    server.pluginManager.disablePlugin(this)
  }

  private fun shutdownRuntime() {
    if (runtimeStopped) {
      return
    }
    runtimeStopped = true

    runCatching { core?.disable() }
    core = null
    runCatching { stopKoin() }
    packetEventsLoader.shutdown()
  }
}
