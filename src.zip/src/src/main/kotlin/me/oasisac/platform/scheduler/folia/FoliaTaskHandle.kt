package me.oasisac.platform.scheduler.folia

import io.papermc.paper.threadedregions.scheduler.ScheduledTask
import me.oasisac.platform.scheduler.TaskHandle

class FoliaTaskHandle(private val task: ScheduledTask) : TaskHandle {
  override fun isSync(): Boolean = false

  override fun isCancelled(): Boolean = task.isCancelled

  override fun cancel() {
    task.cancel()
  }
}
