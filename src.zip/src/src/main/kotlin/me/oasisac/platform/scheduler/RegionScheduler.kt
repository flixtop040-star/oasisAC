package me.oasisac.platform.scheduler

import org.bukkit.Location
import org.bukkit.World
import org.bukkit.plugin.Plugin

/** Represents a scheduler for executing region tasks. */
interface RegionScheduler {
  fun execute(plugin: Plugin, world: World, chunkX: Int, chunkZ: Int, task: Runnable)

  fun execute(plugin: Plugin, location: Location, task: Runnable)

  fun run(plugin: Plugin, world: World, chunkX: Int, chunkZ: Int, task: Runnable): TaskHandle

  fun run(plugin: Plugin, location: Location, task: Runnable): TaskHandle

  fun runDelayed(
    plugin: Plugin,
    world: World,
    chunkX: Int,
    chunkZ: Int,
    task: Runnable,
    delayTicks: Long,
  ): TaskHandle

  fun runDelayed(plugin: Plugin, location: Location, task: Runnable, delayTicks: Long): TaskHandle

  fun runAtFixedRate(
    plugin: Plugin,
    world: World,
    chunkX: Int,
    chunkZ: Int,
    task: Runnable,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle

  fun runAtFixedRate(
    plugin: Plugin,
    location: Location,
    task: Runnable,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle
}
