package me.oasisac.platform.scheduler.folia

import io.papermc.paper.threadedregions.scheduler.AsyncScheduler
import java.util.concurrent.TimeUnit
import me.oasisac.platform.scheduler.AsyncScheduler as OasisAsyncScheduler
import me.oasisac.platform.scheduler.PlatformScheduler
import me.oasisac.platform.scheduler.TaskHandle
import org.bukkit.Bukkit
import org.bukkit.plugin.Plugin

class FoliaAsyncScheduler : OasisAsyncScheduler {
  private val scheduler: AsyncScheduler = Bukkit.getAsyncScheduler()

  override fun runNow(plugin: Plugin, task: Runnable): TaskHandle {
    return FoliaTaskHandle(scheduler.runNow(plugin) { task.run() })
  }

  override fun runDelayed(
    plugin: Plugin,
    task: Runnable,
    delay: Long,
    timeUnit: TimeUnit,
  ): TaskHandle {
    return FoliaTaskHandle(scheduler.runDelayed(plugin, { task.run() }, delay, timeUnit))
  }

  override fun runAtFixedRate(
    plugin: Plugin,
    task: Runnable,
    delay: Long,
    period: Long,
    timeUnit: TimeUnit,
  ): TaskHandle {
    return FoliaTaskHandle(
      scheduler.runAtFixedRate(plugin, { task.run() }, delay, period, timeUnit)
    )
  }

  override fun runAtFixedRate(
    plugin: Plugin,
    task: Runnable,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle {
    val initialDelayMillis =
      PlatformScheduler.convertTicksToTime(initialDelayTicks, TimeUnit.MILLISECONDS)
    val periodMillis = PlatformScheduler.convertTicksToTime(periodTicks, TimeUnit.MILLISECONDS)
    return FoliaTaskHandle(
      scheduler.runAtFixedRate(
        plugin,
        { task.run() },
        initialDelayMillis,
        periodMillis,
        TimeUnit.MILLISECONDS,
      )
    )
  }

  override fun cancel(plugin: Plugin) {
    scheduler.cancelTasks(plugin)
  }
}
