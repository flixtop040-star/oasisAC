package me.oasisac.platform.scheduler

import java.util.concurrent.TimeUnit
import org.bukkit.plugin.Plugin

/** Represents a scheduler for executing tasks asynchronously. */
interface AsyncScheduler {
  fun runNow(plugin: Plugin, task: Runnable): TaskHandle

  fun runDelayed(plugin: Plugin, task: Runnable, delay: Long, timeUnit: TimeUnit): TaskHandle

  fun runAtFixedRate(
    plugin: Plugin,
    task: Runnable,
    delay: Long,
    period: Long,
    timeUnit: TimeUnit,
  ): TaskHandle

  fun runAtFixedRate(
    plugin: Plugin,
    task: Runnable,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle

  fun cancel(plugin: Plugin)
}
