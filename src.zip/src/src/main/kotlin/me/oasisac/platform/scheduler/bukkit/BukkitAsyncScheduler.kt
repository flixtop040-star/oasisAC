package me.oasisac.platform.scheduler.bukkit

import java.util.concurrent.TimeUnit
import me.oasisac.platform.scheduler.AsyncScheduler
import me.oasisac.platform.scheduler.PlatformScheduler
import me.oasisac.platform.scheduler.TaskHandle
import org.bukkit.Bukkit
import org.bukkit.plugin.Plugin

class BukkitAsyncScheduler : AsyncScheduler {
  private val bukkitScheduler = Bukkit.getScheduler()

  override fun runNow(plugin: Plugin, task: Runnable): TaskHandle {
    return BukkitTaskHandle(bukkitScheduler.runTaskAsynchronously(plugin, task))
  }

  override fun runDelayed(
    plugin: Plugin,
    task: Runnable,
    delay: Long,
    timeUnit: TimeUnit,
  ): TaskHandle {
    return BukkitTaskHandle(
      bukkitScheduler.runTaskLaterAsynchronously(
        plugin,
        task,
        PlatformScheduler.convertTimeToTicks(delay, timeUnit),
      )
    )
  }

  override fun runAtFixedRate(
    plugin: Plugin,
    task: Runnable,
    delay: Long,
    period: Long,
    timeUnit: TimeUnit,
  ): TaskHandle {
    return BukkitTaskHandle(
      bukkitScheduler.runTaskTimerAsynchronously(
        plugin,
        task,
        PlatformScheduler.convertTimeToTicks(delay, timeUnit),
        PlatformScheduler.convertTimeToTicks(period, timeUnit),
      )
    )
  }

  override fun runAtFixedRate(
    plugin: Plugin,
    task: Runnable,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle {
    return BukkitTaskHandle(
      bukkitScheduler.runTaskTimerAsynchronously(plugin, task, initialDelayTicks, periodTicks)
    )
  }

  override fun cancel(plugin: Plugin) {
    bukkitScheduler.cancelTasks(plugin)
  }
}
