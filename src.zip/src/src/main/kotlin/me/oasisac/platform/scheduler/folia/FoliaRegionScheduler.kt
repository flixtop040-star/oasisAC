package me.oasisac.platform.scheduler.folia

import io.papermc.paper.threadedregions.scheduler.RegionScheduler
import me.oasisac.platform.scheduler.RegionScheduler as OasisRegionScheduler
import me.oasisac.platform.scheduler.TaskHandle
import org.bukkit.Bukkit
import org.bukkit.Location
import org.bukkit.World
import org.bukkit.plugin.Plugin

class FoliaRegionScheduler : OasisRegionScheduler {
  private val regionScheduler: RegionScheduler = Bukkit.getRegionScheduler()

  override fun execute(plugin: Plugin, world: World, chunkX: Int, chunkZ: Int, task: Runnable) {
    regionScheduler.execute(plugin, world, chunkX, chunkZ, task)
  }

  override fun execute(plugin: Plugin, location: Location, task: Runnable) {
    execute(plugin, location.world, location.blockX shr 4, location.blockZ shr 4, task)
  }

  override fun run(
    plugin: Plugin,
    world: World,
    chunkX: Int,
    chunkZ: Int,
    task: Runnable,
  ): TaskHandle {
    return FoliaTaskHandle(regionScheduler.run(plugin, world, chunkX, chunkZ) { task.run() })
  }

  override fun run(plugin: Plugin, location: Location, task: Runnable): TaskHandle {
    return run(plugin, location.world, location.blockX shr 4, location.blockZ shr 4, task)
  }

  override fun runDelayed(
    plugin: Plugin,
    world: World,
    chunkX: Int,
    chunkZ: Int,
    task: Runnable,
    delayTicks: Long,
  ): TaskHandle {
    return FoliaTaskHandle(
      regionScheduler.runDelayed(plugin, world, chunkX, chunkZ, { task.run() }, delayTicks)
    )
  }

  override fun runDelayed(
    plugin: Plugin,
    location: Location,
    task: Runnable,
    delayTicks: Long,
  ): TaskHandle {
    return runDelayed(
      plugin,
      location.world,
      location.blockX shr 4,
      location.blockZ shr 4,
      task,
      delayTicks,
    )
  }

  override fun runAtFixedRate(
    plugin: Plugin,
    world: World,
    chunkX: Int,
    chunkZ: Int,
    task: Runnable,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle {
    return FoliaTaskHandle(
      regionScheduler.runAtFixedRate(
        plugin,
        world,
        chunkX,
        chunkZ,
        { task.run() },
        initialDelayTicks,
        periodTicks,
      )
    )
  }

  override fun runAtFixedRate(
    plugin: Plugin,
    location: Location,
    task: Runnable,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle {
    return runAtFixedRate(
      plugin,
      location.world,
      location.blockX shr 4,
      location.blockZ shr 4,
      task,
      initialDelayTicks,
      periodTicks,
    )
  }
}
