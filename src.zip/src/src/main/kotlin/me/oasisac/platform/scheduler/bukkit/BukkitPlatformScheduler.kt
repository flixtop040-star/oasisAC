package me.oasisac.platform.scheduler.bukkit

import me.oasisac.platform.scheduler.PlatformScheduler

class BukkitPlatformScheduler : PlatformScheduler {
  override val asyncScheduler = BukkitAsyncScheduler()
  override val globalRegionScheduler = BukkitGlobalRegionScheduler()
  override val entityScheduler = BukkitEntityScheduler()
  override val regionScheduler = BukkitRegionScheduler()
}
