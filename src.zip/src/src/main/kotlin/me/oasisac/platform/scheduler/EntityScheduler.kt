package me.oasisac.platform.scheduler

import org.bukkit.entity.Entity
import org.bukkit.plugin.Plugin

/** Represents a scheduler for executing entity tasks. */
interface EntityScheduler {
  fun execute(entity: Entity, plugin: Plugin, run: Runnable, retired: Runnable?, delay: Long)

  fun run(entity: Entity, plugin: Plugin, task: Runnable, retired: Runnable?): TaskHandle?

  fun runDelayed(
    entity: Entity,
    plugin: Plugin,
    task: Runnable,
    retired: Runnable?,
    delayTicks: Long,
  ): TaskHandle?

  fun runAtFixedRate(
    entity: Entity,
    plugin: Plugin,
    task: Runnable,
    retired: Runnable?,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle?
}
