package me.oasisac.platform.scheduler.folia

import io.papermc.paper.threadedregions.scheduler.ScheduledTask
import me.oasisac.platform.scheduler.EntityScheduler
import me.oasisac.platform.scheduler.TaskHandle
import org.bukkit.entity.Entity
import org.bukkit.plugin.Plugin

class FoliaEntityScheduler : EntityScheduler {
  override fun execute(
    entity: Entity,
    plugin: Plugin,
    run: Runnable,
    retired: Runnable?,
    delay: Long,
  ) {
    entity.scheduler.execute(plugin, run, retired, delay)
  }

  override fun run(
    entity: Entity,
    plugin: Plugin,
    task: Runnable,
    retired: Runnable?,
  ): TaskHandle? {
    val scheduled: ScheduledTask? = entity.scheduler.run(plugin, { task.run() }, retired)
    return scheduled?.let { FoliaTaskHandle(it) }
  }

  override fun runDelayed(
    entity: Entity,
    plugin: Plugin,
    task: Runnable,
    retired: Runnable?,
    delayTicks: Long,
  ): TaskHandle? {
    val scheduled: ScheduledTask? =
      entity.scheduler.runDelayed(plugin, { task.run() }, retired, delayTicks)
    return scheduled?.let { FoliaTaskHandle(it) }
  }

  override fun runAtFixedRate(
    entity: Entity,
    plugin: Plugin,
    task: Runnable,
    retired: Runnable?,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle? {
    val scheduled: ScheduledTask? =
      entity.scheduler.runAtFixedRate(
        plugin,
        { task.run() },
        retired,
        initialDelayTicks,
        periodTicks,
      )
    return scheduled?.let { FoliaTaskHandle(it) }
  }
}
