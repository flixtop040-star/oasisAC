package me.oasisac.platform.scheduler

import me.oasisac.platform.scheduler.bukkit.BukkitPlatformScheduler
import me.oasisac.platform.scheduler.folia.FoliaPlatformScheduler

object PlatformSchedulerFactory {
  @JvmStatic
  fun create(): PlatformScheduler {
    return if (FoliaDetector.isFolia()) FoliaPlatformScheduler() else BukkitPlatformScheduler()
  }

  @JvmStatic
  fun isFolia(): Boolean {
    return FoliaDetector.isFolia()
  }
}
