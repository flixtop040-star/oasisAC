package me.oasisac.platform.scheduler

import org.bukkit.plugin.Plugin

/** Represents a scheduler for executing global region tasks. */
interface GlobalRegionScheduler {
  fun execute(plugin: Plugin, task: Runnable)

  fun run(plugin: Plugin, task: Runnable): TaskHandle

  fun runDelayed(plugin: Plugin, task: Runnable, delayTicks: Long): TaskHandle

  fun runAtFixedRate(
    plugin: Plugin,
    task: Runnable,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle

  fun cancel(plugin: Plugin)
}
