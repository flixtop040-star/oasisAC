package me.oasisac.platform.scheduler.bukkit

import me.oasisac.platform.scheduler.RegionScheduler
import me.oasisac.platform.scheduler.TaskHandle
import org.bukkit.Bukkit
import org.bukkit.Location
import org.bukkit.World
import org.bukkit.plugin.Plugin
import org.bukkit.scheduler.BukkitScheduler

class BukkitRegionScheduler : RegionScheduler {
  private val bukkitScheduler: BukkitScheduler = Bukkit.getScheduler()

  override fun execute(plugin: Plugin, world: World, chunkX: Int, chunkZ: Int, task: Runnable) {
    bukkitScheduler.runTask(plugin, task)
  }

  override fun execute(plugin: Plugin, location: Location, task: Runnable) {
    bukkitScheduler.runTask(plugin, task)
  }

  override fun run(
    plugin: Plugin,
    world: World,
    chunkX: Int,
    chunkZ: Int,
    task: Runnable,
  ): TaskHandle {
    return BukkitTaskHandle(bukkitScheduler.runTask(plugin, task))
  }

  override fun run(plugin: Plugin, location: Location, task: Runnable): TaskHandle {
    return BukkitTaskHandle(bukkitScheduler.runTask(plugin, task))
  }

  override fun runDelayed(
    plugin: Plugin,
    world: World,
    chunkX: Int,
    chunkZ: Int,
    task: Runnable,
    delayTicks: Long,
  ): TaskHandle {
    return BukkitTaskHandle(bukkitScheduler.runTaskLater(plugin, task, delayTicks))
  }

  override fun runDelayed(
    plugin: Plugin,
    location: Location,
    task: Runnable,
    delayTicks: Long,
  ): TaskHandle {
    return BukkitTaskHandle(bukkitScheduler.runTaskLater(plugin, task, delayTicks))
  }

  override fun runAtFixedRate(
    plugin: Plugin,
    world: World,
    chunkX: Int,
    chunkZ: Int,
    task: Runnable,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle {
    return BukkitTaskHandle(
      bukkitScheduler.runTaskTimer(plugin, task, initialDelayTicks, periodTicks)
    )
  }

  override fun runAtFixedRate(
    plugin: Plugin,
    location: Location,
    task: Runnable,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle {
    return BukkitTaskHandle(
      bukkitScheduler.runTaskTimer(plugin, task, initialDelayTicks, periodTicks)
    )
  }
}
