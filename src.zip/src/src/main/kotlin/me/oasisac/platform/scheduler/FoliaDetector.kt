package me.oasisac.platform.scheduler

object FoliaDetector {
  @JvmStatic
  fun isFolia(): Boolean {
    return try {
      Class.forName("io.papermc.paper.threadedregions.RegionizedServer")
      true
    } catch (ex: ClassNotFoundException) {
      false
    }
  }
}
