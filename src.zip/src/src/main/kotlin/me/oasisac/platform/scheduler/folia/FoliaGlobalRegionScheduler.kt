package me.oasisac.platform.scheduler.folia

import io.papermc.paper.threadedregions.scheduler.GlobalRegionScheduler
import me.oasisac.platform.scheduler.GlobalRegionScheduler as OasisGlobalRegionScheduler
import me.oasisac.platform.scheduler.TaskHandle
import org.bukkit.Bukkit
import org.bukkit.plugin.Plugin

class FoliaGlobalRegionScheduler : OasisGlobalRegionScheduler {
  private val globalRegionScheduler: GlobalRegionScheduler = Bukkit.getGlobalRegionScheduler()

  override fun execute(plugin: Plugin, task: Runnable) {
    globalRegionScheduler.execute(plugin, task)
  }

  override fun run(plugin: Plugin, task: Runnable): TaskHandle {
    return FoliaTaskHandle(globalRegionScheduler.run(plugin) { task.run() })
  }

  override fun runDelayed(plugin: Plugin, task: Runnable, delayTicks: Long): TaskHandle {
    return FoliaTaskHandle(globalRegionScheduler.runDelayed(plugin, { task.run() }, delayTicks))
  }

  override fun runAtFixedRate(
    plugin: Plugin,
    task: Runnable,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle {
    return FoliaTaskHandle(
      globalRegionScheduler.runAtFixedRate(plugin, { task.run() }, initialDelayTicks, periodTicks)
    )
  }

  override fun cancel(plugin: Plugin) {
    globalRegionScheduler.cancelTasks(plugin)
  }
}
