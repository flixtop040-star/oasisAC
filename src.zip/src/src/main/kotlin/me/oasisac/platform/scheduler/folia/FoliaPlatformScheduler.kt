package me.oasisac.platform.scheduler.folia

import me.oasisac.platform.scheduler.PlatformScheduler

class FoliaPlatformScheduler : PlatformScheduler {
  override val asyncScheduler = FoliaAsyncScheduler()
  override val globalRegionScheduler = FoliaGlobalRegionScheduler()
  override val entityScheduler = FoliaEntityScheduler()
  override val regionScheduler = FoliaRegionScheduler()
}
