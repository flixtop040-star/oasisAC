package me.oasisac.platform.scheduler.bukkit

import me.oasisac.platform.scheduler.EntityScheduler
import me.oasisac.platform.scheduler.TaskHandle
import org.bukkit.Bukkit
import org.bukkit.entity.Entity
import org.bukkit.plugin.Plugin

class BukkitEntityScheduler : EntityScheduler {
  private val scheduler = Bukkit.getScheduler()

  override fun execute(
    entity: Entity,
    plugin: Plugin,
    run: Runnable,
    retired: Runnable?,
    delay: Long,
  ) {
    scheduler.runTaskLater(plugin, run, delay)
  }

  override fun run(entity: Entity, plugin: Plugin, task: Runnable, retired: Runnable?): TaskHandle {
    return BukkitTaskHandle(scheduler.runTask(plugin, task))
  }

  override fun runDelayed(
    entity: Entity,
    plugin: Plugin,
    task: Runnable,
    retired: Runnable?,
    delayTicks: Long,
  ): TaskHandle {
    return BukkitTaskHandle(scheduler.runTaskLater(plugin, task, delayTicks))
  }

  override fun runAtFixedRate(
    entity: Entity,
    plugin: Plugin,
    task: Runnable,
    retired: Runnable?,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle {
    return BukkitTaskHandle(scheduler.runTaskTimer(plugin, task, initialDelayTicks, periodTicks))
  }
}
