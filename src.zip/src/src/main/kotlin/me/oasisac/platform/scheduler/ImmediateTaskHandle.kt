package me.oasisac.platform.scheduler

class ImmediateTaskHandle private constructor(private val sync: Boolean) : TaskHandle {
  override fun isSync(): Boolean = sync

  override fun isCancelled(): Boolean = false

  override fun cancel() {
    // no-op
  }

  companion object {
    @JvmStatic fun sync(): ImmediateTaskHandle = ImmediateTaskHandle(true)
  }
}
