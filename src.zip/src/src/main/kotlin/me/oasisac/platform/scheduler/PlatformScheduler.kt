package me.oasisac.platform.scheduler

import java.util.concurrent.TimeUnit

/** Cross-platform scheduler abstraction for Bukkit/Paper/Folia. */
interface PlatformScheduler {
  val asyncScheduler: AsyncScheduler

  val globalRegionScheduler: GlobalRegionScheduler

  val entityScheduler: EntityScheduler

  val regionScheduler: RegionScheduler

  companion object {
    @JvmStatic
    fun convertTimeToTicks(time: Long, timeUnit: TimeUnit): Long {
      return timeUnit.toMillis(time) / 50
    }

    @JvmStatic
    fun convertTicksToTime(ticks: Long, timeUnit: TimeUnit): Long {
      val millis = ticks * 50L
      return timeUnit.convert(millis, TimeUnit.MILLISECONDS)
    }
  }
}
