package me.oasisac.platform.scheduler.bukkit

import me.oasisac.platform.scheduler.GlobalRegionScheduler
import me.oasisac.platform.scheduler.TaskHandle
import org.bukkit.Bukkit
import org.bukkit.plugin.Plugin
import org.bukkit.scheduler.BukkitScheduler

class BukkitGlobalRegionScheduler : GlobalRegionScheduler {
  private val bukkitScheduler: BukkitScheduler = Bukkit.getScheduler()

  override fun execute(plugin: Plugin, task: Runnable) {
    bukkitScheduler.runTask(plugin, task)
  }

  override fun run(plugin: Plugin, task: Runnable): TaskHandle {
    return BukkitTaskHandle(bukkitScheduler.runTask(plugin, task))
  }

  override fun runDelayed(plugin: Plugin, task: Runnable, delayTicks: Long): TaskHandle {
    return BukkitTaskHandle(bukkitScheduler.runTaskLater(plugin, task, delayTicks))
  }

  override fun runAtFixedRate(
    plugin: Plugin,
    task: Runnable,
    initialDelayTicks: Long,
    periodTicks: Long,
  ): TaskHandle {
    return BukkitTaskHandle(
      bukkitScheduler.runTaskTimer(plugin, task, initialDelayTicks, periodTicks)
    )
  }

  override fun cancel(plugin: Plugin) {
    bukkitScheduler.cancelTasks(plugin)
  }
}
