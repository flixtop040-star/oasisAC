package me.oasisac.platform.scheduler.bukkit

import me.oasisac.platform.scheduler.TaskHandle
import org.bukkit.scheduler.BukkitTask

class BukkitTaskHandle(private val task: BukkitTask) : TaskHandle {
  override fun isSync(): Boolean = task.isSync

  override fun isCancelled(): Boolean = task.isCancelled

  override fun cancel() {
    task.cancel()
  }
}
