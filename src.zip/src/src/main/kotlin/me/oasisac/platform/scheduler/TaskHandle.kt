package me.oasisac.platform.scheduler

interface TaskHandle {
  fun isSync(): Boolean

  fun isCancelled(): Boolean

  fun cancel()
}
