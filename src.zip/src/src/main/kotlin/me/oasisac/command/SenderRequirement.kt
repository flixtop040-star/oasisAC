package me.oasisac.command

import me.oasisac.sender.Sender
import net.kyori.adventure.text.Component
import org.incendo.cloud.processors.requirements.Requirement

interface SenderRequirement : Requirement<Sender, SenderRequirement> {
  fun errorMessage(sender: Sender): Component
}
