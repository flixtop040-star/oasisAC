package me.oasisac.command.handler

import me.oasisac.command.SenderRequirement
import me.oasisac.sender.Sender
import org.incendo.cloud.context.CommandContext
import org.incendo.cloud.processors.requirements.RequirementFailureHandler

class OasisCommandFailureHandler : RequirementFailureHandler<Sender, SenderRequirement> {
  override fun handleFailure(context: CommandContext<Sender>, requirement: SenderRequirement) {
    context.sender().sendMessage(requirement.errorMessage(context.sender()))
  }
}
