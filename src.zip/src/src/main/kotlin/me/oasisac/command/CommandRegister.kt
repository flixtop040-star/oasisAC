package me.oasisac.command

import io.leangen.geantyref.TypeToken
import java.util.function.Function
import me.oasisac.command.handler.OasisCommandFailureHandler
import me.oasisac.sender.Sender
import me.oasisac.utils.MessageUtil
import net.kyori.adventure.text.ComponentLike
import net.kyori.adventure.text.format.NamedTextColor
import org.incendo.cloud.exception.InvalidSyntaxException
import org.incendo.cloud.key.CloudKey
import org.incendo.cloud.processors.requirements.RequirementApplicable
import org.incendo.cloud.processors.requirements.RequirementPostprocessor
import org.incendo.cloud.processors.requirements.Requirements

class CommandRegister(
  private val commands: Collection<OasisCommand>,
  private val failureHandler: OasisCommandFailureHandler,
) {
  private var commandsRegistered = false

  fun registerCommands(commandManager: org.incendo.cloud.CommandManager<Sender>) {
    if (commandsRegistered) {
      return
    }

    for (command in commands) {
      command.register(commandManager)
    }

    val senderRequirementPostprocessor =
      RequirementPostprocessor.of(REQUIREMENT_KEY, failureHandler)
    commandManager.registerCommandPostProcessor(senderRequirementPostprocessor)

    registerExceptionHandler(commandManager, InvalidSyntaxException::class.java) { e ->
      MessageUtil.format(e.correctSyntax())
    }

    commandsRegistered = true
  }

  private fun <E : Exception> registerExceptionHandler(
    commandManager: org.incendo.cloud.CommandManager<Sender>,
    ex: Class<E>,
    toComponent: Function<E, ComponentLike>,
  ) {
    commandManager.exceptionController().registerHandler(ex) { c ->
      c.context()
        .sender()
        .sendMessage(
          toComponent.apply(c.exception()).asComponent().colorIfAbsent(NamedTextColor.RED)
        )
    }
  }

  companion object {
    @JvmField
    val REQUIREMENT_KEY: CloudKey<Requirements<Sender, SenderRequirement>> =
      CloudKey.of(
        "oasisac_requirements",
        object : TypeToken<Requirements<Sender, SenderRequirement>>() {},
      )

    @JvmField
    val REQUIREMENT_FACTORY:
      RequirementApplicable.RequirementApplicableFactory<Sender, SenderRequirement> =
      RequirementApplicable.factory(REQUIREMENT_KEY)
  }
}
