package me.oasisac.command.commands.info

import me.oasisac.command.OasisCommand
import me.oasisac.config.ConfigManager
import me.oasisac.config.LocaleManager
import me.oasisac.database.DatabaseManager
import me.oasisac.database.Violation
import me.oasisac.scheduler.SchedulerService
import me.oasisac.sender.Sender
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import me.oasisac.utils.TimeUtil
import org.bukkit.OfflinePlayer
import org.incendo.cloud.CommandManager
import org.incendo.cloud.bukkit.parser.OfflinePlayerParser
import org.incendo.cloud.context.CommandContext
import org.incendo.cloud.description.Description
import org.incendo.cloud.kotlin.extension.buildAndRegister
import org.incendo.cloud.parser.standard.IntegerParser

class HistoryCommand(
  private val databaseManager: DatabaseManager,
  private val configManager: ConfigManager,
  private val localeManager: LocaleManager,
  private val scheduler: SchedulerService,
) : OasisCommand {
  override fun register(manager: CommandManager<Sender>) {
    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("history", Description.empty(), "hist")
        .permission("oasisac.history")
        .required("target", OfflinePlayerParser.offlinePlayerParser())
        .optional("page", IntegerParser.integerParser(1))
        .handler(this@HistoryCommand::handleHistory)
    }
  }

  private fun handleHistory(context: CommandContext<Sender>) {
    val sender = context.sender()
    val target: OfflinePlayer = context["target"]
    val page: Int = context.getOrDefault("page", 1)

    if (!configManager.config.getBoolean("history.enabled", false)) {
      MessageUtil.sendMessage(sender.nativeSender, Message.HISTORY_DISABLED)
      return
    }
    if (!target.hasPlayedBefore() && !target.isOnline) {
      MessageUtil.sendMessage(sender.nativeSender, Message.PLAYER_NOT_FOUND)
      return
    }
    warnIfStorageDegraded(sender)
    val targetId = target.uniqueId

    scheduler.runAsync {
      val entriesPerPage = 10
      val violations: List<Violation> =
        databaseManager.database.getViolations(targetId, page, entriesPerPage)
      val totalLogs = databaseManager.database.getLogCount(targetId)
      val maxPages =
        kotlin.math.max(1, kotlin.math.ceil(totalLogs.toDouble() / entriesPerPage).toInt())

      val header =
        MessageUtil.getMessage(
          Message.HISTORY_HEADER,
          "player",
          displayName(target),
          "page",
          page.toString(),
          "max_pages",
          maxPages.toString(),
        )

      val entries =
        violations.map { violation ->
          MessageUtil.getMessage(
            Message.HISTORY_ENTRY,
            "server",
            violation.serverName,
            "check",
            violation.checkName,
            "vl",
            violation.vl.toString(),
            "verbose",
            violation.verbose,
            "timeago",
            TimeUtil.formatTimeAgo(violation.createdAt, localeManager),
          )
        }

      scheduler.runSync {
        sender.sendMessage(header)

        if (entries.isEmpty()) {
          MessageUtil.sendMessage(sender.nativeSender, Message.HISTORY_NO_VIOLATIONS)
          return@runSync
        }

        for (entry in entries) {
          sender.sendMessage(entry)
        }
      }
    }
  }

  private fun warnIfStorageDegraded(sender: Sender) {
    if (!databaseManager.isAvailable) {
      MessageUtil.sendMessage(sender.nativeSender, Message.STORAGE_DEGRADED)
    }
  }

  private fun displayName(target: OfflinePlayer): String {
    return target.name ?: target.uniqueId.toString()
  }
}
