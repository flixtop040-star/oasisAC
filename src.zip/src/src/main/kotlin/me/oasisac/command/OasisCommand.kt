package me.oasisac.command

import me.oasisac.sender.Sender
import org.incendo.cloud.CommandManager

interface OasisCommand {
  fun register(manager: CommandManager<Sender>)
}
