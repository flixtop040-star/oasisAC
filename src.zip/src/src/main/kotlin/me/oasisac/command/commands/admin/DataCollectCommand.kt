package me.oasisac.command.commands.admin

import java.time.Duration
import java.time.Instant
import java.util.Locale
import me.oasisac.checks.impl.ai.DataCollectorManager
import me.oasisac.command.OasisCommand
import me.oasisac.data.DataSession
import me.oasisac.sender.Sender
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import org.bukkit.command.CommandSender
import org.bukkit.entity.Player
import org.incendo.cloud.CommandManager
import org.incendo.cloud.bukkit.parser.PlayerParser
import org.incendo.cloud.context.CommandContext
import org.incendo.cloud.description.Description
import org.incendo.cloud.kotlin.extension.buildAndRegister
import org.incendo.cloud.kotlin.extension.suggestionProvider
import org.incendo.cloud.parser.standard.StringParser
import org.incendo.cloud.suggestion.Suggestion
import org.incendo.cloud.suggestion.SuggestionProvider

class DataCollectCommand(private val dataCollectorManager: DataCollectorManager) : OasisCommand {
  override fun register(manager: CommandManager<Sender>) {
    val typeSuggestions = listOf("LEGIT", "CHEAT").map { Suggestion.suggestion(it) }

    val typeProvider = SuggestionProvider.suggesting<Sender>(typeSuggestions)

    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("datacollect", Description.empty(), "dc")
        .literal("start")
        .permission("oasisac.datacollect.start")
        .required("target", PlayerParser.playerParser())
        .required("type", StringParser.stringParser()) { suggestionProvider = typeProvider }
        .optional("details", StringParser.greedyStringParser())
        .handler(this@DataCollectCommand::start)
    }

    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("datacollect", Description.empty(), "dc")
        .literal("stop")
        .permission("oasisac.datacollect.stop")
        .required("target", PlayerParser.playerParser())
        .handler(this@DataCollectCommand::stop)
    }

    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("datacollect", Description.empty(), "dc")
        .literal("status")
        .permission("oasisac.datacollect.status")
        .optional("target", PlayerParser.playerParser())
        .handler(this@DataCollectCommand::status)
    }
  }

  private fun start(context: CommandContext<Sender>) {
    val sender: CommandSender = context.sender().nativeSender
    val target: Player = context["target"]
    val type = context.get<String>("type").uppercase(Locale.ROOT)
    val details: String = context.getOrDefault("details", "")

    val statusDetails = resolveStatus(type, details, sender) ?: return

    if (dataCollectorManager.startCollecting(target.uniqueId, target.name, statusDetails)) {
      MessageUtil.sendMessage(
        sender,
        Message.DATACOLLECT_START_SUCCESS,
        "player",
        target.name,
        "status",
        statusDetails,
      )
    } else {
      MessageUtil.sendMessage(sender, Message.DATACOLLECT_START_RESTARTED, "player", target.name)
    }
  }

  private fun stop(context: CommandContext<Sender>) {
    val sender: CommandSender = context.sender().nativeSender
    val target: Player = context["target"]

    if (dataCollectorManager.stopCollecting(target.uniqueId)) {
      MessageUtil.sendMessage(sender, Message.DATACOLLECT_STOP_SUCCESS, "player", target.name)
    } else {
      MessageUtil.sendMessage(sender, Message.DATACOLLECT_STOP_FAIL, "player", target.name)
    }
  }

  private fun status(context: CommandContext<Sender>) {
    val sender: CommandSender = context.sender().nativeSender
    val target: Player? = context.getOrDefault("target", null)

    if (target != null) {
      val session = dataCollectorManager.getSession(target.uniqueId)
      if (session != null) {
        val seconds = Duration.between(session.startTime, Instant.now()).toSeconds()
        MessageUtil.sendMessage(
          sender,
          Message.DATACOLLECT_STATUS_PLAYER,
          "player",
          target.name,
          "status",
          session.status,
          "time",
          seconds.toString(),
          "ticks",
          session.recordedTicks.size.toString(),
        )
      } else {
        MessageUtil.sendMessage(
          sender,
          Message.DATACOLLECT_STATUS_NO_SESSION,
          "player",
          target.name,
        )
      }
      return
    }

    MessageUtil.sendMessage(sender, Message.DATACOLLECT_STATUS_HEADER)
    if (dataCollectorManager.activeSessions.isEmpty()) {
      MessageUtil.sendMessage(sender, Message.DATACOLLECT_STATUS_NONE)
      return
    }

    for (session: DataSession in dataCollectorManager.activeSessions.values) {
      val seconds = Duration.between(session.startTime, Instant.now()).toSeconds()
      MessageUtil.sendMessage(
        sender,
        Message.DATACOLLECT_STATUS_PLAYER,
        "player",
        session.player,
        "status",
        session.status,
        "time",
        seconds.toString(),
        "ticks",
        session.recordedTicks.size.toString(),
      )
    }
  }

  private fun resolveStatus(type: String, details: String, sender: CommandSender): String? {
    return when (type) {
      "LEGIT",
      "CHEAT" -> {
        if (details.isEmpty()) {
          MessageUtil.sendMessage(sender, Message.DATACOLLECT_DETAILS_REQUIRED)
          null
        } else {
          "$type $details"
        }
      }
      else -> {
        MessageUtil.sendMessage(sender, Message.DATACOLLECT_INVALID_TYPE)
        null
      }
    }
  }
}
