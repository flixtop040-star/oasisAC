package me.oasisac.command

import me.oasisac.OasisAC
import me.oasisac.sender.Sender
import org.bukkit.command.CommandSender
import org.incendo.cloud.SenderMapper
import org.incendo.cloud.bukkit.CloudBukkitCapabilities
import org.incendo.cloud.execution.ExecutionCoordinator
import org.incendo.cloud.paper.LegacyPaperCommandManager

class CommandManager(
  private val plugin: OasisAC,
  private val commandRegister: CommandRegister,
  private val senderMapper: SenderMapper<CommandSender, Sender>,
) {
  private var cloudManager: LegacyPaperCommandManager<Sender>? = null

  fun registerCommands() {
    if (cloudManager != null) {
      return
    }

    val manager = setupCloud(plugin) ?: return

    commandRegister.registerCommands(manager)
    cloudManager = manager
  }

  private fun setupCloud(plugin: OasisAC): LegacyPaperCommandManager<Sender>? {
    val manager =
      try {
        LegacyPaperCommandManager(plugin, ExecutionCoordinator.simpleCoordinator(), senderMapper)
      } catch (e: Exception) {
        plugin.logger.severe("Failed to initialize Cloud Command Manager: ${e.message}")
        e.printStackTrace()
        return null
      }

    if (manager.hasCapability(CloudBukkitCapabilities.NATIVE_BRIGADIER)) {
      manager.registerBrigadier()
    } else if (manager.hasCapability(CloudBukkitCapabilities.ASYNCHRONOUS_COMPLETION)) {
      manager.registerAsynchronousCompletions()
    }

    return manager
  }
}
