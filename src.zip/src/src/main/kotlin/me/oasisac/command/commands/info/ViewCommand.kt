package me.oasisac.command.commands.info

import me.oasisac.command.CommandRegister
import me.oasisac.command.OasisCommand
import me.oasisac.command.requirements.PlayerSenderRequirement
import me.oasisac.monitor.MonitorViewService
import me.oasisac.monitor.VIEW_PERMISSION
import me.oasisac.sender.Sender
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import org.incendo.cloud.CommandManager
import org.incendo.cloud.context.CommandContext
import org.incendo.cloud.kotlin.extension.buildAndRegister

class ViewCommand(private val monitorViewService: MonitorViewService) : OasisCommand {
  override fun register(manager: CommandManager<Sender>) {
    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("view")
        .permission(VIEW_PERMISSION)
        .mutate { it.apply(CommandRegister.REQUIREMENT_FACTORY.create(PlayerSenderRequirement)) }
        .handler(this@ViewCommand::toggle)
    }
  }

  private fun toggle(context: CommandContext<Sender>) {
    val viewer = context.sender().player ?: return
    val enabled = monitorViewService.toggle(viewer)

    if (enabled) {
      MessageUtil.sendMessage(viewer, Message.VIEW_ENABLED)
    } else {
      MessageUtil.sendMessage(viewer, Message.VIEW_DISABLED)
    }
  }
}
