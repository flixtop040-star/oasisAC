package me.oasisac.command.commands.info

import java.util.logging.Logger
import me.oasisac.checks.impl.ai.AiCheck
import me.oasisac.checks.impl.combat.AimProcessor
import me.oasisac.command.OasisCommand
import me.oasisac.config.LocaleManager
import me.oasisac.player.OasisPlayer
import me.oasisac.player.PlayerDataManager
import me.oasisac.sender.Sender
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import me.oasisac.utils.TimeUtil
import org.bukkit.Statistic
import org.bukkit.command.CommandSender
import org.bukkit.entity.Player
import org.incendo.cloud.CommandManager
import org.incendo.cloud.bukkit.parser.PlayerParser
import org.incendo.cloud.context.CommandContext
import org.incendo.cloud.kotlin.extension.buildAndRegister

class ProfileCommand(
  private val playerDataManager: PlayerDataManager,
  private val localeManager: LocaleManager,
  private val logger: Logger,
) : OasisCommand {
  override fun register(manager: CommandManager<Sender>) {
    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("profile")
        .permission("oasisac.profile")
        .required("target", PlayerParser.playerParser())
        .handler(this@ProfileCommand::execute)
    }
  }

  private fun execute(context: CommandContext<Sender>) {
    val sender: CommandSender = context.sender().nativeSender
    val target: Player = context["target"]

    val oasisacPlayer: OasisPlayer =
      playerDataManager.getPlayer(target)
        ?: run {
          MessageUtil.sendMessage(sender, Message.PROFILE_NO_DATA)
          return
        }

    val aiCheck = oasisacPlayer.checkManager.getCheck(AiCheck::class.java)
    val aimProcessor = oasisacPlayer.checkManager.getCheck(AimProcessor::class.java)

    val sessionMillis = System.currentTimeMillis() - oasisacPlayer.joinTime
    var totalPlayTicks = 0L
    try {
      totalPlayTicks = target.getStatistic(Statistic.PLAY_ONE_MINUTE).toLong()
    } catch (_: IllegalArgumentException) {
      logger.fine("Failed to fetch PLAY_ONE_MINUTE for ${target.name}")
    }

    val totalPlayMillis = totalPlayTicks * 50

    MessageUtil.sendMessageList(
      sender,
      Message.PROFILE_LINES,
      "player",
      target.name,
      "ping",
      target.ping.toString(),
      "version",
      oasisacPlayer.user.clientVersion.releaseName,
      "brand",
      oasisacPlayer.brand,
      "session_time",
      TimeUtil.formatDuration(sessionMillis, localeManager),
      "total_playtime",
      TimeUtil.formatDuration(totalPlayMillis, localeManager),
      "sens_x",
      if (aimProcessor != null) String.format("%.2f", aimProcessor.sensitivityX * 200) else "N/A",
      "sens_y",
      if (aimProcessor != null) String.format("%.2f", aimProcessor.sensitivityY * 200) else "N/A",
      "ai_buffer",
      if (aiCheck != null) String.format("%.2f", aiCheck.buffer) else "N/A",
      "ai_probs_90",
      if (aiCheck != null) aiCheck.prob90.toString() else "N/A",
    )
  }
}
