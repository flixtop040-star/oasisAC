package me.oasisac.command.requirements

import me.oasisac.command.SenderRequirement
import me.oasisac.sender.Sender
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import net.kyori.adventure.text.Component
import org.incendo.cloud.context.CommandContext

object PlayerSenderRequirement : SenderRequirement {
  override fun errorMessage(sender: Sender): Component {
    return MessageUtil.getMessage(Message.RUN_AS_PLAYER)
  }

  override fun evaluateRequirement(commandContext: CommandContext<Sender>): Boolean {
    return commandContext.sender().isPlayer
  }
}
