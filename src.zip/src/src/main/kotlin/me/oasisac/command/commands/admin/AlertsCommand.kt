package me.oasisac.command.commands.admin

import me.oasisac.alert.AlertManager
import me.oasisac.alert.AlertType
import me.oasisac.command.OasisCommand
import me.oasisac.sender.Sender
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import org.bukkit.command.CommandSender
import org.bukkit.entity.Player
import org.incendo.cloud.CommandManager
import org.incendo.cloud.context.CommandContext
import org.incendo.cloud.kotlin.extension.buildAndRegister

class AlertsCommand(private val alertManager: AlertManager) : OasisCommand {
  override fun register(manager: CommandManager<Sender>) {
    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("alerts").permission("oasisac.alerts").handler(this@AlertsCommand::execute)
    }
  }

  private fun execute(context: CommandContext<Sender>) {
    val nativeSender: CommandSender = context.sender().nativeSender

    if (nativeSender is Player) {
      alertManager.toggle(nativeSender, AlertType.REGULAR, false)
    } else {
      alertManager.toggleConsoleAlerts(AlertType.REGULAR)
      if (alertManager.isConsoleAlertsEnabled(AlertType.REGULAR)) {
        MessageUtil.sendMessage(nativeSender, Message.ALERTS_ENABLED)
      } else {
        MessageUtil.sendMessage(nativeSender, Message.ALERTS_DISABLED)
      }
    }
  }
}
