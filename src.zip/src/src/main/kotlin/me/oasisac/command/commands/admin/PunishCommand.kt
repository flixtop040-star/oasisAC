package me.oasisac.command.commands.admin

import me.oasisac.command.OasisCommand
import me.oasisac.database.DatabaseManager
import me.oasisac.sender.Sender
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import org.bukkit.OfflinePlayer
import org.incendo.cloud.CommandManager
import org.incendo.cloud.bukkit.parser.OfflinePlayerParser
import org.incendo.cloud.context.CommandContext
import org.incendo.cloud.kotlin.extension.buildAndRegister

class PunishCommand(private val databaseManager: DatabaseManager) : OasisCommand {
  override fun register(manager: CommandManager<Sender>) {
    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("punish")
        .permission("oasisac.punish.manage")
        .literal("reset")
        .required("target", OfflinePlayerParser.offlinePlayerParser())
        .handler(this@PunishCommand::reset)
    }
  }

  private fun reset(context: CommandContext<Sender>) {
    val sender = context.sender()
    val target: OfflinePlayer = context["target"]

    if (!databaseManager.isAvailable) {
      MessageUtil.sendMessage(sender.nativeSender, Message.STORAGE_DEGRADED)
    }

    databaseManager.database.resetAllViolationLevels(target.uniqueId)

    MessageUtil.sendMessage(
      sender.nativeSender,
      Message.PUNISH_RESET_SUCCESS,
      "player",
      target.name ?: target.uniqueId.toString(),
    )
  }
}
