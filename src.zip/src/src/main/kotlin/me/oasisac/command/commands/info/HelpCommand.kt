package me.oasisac.command.commands.info

import me.oasisac.command.OasisCommand
import me.oasisac.sender.Sender
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import org.incendo.cloud.CommandManager
import org.incendo.cloud.context.CommandContext
import org.incendo.cloud.kotlin.extension.buildAndRegister

class HelpCommand : OasisCommand {
  override fun register(manager: CommandManager<Sender>) {
    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      permission("oasisac.help")
      handler(this@HelpCommand::help)
    }
    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      permission("oasisac.help")
      literal("help").handler(this@HelpCommand::help)
    }
  }

  private fun help(context: CommandContext<Sender>) {
    val sender = context.sender()
    MessageUtil.sendMessageList(sender.nativeSender, Message.HELP_MESSAGE, "command", "oasisac")
  }
}
