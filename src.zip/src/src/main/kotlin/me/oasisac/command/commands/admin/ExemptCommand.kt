package me.oasisac.command.commands.admin

import me.oasisac.command.OasisCommand
import me.oasisac.config.LocaleManager
import me.oasisac.player.ExemptManager
import me.oasisac.sender.Sender
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import me.oasisac.utils.TimeUtil
import org.bukkit.entity.Player
import org.incendo.cloud.CommandManager
import org.incendo.cloud.bukkit.parser.PlayerParser
import org.incendo.cloud.context.CommandContext
import org.incendo.cloud.kotlin.extension.buildAndRegister
import org.incendo.cloud.parser.standard.StringParser

class ExemptCommand(
  private val exemptManager: ExemptManager,
  private val localeManager: LocaleManager,
) : OasisCommand {
  override fun register(manager: CommandManager<Sender>) {
    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("exempt")
        .permission("oasisac.exempt.manage")
        .required("target", PlayerParser.playerParser())
        .optional("duration", StringParser.stringParser())
        .handler(this@ExemptCommand::handleExempt)
    }

    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("exempt")
        .permission("oasisac.exempt.manage")
        .literal("remove")
        .required("target", PlayerParser.playerParser())
        .handler(this@ExemptCommand::handleRemoveExempt)
    }

    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("exempt")
        .permission("oasisac.exempt.manage")
        .literal("status")
        .required("target", PlayerParser.playerParser())
        .handler(this@ExemptCommand::handleStatus)
    }
  }

  private fun handleExempt(context: CommandContext<Sender>) {
    val sender = context.sender()
    val target: Player = context["target"]
    val durationStr: String = context.getOrDefault("duration", "5m")

    val durationMillis = TimeUtil.parseDuration(durationStr)
    if (durationMillis == 0L) {
      MessageUtil.sendMessage(sender.nativeSender, Message.EXEMPT_INVALID_DURATION)
      return
    }

    exemptManager.addExemption(target.uniqueId, durationMillis)

    if (durationMillis == -1L) {
      MessageUtil.sendMessage(
        sender.nativeSender,
        Message.EXEMPT_SUCCESS_PERM,
        "player",
        target.name,
      )
    } else {
      MessageUtil.sendMessage(
        sender.nativeSender,
        Message.EXEMPT_SUCCESS_TEMP,
        "player",
        target.name,
        "duration",
        durationStr,
      )
    }
  }

  private fun handleRemoveExempt(context: CommandContext<Sender>) {
    val sender = context.sender()
    val target: Player = context["target"]

    if (exemptManager.removeExemption(target.uniqueId)) {
      MessageUtil.sendMessage(
        sender.nativeSender,
        Message.EXEMPT_REMOVE_SUCCESS,
        "player",
        target.name,
      )
    } else {
      MessageUtil.sendMessage(
        sender.nativeSender,
        Message.EXEMPT_REMOVE_FAIL,
        "player",
        target.name,
      )
    }
  }

  private fun handleStatus(context: CommandContext<Sender>) {
    val sender = context.sender()
    val target: Player = context["target"]

    if (target.hasPermission("oasisac.exempt")) {
      MessageUtil.sendMessage(
        sender.nativeSender,
        Message.EXEMPT_STATUS_PERM_PERMISSION,
        "player",
        target.name,
      )
      return
    }

    val expiryTime = exemptManager.getExpiryTime(target.uniqueId)
    if (expiryTime == null) {
      MessageUtil.sendMessage(
        sender.nativeSender,
        Message.EXEMPT_STATUS_NOT_EXEMPT,
        "player",
        target.name,
      )
    } else if (expiryTime == -1L) {
      MessageUtil.sendMessage(
        sender.nativeSender,
        Message.EXEMPT_STATUS_PERM_COMMAND,
        "player",
        target.name,
      )
    } else {
      val remaining = expiryTime - System.currentTimeMillis()
      if (remaining <= 0) {
        MessageUtil.sendMessage(
          sender.nativeSender,
          Message.EXEMPT_STATUS_EXPIRED,
          "player",
          target.name,
        )
        exemptManager.removeExemption(target.uniqueId)
      } else {
        val remainingStr = TimeUtil.formatDuration(remaining, localeManager)
        MessageUtil.sendMessage(
          sender.nativeSender,
          Message.EXEMPT_STATUS_TEMP,
          "player",
          target.name,
          "duration",
          remainingStr,
        )
      }
    }
  }
}
