package me.oasisac.command.commands.admin

import java.util.Locale
import me.oasisac.alert.AlertManager
import me.oasisac.alert.AlertType
import me.oasisac.checks.impl.ai.AiCheck
import me.oasisac.command.CommandRegister
import me.oasisac.command.OasisCommand
import me.oasisac.command.requirements.PlayerSenderRequirement
import me.oasisac.database.DatabaseManager
import me.oasisac.player.OasisPlayer
import me.oasisac.player.PlayerDataManager
import me.oasisac.scheduler.SchedulerService
import me.oasisac.sender.Sender
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import net.kyori.adventure.text.Component
import net.kyori.adventure.text.event.ClickEvent
import net.kyori.adventure.text.event.HoverEvent
import org.bukkit.Bukkit
import org.incendo.cloud.CommandManager
import org.incendo.cloud.context.CommandContext
import org.incendo.cloud.kotlin.extension.buildAndRegister

class SuspiciousCommand(
  private val playerDataManager: PlayerDataManager,
  private val alertManager: AlertManager,
  private val databaseManager: DatabaseManager,
  private val scheduler: SchedulerService,
) : OasisCommand {
  private data class SuspiciousEntry(val player: OasisPlayer, val check: AiCheck)

  private data class FlaggedPlayerEntry(val playerName: String, val flags: Int)

  override fun register(manager: CommandManager<Sender>) {
    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("suspicious")
        .permission("oasisac.suspicious")
        .literal("alerts")
        .permission("oasisac.suspicious.alerts")
        .mutate { it.apply(CommandRegister.REQUIREMENT_FACTORY.create(PlayerSenderRequirement)) }
        .handler(this@SuspiciousCommand::executeAlerts)
    }

    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("suspicious")
        .permission("oasisac.suspicious")
        .literal("list")
        .permission("oasisac.suspicious.list")
        .handler(this@SuspiciousCommand::executeList)
    }

    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("suspicious")
        .permission("oasisac.suspicious")
        .literal("top")
        .permission("oasisac.suspicious.top")
        .handler(this@SuspiciousCommand::executeTop)
    }

    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("suspicious")
        .permission("oasisac.suspicious")
        .literal("flagged")
        .permission("oasisac.suspicious.flagged")
        .handler(this@SuspiciousCommand::executeFlagged)
    }
  }

  private fun executeAlerts(context: CommandContext<Sender>) {
    val player = context.sender().player ?: return
    alertManager.toggle(player, AlertType.SUSPICIOUS, false)
  }

  private fun executeList(context: CommandContext<Sender>) {
    val sender = context.sender()
    val bufferFilter = 0.0

    val suspiciousPlayers = ArrayList<SuspiciousEntry>()
    for (sp in playerDataManager.getPlayers()) {
      val check = sp.checkManager.getCheck(AiCheck::class.java) ?: continue
      if (check.buffer > bufferFilter) {
        suspiciousPlayers.add(SuspiciousEntry(sp, check))
      }
    }

    suspiciousPlayers.sortByDescending { it.check.buffer }

    if (suspiciousPlayers.isEmpty()) {
      sender.sendMessage(MessageUtil.getMessage(Message.SUSPICIOUS_LIST_EMPTY))
      return
    }

    sender.sendMessage(
      MessageUtil.getMessage(
        Message.SUSPICIOUS_LIST_HEADER,
        "count",
        suspiciousPlayers.size.toString(),
      )
    )

    for (item in suspiciousPlayers) {
      val buffer = item.check.buffer
      val playerName = item.player.player.name

      val message: Component =
        MessageUtil.getMessage(
            Message.SUSPICIOUS_LIST_ENTRY,
            "player",
            playerName,
            "buffer",
            String.format(Locale.US, "%.1f", buffer),
            "ping",
            item.player.player.ping.toString(),
          )
          .hoverEvent(
            HoverEvent.showText(MessageUtil.getMessage(Message.SUSPICIOUS_LIST_ENTRY_HOVER))
          )
          .clickEvent(ClickEvent.runCommand("/oasisac profile $playerName"))

      sender.sendMessage(message)
    }
  }

  private fun executeTop(context: CommandContext<Sender>) {
    val sender = context.sender()

    var topPlayer: OasisPlayer? = null
    var topBuffer = 0.0

    for (sp in playerDataManager.getPlayers()) {
      val check = sp.checkManager.getCheck(AiCheck::class.java) ?: continue
      val buffer = check.buffer
      if (buffer > topBuffer) {
        topBuffer = buffer
        topPlayer = sp
      }
    }

    if (topPlayer == null || topBuffer == 0.0) {
      sender.sendMessage(MessageUtil.getMessage(Message.SUSPICIOUS_TOP_NONE))
      return
    }

    val playerName = topPlayer.player.name

    val message: Component =
      MessageUtil.getMessage(
          Message.SUSPICIOUS_TOP_PLAYER,
          "player",
          playerName,
          "buffer",
          String.format(Locale.US, "%.1f", topBuffer),
        )
        .hoverEvent(
          HoverEvent.showText(MessageUtil.getMessage(Message.SUSPICIOUS_TOP_PLAYER_HOVER))
        )
        .clickEvent(ClickEvent.runCommand("/oasisac monitor $playerName"))

    sender.sendMessage(message)
  }

  private fun executeFlagged(context: CommandContext<Sender>) {
    val sender = context.sender()
    val onlinePlayers =
      Bukkit.getOnlinePlayers()
        .map { player -> player.uniqueId to player.name }
        .toMap(LinkedHashMap())

    if (onlinePlayers.isEmpty()) {
      sender.sendMessage(MessageUtil.getMessage(Message.SUSPICIOUS_FLAGGED_EMPTY))
      return
    }

    scheduler.runAsync {
      val flagCounts = databaseManager.database.getLogCounts(onlinePlayers.keys)
      val flaggedPlayers =
        flagCounts.entries
          .asSequence()
          .filter { it.value > 0 }
          .mapNotNull { (uuid, flags) ->
            onlinePlayers[uuid]?.let { playerName -> FlaggedPlayerEntry(playerName, flags) }
          }
          .sortedWith(compareByDescending<FlaggedPlayerEntry> { it.flags }.thenBy { it.playerName })
          .toList()

      scheduler.runSync {
        if (flaggedPlayers.isEmpty()) {
          sender.sendMessage(MessageUtil.getMessage(Message.SUSPICIOUS_FLAGGED_EMPTY))
          return@runSync
        }

        sender.sendMessage(
          MessageUtil.getMessage(
            Message.SUSPICIOUS_FLAGGED_HEADER,
            "count",
            flaggedPlayers.size.toString(),
          )
        )

        for (entry in flaggedPlayers) {
          sender.sendMessage(
            MessageUtil.getMessage(
                Message.SUSPICIOUS_FLAGGED_ENTRY,
                "player",
                entry.playerName,
                "flags",
                entry.flags.toString(),
              )
              .hoverEvent(
                HoverEvent.showText(MessageUtil.getMessage(Message.SUSPICIOUS_LIST_ENTRY_HOVER))
              )
              .clickEvent(ClickEvent.runCommand("/oasisac profile ${entry.playerName}"))
          )
        }
      }
    }
  }
}
