package me.oasisac.command.commands.admin

import me.oasisac.OasisAC
import me.oasisac.command.OasisCommand
import me.oasisac.sender.Sender
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import org.incendo.cloud.CommandManager
import org.incendo.cloud.context.CommandContext
import org.incendo.cloud.kotlin.extension.buildAndRegister

class ReloadCommand(private val plugin: OasisAC) : OasisCommand {
  override fun register(manager: CommandManager<Sender>) {
    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("reload").permission("oasisac.reload").handler(this@ReloadCommand::execute)
    }
  }

  private fun execute(context: CommandContext<Sender>) {
    MessageUtil.sendMessage(context.sender().nativeSender, Message.RELOAD_START)
    plugin.onReload()
    MessageUtil.sendMessage(context.sender().nativeSender, Message.RELOAD_SUCCESS)
  }
}
