package me.oasisac.command.commands.info

import me.oasisac.command.OasisCommand
import me.oasisac.config.ConfigManager
import me.oasisac.config.LocaleManager
import me.oasisac.database.DatabaseManager
import me.oasisac.database.Violation
import me.oasisac.scheduler.SchedulerService
import me.oasisac.sender.Sender
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import me.oasisac.utils.TimeUtil
import org.incendo.cloud.CommandManager
import org.incendo.cloud.context.CommandContext
import org.incendo.cloud.kotlin.extension.buildAndRegister
import org.incendo.cloud.parser.standard.IntegerParser

class LogsCommand(
  private val databaseManager: DatabaseManager,
  private val configManager: ConfigManager,
  private val localeManager: LocaleManager,
  private val scheduler: SchedulerService,
) : OasisCommand {
  override fun register(manager: CommandManager<Sender>) {
    manager.buildAndRegister("oasisac", aliases = arrayOf("oasisac")) {
      literal("logs")
        .permission("oasisac.logs")
        .optional("page", IntegerParser.integerParser(1))
        .handler(this@LogsCommand::handleLogs)
    }
  }

  private fun handleLogs(context: CommandContext<Sender>) {
    val sender = context.sender()
    val page: Int = context.getOrDefault("page", 1)

    if (!configManager.config.getBoolean("history.enabled", false)) {
      MessageUtil.sendMessage(sender.nativeSender, Message.HISTORY_DISABLED)
      return
    }

    if (!databaseManager.isAvailable) {
      MessageUtil.sendMessage(sender.nativeSender, Message.STORAGE_DEGRADED)
    }

    scheduler.runAsync {
      val entriesPerPage = 10
      val violations: List<Violation> =
        databaseManager.database.getViolations(page, entriesPerPage, 0L)
      val totalLogs = databaseManager.database.getLogCount(0L)
      val maxPages =
        kotlin.math.max(1, kotlin.math.ceil(totalLogs.toDouble() / entriesPerPage).toInt())

      val header =
        MessageUtil.getMessage(
          Message.LOGS_HEADER,
          "page",
          page.toString(),
          "max_pages",
          maxPages.toString(),
        )

      val entries =
        violations.map { violation ->
          MessageUtil.getMessage(
            Message.LOGS_ENTRY,
            "server",
            violation.serverName,
            "player",
            violation.playerName,
            "check",
            violation.checkName,
            "vl",
            violation.vl.toString(),
            "verbose",
            violation.verbose,
            "timeago",
            TimeUtil.formatTimeAgo(violation.createdAt, localeManager),
          )
        }

      scheduler.runSync {
        sender.sendMessage(header)

        if (entries.isEmpty()) {
          MessageUtil.sendMessage(sender.nativeSender, Message.LOGS_NO_VIOLATIONS)
          return@runSync
        }

        for (entry in entries) {
          sender.sendMessage(entry)
        }
      }
    }
  }
}
