package me.oasisac.utils

import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer

object ChatUtil {
  private val LEGACY_SERIALIZER = LegacyComponentSerializer.legacySection()
  private val PLAIN_SERIALIZER = PlainTextComponentSerializer.plainText()

  @JvmStatic
  fun translateAlternateColorCodes(altColorChar: Char, textToTranslate: String): String {
    val chars = textToTranslate.toCharArray()

    var i = 0
    while (i < chars.size - 1) {
      if (
        chars[i] == altColorChar &&
          "0123456789AaBbCcDdEeFfKkLlMmNnOoRrXx".indexOf(chars[i + 1]) > -1
      ) {
        chars[i] = 167.toChar()
        chars[i + 1] = chars[i + 1].lowercaseChar()
      }
      i++
    }

    return String(chars)
  }

  @JvmStatic
  fun stripColor(input: String?): String? {
    if (input == null) {
      return null
    }
    return PLAIN_SERIALIZER.serialize(LEGACY_SERIALIZER.deserialize(input))
  }
}
