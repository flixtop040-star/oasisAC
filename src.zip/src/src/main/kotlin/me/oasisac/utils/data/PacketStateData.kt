package me.oasisac.utils.data

import com.github.retrooper.packetevents.util.Vector3d

class PacketStateData {
  var packetPlayerOnGround: Boolean = false
  var lastPacketWasTeleport: Boolean = false
  var lastPacketWasServerRotation: Boolean = false
  var lastPacketWasOnePointSeventeenDuplicate: Boolean = false
  var duplicatePacketFilterPosition: Vector3d = Vector3d(0.0, 0.0, 0.0)
}
