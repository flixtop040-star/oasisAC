package me.oasisac.utils.latency

import com.github.retrooper.packetevents.netty.channel.ChannelHelper
import java.util.ArrayDeque
import java.util.ArrayList
import me.oasisac.OasisAC
import me.oasisac.player.OasisPlayer
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil

class LatencyUtils(private val player: OasisPlayer, private val plugin: OasisAC) : ILatencyUtils {
  private data class TransactionTask(val transactionId: Int, val task: Runnable)

  private val transactionMap: ArrayDeque<TransactionTask> = ArrayDeque()

  override fun addRealTimeTask(transaction: Int, runnable: Runnable) {
    addRealTimeTaskInternal(transaction, false, runnable)
  }

  override fun addRealTimeTaskAsync(transaction: Int, runnable: Runnable) {
    addRealTimeTaskInternal(transaction, true, runnable)
  }

  private fun addRealTimeTaskInternal(transactionId: Int, async: Boolean, runnable: Runnable) {
    if (player.transactions.lastTransactionReceived.get() >= transactionId) {
      if (async) {
        ChannelHelper.runInEventLoop(player.user.channel, runnable)
      } else {
        runnable.run()
      }
      return
    }
    synchronized(transactionMap) { transactionMap.add(TransactionTask(transactionId, runnable)) }
  }

  override fun handleNettySyncTransaction(receivedTransactionId: Int) {
    val tasksToRun = ArrayList<Runnable>()
    synchronized(transactionMap) {
      val iterator = transactionMap.iterator()
      while (iterator.hasNext()) {
        val taskEntry = iterator.next()
        val taskTransactionId = taskEntry.transactionId

        if (receivedTransactionId + 1 < taskTransactionId) {
          break
        }

        if (receivedTransactionId == taskTransactionId - 1) {
          continue
        }

        tasksToRun.add(taskEntry.task)
        iterator.remove()
      }
    }

    for (runnable in tasksToRun) {
      try {
        runnable.run()
      } catch (ex: Exception) {
        plugin.logger.severe(
          "An error occurred when running transactions for player: ${player.user.name}"
        )
        ex.printStackTrace()
        player.disconnect(MessageUtil.getMessage(Message.INTERNAL_ERROR))
      }
    }
  }
}
