package me.oasisac.utils.update

import me.oasisac.utils.data.HeadRotation

class RotationUpdate(
  var from: HeadRotation,
  var to: HeadRotation,
  var deltaYaw: Float,
  var deltaPitch: Float,
)
