package me.oasisac.utils.data

data class HeadRotation(var yaw: Float = 0f, var pitch: Float = 0f)
