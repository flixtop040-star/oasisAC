package me.oasisac.utils.math

import kotlin.math.floor
import kotlin.math.pow

object OasisMath {
  private val MINIMUM_DIVISOR: Double = 0.2f.pow(3) * 8 * 0.15 - 1e-3

  @JvmStatic fun getMinimumDivisor(): Double = MINIMUM_DIVISOR

  @JvmStatic
  fun gcd(aInput: Double, bInput: Double): Double {
    if (aInput == 0.0) return 0.0

    var a = aInput
    var b = bInput
    // Make sure a is larger than b
    if (a < b) {
      val temp = a
      a = b
      b = temp
    }

    while (b > MINIMUM_DIVISOR) { // Minimum minecraft sensitivity
      val temp = a - (floor(a / b) * b)
      a = b
      b = temp
    }

    return a
  }
}
