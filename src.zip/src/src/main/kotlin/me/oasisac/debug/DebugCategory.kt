package me.oasisac.debug

enum class DebugCategory(val configKey: String) {
  AI_PROBABILITY("probability"),
  AI_API_TIMEOUT("api-error.timeout"),
  AI_API_NETWORK("api-error.network"),
  AI_API_RATE_LIMITED("api-error.rate-limited"),
  AI_API_SERVICE_UNAVAILABLE("api-error.service-unavailable"),
  AI_PERSISTENT_BUFFER("persistent-buffer"),
  RATE_LIMIT("rate-limit"),
  WORLDGUARD("worldguard"),
  PACKET_DUPLICATION("packet-duplication"),
}
