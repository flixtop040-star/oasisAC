package me.oasisac.debug

import java.util.EnumSet
import me.oasisac.OasisAC
import me.oasisac.config.ConfigManager

class DebugManager(private val plugin: OasisAC, private val configManager: ConfigManager) {
  private val enabledCategories: MutableSet<DebugCategory> =
    EnumSet.noneOf(DebugCategory::class.java)
  private var debugEnabled = false

  init {
    reload()
  }

  fun reload() {
    enabledCategories.clear()
    enabledCategories.addAll(configManager.enabledDebugCategories)
    debugEnabled = configManager.isDebugEnabled()
  }

  fun isEnabled(category: DebugCategory): Boolean {
    return debugEnabled && enabledCategories.contains(category)
  }

  fun log(category: DebugCategory, message: String) {
    if (isEnabled(category)) {
      plugin.logger.info("[DEBUG | ${category.name}] $message")
    }
  }
}
