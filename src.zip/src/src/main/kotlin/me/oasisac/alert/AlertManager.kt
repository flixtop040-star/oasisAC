package me.oasisac.alert

import java.util.EnumMap
import java.util.EnumSet
import java.util.UUID
import java.util.concurrent.CopyOnWriteArraySet
import me.oasisac.config.ConfigManager
import me.oasisac.config.LocaleManager
import me.oasisac.utils.Message
import me.oasisac.utils.MessageUtil
import net.kyori.adventure.audience.Audience
import net.kyori.adventure.platform.bukkit.BukkitAudiences
import net.kyori.adventure.text.Component
import org.bukkit.Bukkit
import org.bukkit.command.CommandSender
import org.bukkit.entity.Player

class AlertManager(
  private val configManager: ConfigManager,
  private val localeManager: LocaleManager,
  private val adventure: BukkitAudiences,
) {
  private val playersWithAlerts: MutableMap<AlertType, MutableSet<UUID>> =
    EnumMap(AlertType::class.java)
  private val consoleAlertsEnabled: MutableSet<AlertType> = EnumSet.allOf(AlertType::class.java)

  private var logToConsole = true

  var alertFormat: String = ""
    private set

  var brandAlertFormat: String = ""
    private set

  init {
    for (type in AlertType.values()) {
      playersWithAlerts[type] = CopyOnWriteArraySet()
    }
    reload()
  }

  fun reload() {
    logToConsole = configManager.config.getBoolean("alerts.print-to-console", true)
    alertFormat = localeManager.getRawMessage(Message.ALERTS_FORMAT)
    brandAlertFormat = localeManager.getRawMessage(Message.BRAND_NOTIFICATION)
  }

  fun toggle(player: Player, type: AlertType, silent: Boolean) {
    val playersSet = playersWithAlerts.getValue(type)
    val uuid = player.uniqueId

    if (playersSet.contains(uuid)) {
      playersSet.remove(uuid)
      if (!silent) {
        adventure(player).sendMessage(MessageUtil.getMessage(type.disabledMessage))
      }
    } else {
      playersSet.add(uuid)
      if (!silent) {
        adventure(player).sendMessage(MessageUtil.getMessage(type.enabledMessage))
      }
    }
  }

  fun send(component: Component, type: AlertType) {
    val playersSet = playersWithAlerts.getValue(type)
    val permission = type.permission

    for (uuid in playersSet) {
      val player = Bukkit.getPlayer(uuid)
      if (player != null && player.hasPermission(permission)) {
        adventure(player).sendMessage(component)
      }
    }

    if (logToConsole && consoleAlertsEnabled.contains(type)) {
      adventure(Bukkit.getConsoleSender()).sendMessage(component)
    }
  }

  fun hasAlertsEnabled(player: Player, type: AlertType): Boolean {
    return playersWithAlerts.getValue(type).contains(player.uniqueId)
  }

  fun isConsoleAlertsEnabled(type: AlertType): Boolean {
    return consoleAlertsEnabled.contains(type)
  }

  fun toggleConsoleAlerts(type: AlertType) {
    if (consoleAlertsEnabled.contains(type)) {
      consoleAlertsEnabled.remove(type)
    } else {
      consoleAlertsEnabled.add(type)
    }
  }

  fun handlePlayerQuit(player: Player) {
    val uuid = player.uniqueId
    for (players in playersWithAlerts.values) {
      players.remove(uuid)
    }
  }

  private fun adventure(player: Player): Audience {
    return adventure.player(player)
  }

  private fun adventure(sender: CommandSender): Audience {
    return adventure.sender(sender)
  }
}
