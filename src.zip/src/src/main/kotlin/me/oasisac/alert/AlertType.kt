package me.oasisac.alert

import me.oasisac.utils.Message

enum class AlertType(
  val permission: String,
  val enabledMessage: Message,
  val disabledMessage: Message,
) {
  REGULAR("oasisac.alerts", Message.ALERTS_ENABLED, Message.ALERTS_DISABLED),
  BRAND("oasisac.brand", Message.BRAND_ALERTS_ENABLED, Message.BRAND_ALERTS_DISABLED),
  SUSPICIOUS(
    "oasisac.suspicious.alerts",
    Message.SUSPICIOUS_ALERTS_ENABLED,
    Message.SUSPICIOUS_ALERTS_DISABLED,
  ),
}
