package me.oasisac.database

import com.zaxxer.hikari.HikariDataSource
import java.nio.file.Path
import java.util.logging.Level
import me.oasisac.config.ConfigManager
import org.flywaydb.core.api.FlywayException

internal class SqliteMigrationRecovery(
  private val environment: DatabaseEnvironment,
  private val configManager: ConfigManager,
  private val migrationExecutor: DatabaseMigrationExecutor,
) {

  fun migrate(initialDataSource: HikariDataSource): HikariDataSource {
    val databaseFile = resolveSqliteDatabaseFile(environment.dataDirectory, configManager)
    var backupFile: Path? = null

    fun ensureBackup(): Path? {
      if (backupFile != null || !sqliteDatabaseHasContent(databaseFile)) {
        return backupFile
      }

      return runCatching {
          createSqliteBackup(environment.dataDirectory, initialDataSource, databaseFile)
        }
        .onSuccess { createdBackup -> backupFile = createdBackup }
        .onFailure { exception ->
          environment.logger.log(
            Level.WARNING,
            "Failed to create a SQLite backup before migration recovery.",
            exception,
          )
        }
        .getOrNull()
    }

    return try {
      migrationExecutor.migrate(
        dataSource = initialDataSource,
        databaseType = DatabaseType.SQLITE,
        sqliteBackupSupplier = ::ensureBackup,
        announceCompat = false,
      )
      initialDataSource
    } catch (exception: FlywayException) {
      logMigrationFailure(ensureBackup())
      throw exception
    }
  }

  private fun logMigrationFailure(preservedBackup: Path?) {
    environment.logger.warning(
      buildString {
        append("SQLite migrations failed")
        preservedBackup?.let { append(". Preserved the previous database at $it") }
        append(". Oasis will switch to in-memory storage until the database issue is fixed.")
      }
    )
  }
}
