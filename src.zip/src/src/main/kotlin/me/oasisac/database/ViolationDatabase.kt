package me.oasisac.database

import java.util.UUID
import me.oasisac.monitor.MonitorSettings
import me.oasisac.player.OasisPlayer

interface ViolationDatabase {
  fun logAlert(player: OasisPlayer, verbose: String, checkName: String, vls: Int)

  fun getLogCount(player: UUID): Int

  fun getViolations(player: UUID, page: Int, limit: Int): List<Violation>

  fun getUniqueViolatorsSince(since: Long): Int

  fun recordLogin(playerUUID: UUID, timestamp: Long)

  fun countUniquePlayersSince(since: Long): Int

  fun saveAiBuffer(playerUUID: UUID, buffer: Double, updatedAt: Long)

  fun loadAiBuffer(playerUUID: UUID): AiBufferState?

  fun getLogCount(since: Long): Int

  fun getLogCounts(playerUUIDs: Collection<UUID>): Map<UUID, Int>

  fun getViolations(page: Int, limit: Int, since: Long): List<Violation>

  fun getViolationLevel(playerUUID: UUID, punishGroupName: String): Int

  fun incrementViolationLevel(playerUUID: UUID, punishGroupName: String): Int

  fun resetViolationLevel(playerUUID: UUID, punishGroupName: String)

  fun resetAllViolationLevels(playerUUID: UUID)

  fun loadMonitorSettings(playerUUID: UUID): MonitorSettings?

  fun saveMonitorSettings(playerUUID: UUID, settings: MonitorSettings)
}
