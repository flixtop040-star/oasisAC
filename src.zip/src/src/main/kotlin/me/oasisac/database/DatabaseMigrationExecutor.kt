package me.oasisac.database

import com.zaxxer.hikari.HikariDataSource
import java.nio.file.Path
import org.flywaydb.core.api.exception.FlywayValidateException

private const val SQLITE_BASELINE_LOG =
  "Detected a legacy SQLite schema without Flyway history. Baselining it explicitly before migrations."

internal class DatabaseMigrationExecutor(private val environment: DatabaseEnvironment) {

  fun migrate(
    dataSource: HikariDataSource,
    databaseType: DatabaseType,
    sqliteBackupSupplier: (() -> Path?)? = null,
    announceCompat: Boolean = true,
  ) {
    var activeFlyway =
      buildMigrationFlyway(
        environment.classLoader,
        environment.logger,
        dataSource,
        databaseType,
        announceCompat,
      )
    if (requiresExplicitBaseline(dataSource, databaseType)) {
      environment.logger.info(SQLITE_BASELINE_LOG)
      activeFlyway.baseline()
      activeFlyway =
        buildMigrationFlyway(
          environment.classLoader,
          environment.logger,
          dataSource,
          databaseType,
          announceCompat,
        )
    }

    try {
      activeFlyway.migrate()
    } catch (exception: FlywayValidateException) {
      val validation = activeFlyway.validateWithResult()
      if (
        databaseType == DatabaseType.SQLITE &&
          isRepairableSqliteV1ChecksumMismatch(validation, dataSource)
      ) {
        val backupPath = sqliteBackupSupplier?.invoke()
        environment.logger.warning(
          buildString {
            append("Detected a legacy SQLite checksum mismatch for migration V1")
            backupPath?.let { append(". Preserved the previous database at $it") }
            append(". Repairing Flyway schema history automatically.")
          }
        )
        activeFlyway.repair()
        activeFlyway =
          buildMigrationFlyway(
            environment.classLoader,
            environment.logger,
            dataSource,
            databaseType,
          )
        activeFlyway.migrate()
      } else {
        throw exception
      }
    }
  }
}
