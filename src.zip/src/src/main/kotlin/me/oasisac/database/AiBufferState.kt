package me.oasisac.database

data class AiBufferState(val buffer: Double, val updatedAt: Long)
