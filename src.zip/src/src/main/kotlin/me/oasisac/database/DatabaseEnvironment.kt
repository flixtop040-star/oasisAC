package me.oasisac.database

import java.nio.file.Path
import java.util.logging.Logger

internal data class DatabaseEnvironment(
  val dataDirectory: Path,
  val logger: Logger,
  val classLoader: ClassLoader,
)
