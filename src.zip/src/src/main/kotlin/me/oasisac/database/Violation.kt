package me.oasisac.database

import java.sql.ResultSet
import java.sql.SQLException
import java.time.Instant
import java.util.UUID

data class Violation(
  val serverName: String,
  val playerUUID: UUID,
  val playerName: String,
  val checkName: String,
  val verbose: String,
  val vl: Int,
  val createdAt: Instant,
) {
  companion object {
    @Throws(SQLException::class)
    fun fromResultSet(resultSet: ResultSet): List<Violation> {
      val violations = ArrayList<Violation>()
      while (resultSet.next()) {
        val server = resultSet.getString("server")
        val player = UUID.fromString(resultSet.getString("uuid"))
        val playerName = resultSet.getString("player_name")

        val checkName = resultSet.getString("check_name")
        val verbose = resultSet.getString("verbose")
        val vl = resultSet.getInt("vl")
        val createdAt = Instant.ofEpochMilli(resultSet.getLong("created_at"))
        violations.add(Violation(server, player, playerName, checkName, verbose, vl, createdAt))
      }
      return violations
    }
  }
}
