package me.oasisac.database

import java.util.concurrent.atomic.AtomicReference

internal enum class DatabaseMode {
  PERSISTENT,
  DEGRADED_IN_MEMORY,
}

internal class DatabaseHealth {
  private val modeRef = AtomicReference(DatabaseMode.PERSISTENT)

  @Volatile private var failure: Throwable? = null

  val mode: DatabaseMode
    get() = modeRef.get()

  val failureCause: Throwable?
    get() = failure

  fun isPersistentAvailable(): Boolean = mode == DatabaseMode.PERSISTENT

  fun markPersistent() {
    failure = null
    modeRef.set(DatabaseMode.PERSISTENT)
  }

  fun markDegraded(cause: Throwable) {
    failure = cause
    modeRef.set(DatabaseMode.DEGRADED_IN_MEMORY)
  }
}
