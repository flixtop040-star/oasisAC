package me.oasisac.punishment

import java.util.Locale
import java.util.NavigableMap
import me.oasisac.checks.ICheck

class PunishGroup(
  val groupName: String,
  checkNames: List<String>,
  val actions: NavigableMap<Int, List<String>>,
) {
  val associatedCheckNames: Set<String> = checkNames.map { it.lowercase(Locale.ROOT) }.toSet()

  fun isCheckAssociated(check: ICheck): Boolean {
    val checkNameLower = check.checkName.lowercase(Locale.ROOT)
    for (filter in associatedCheckNames) {
      if (checkNameLower.contains(filter)) {
        return true
      }
    }
    return false
  }
}
