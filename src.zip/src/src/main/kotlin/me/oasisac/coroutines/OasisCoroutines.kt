package me.oasisac.coroutines

import java.io.Closeable
import java.util.logging.Level
import java.util.logging.Logger
import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import me.oasisac.scheduler.SchedulerService

class OasisCoroutines(private val scheduler: SchedulerService, private val logger: Logger) :
  Closeable {
  val main: CoroutineDispatcher =
    object : CoroutineDispatcher() {
      override fun dispatch(context: CoroutineContext, block: Runnable) {
        scheduler.runSync(block)
      }
    }

  val async: CoroutineDispatcher =
    object : CoroutineDispatcher() {
      override fun dispatch(context: CoroutineContext, block: Runnable) {
        scheduler.runAsync(block)
      }
    }

  private val job = SupervisorJob()
  private val exceptionHandler = CoroutineExceptionHandler { _, throwable ->
    logger.log(Level.SEVERE, "Uncaught coroutine error", throwable)
  }

  val scope: CoroutineScope = CoroutineScope(job + async + exceptionHandler)

  override fun close() {
    job.cancel()
  }
}
