package me.oasisac.player

import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import org.bukkit.entity.Player

class ExemptManager {
  private val temporaryExemptions = ConcurrentHashMap<UUID, Long>()

  fun isDisabled(player: Player?): Boolean {
    return player?.hasPermission(DISABLE_PERMISSION) == true
  }

  fun isExempt(player: Player?): Boolean {
    if (player == null) {
      return false
    }
    if (player.hasPermission(EXEMPT_PERMISSION)) {
      return true
    }

    val expiryTime = temporaryExemptions[player.uniqueId] ?: return false
    if (expiryTime != -1L && System.currentTimeMillis() > expiryTime) {
      temporaryExemptions.remove(player.uniqueId)
      return false
    }
    return true
  }

  fun addExemption(uuid: UUID, durationMillis: Long) {
    if (durationMillis == -1L) {
      temporaryExemptions[uuid] = -1L
      return
    }
    val expiryTime = System.currentTimeMillis() + durationMillis
    temporaryExemptions[uuid] = expiryTime
  }

  fun removeExemption(uuid: UUID): Boolean {
    return temporaryExemptions.remove(uuid) != null
  }

  fun getExpiryTime(uuid: UUID): Long? {
    return temporaryExemptions[uuid]
  }

  companion object {
    const val EXEMPT_PERMISSION = "oasisac.exempt"
    const val DISABLE_PERMISSION = "oasisac.disable"
  }
}
