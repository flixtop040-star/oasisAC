package me.oasisac.player

import com.github.retrooper.packetevents.protocol.player.ClientVersion
import com.github.retrooper.packetevents.protocol.player.GameMode
import com.github.retrooper.packetevents.protocol.player.User
import com.github.retrooper.packetevents.protocol.teleport.RelativeFlag
import com.github.retrooper.packetevents.util.Vector3d
import java.util.Queue
import java.util.UUID
import java.util.concurrent.ConcurrentLinkedQueue
import me.oasisac.OasisAC
import me.oasisac.alert.AlertManager
import me.oasisac.api.event.OasisEventBus
import me.oasisac.checks.CheckManager
import me.oasisac.checks.impl.ai.DataCollectorManager
import me.oasisac.config.ConfigManager
import me.oasisac.entity.CompensatedEntities
import me.oasisac.player.state.CombatState
import me.oasisac.player.state.MovementState
import me.oasisac.player.state.TransactionTracker
import me.oasisac.punishment.PunishmentManager
import me.oasisac.scheduler.SchedulerService
import me.oasisac.server.AIServerProvider
import me.oasisac.utils.data.HeadRotation
import me.oasisac.utils.data.PacketStateData
import me.oasisac.utils.latency.ILatencyUtils
import me.oasisac.utils.latency.LatencyUtils
import me.oasisac.utils.update.RotationUpdate
import net.kyori.adventure.text.Component
import org.bukkit.entity.Player

class OasisPlayer
@Suppress("LongParameterList")
constructor(
  val player: Player,
  val user: User,
  private val plugin: OasisAC,
  private val configManager: ConfigManager,
  aiSequence: Int,
  alertManager: AlertManager,
  dataCollectorManager: DataCollectorManager,
  aiServerProvider: AIServerProvider,
  val exemptManager: ExemptManager,
  private val scheduler: SchedulerService,
  checkManagerFactory: CheckManager.Factory,
  punishmentManagerFactory: PunishmentManager.Factory,
  val eventBus: OasisEventBus,
) {
  val uuid: UUID = player.uniqueId
  val packetStateData: PacketStateData = PacketStateData()
  val rotationUpdate: RotationUpdate = RotationUpdate(HeadRotation(), HeadRotation(), 0f, 0f)
  val joinTime: Long = System.currentTimeMillis()

  var entityId: Int = 0
  var gameMode: GameMode = GameMode.SURVIVAL
  var brand: String = "vanilla"

  val movement: MovementState = MovementState()
  val combat: CombatState = CombatState(aiSequence + 1)
  val transactions: TransactionTracker = TransactionTracker()

  val pendingTeleports: Queue<TeleportData> = ConcurrentLinkedQueue()
  val pendingRotations: Queue<RotationData> = ConcurrentLinkedQueue()

  val compensatedEntities: CompensatedEntities = CompensatedEntities(this)
  val latencyUtils: ILatencyUtils = LatencyUtils(this, plugin)
  val checkManager: CheckManager = checkManagerFactory.create(this)
  val punishmentManager: PunishmentManager = punishmentManagerFactory.create(this)

  private var cancelDuplicatePacket = true
  private var forceCancelDuplicatePacket = false
  private var ignoreDuplicatePacketRotation = true

  init {
    refreshDuplicatePacketSettings()
  }

  fun isPointThree(): Boolean = user.clientVersion.isOlderThan(ClientVersion.V_1_18_2)

  fun getMovementThreshold(): Double = if (isPointThree()) 0.03 else 0.0002

  fun isCancelDuplicatePacket(): Boolean = cancelDuplicatePacket

  fun isForceCancelDuplicatePacket(): Boolean = forceCancelDuplicatePacket

  fun isIgnoreDuplicatePacketRotation(): Boolean = ignoreDuplicatePacketRotation

  fun sendTransaction() {
    transactions.sendTransaction(user)
  }

  fun disconnect(reason: Component) {
    user.sendPacket(
      com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerDisconnect(reason)
    )
    user.closeConnection()

    scheduler.runSync(player) { player.kick(reason) }
  }

  fun reload() {
    refreshDuplicatePacketSettings()
    punishmentManager.reload()
    checkManager.reloadChecks()
  }

  private fun refreshDuplicatePacketSettings() {
    cancelDuplicatePacket = configManager.cancelDuplicatePacket
    forceCancelDuplicatePacket = configManager.forceCancelDuplicatePacket
    ignoreDuplicatePacketRotation = configManager.ignoreDuplicatePacketRotation
  }

  class TeleportData(val location: Vector3d, val flags: RelativeFlag, val transactionId: Int) {
    fun isRelativeX(): Boolean = flags.has(RelativeFlag.X)

    fun isRelativeY(): Boolean = flags.has(RelativeFlag.Y)

    fun isRelativeZ(): Boolean = flags.has(RelativeFlag.Z)
  }

  class RotationData(val yaw: Float, val pitch: Float, val transactionId: Int)
}
