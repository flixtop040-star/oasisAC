package me.oasisac.player

import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import me.oasisac.OasisAC
import me.oasisac.alert.AlertManager
import me.oasisac.alert.AlertType
import me.oasisac.api.event.OasisEventBus
import me.oasisac.checks.CheckManager
import me.oasisac.checks.impl.ai.DataCollectorManager
import me.oasisac.checks.impl.ai.PersistentBufferService
import me.oasisac.config.ConfigManager
import me.oasisac.database.DatabaseManager
import me.oasisac.punishment.PunishmentManager
import me.oasisac.scheduler.SchedulerService
import me.oasisac.server.AIServerProvider
import org.bukkit.entity.Player
import org.bukkit.event.EventHandler
import org.bukkit.event.Listener
import org.bukkit.event.player.PlayerQuitEvent

class PlayerDataManager
@Suppress("LongParameterList")
constructor(
  private val plugin: OasisAC,
  private val alertManager: AlertManager,
  private val dataCollectorManager: DataCollectorManager,
  private val configManager: ConfigManager,
  private val aiServerProvider: AIServerProvider,
  private val exemptManager: ExemptManager,
  private val scheduler: SchedulerService,
  private val checkManagerFactory: CheckManager.Factory,
  private val punishmentManagerFactory: PunishmentManager.Factory,
  private val eventBus: OasisEventBus,
  private val databaseManager: DatabaseManager,
  private val persistentBufferService: PersistentBufferService,
) : Listener {
  private val players = ConcurrentHashMap<UUID, OasisPlayer>()

  init {
    plugin.server.pluginManager.registerEvents(this, plugin)
  }

  @EventHandler
  fun onQuit(event: PlayerQuitEvent) {
    cleanupPlayer(event.player.uniqueId, event.player)
  }

  private fun cleanupPlayer(uuid: UUID, player: Player?) {
    if (dataCollectorManager.getSession(uuid) != null) {
      dataCollectorManager.stopCollecting(uuid)
    }
    if (player != null) {
      runCatching { alertManager.handlePlayerQuit(player) }
        .onFailure {
          plugin.logger.log(
            java.util.logging.Level.WARNING,
            "alertManager.handlePlayerQuit failed for ${player.name}",
            it,
          )
        }
    }
    val tracked = players.remove(uuid) ?: return
    scheduler.runAsync { persistentBufferService.saveOnQuit(tracked) }
  }

  fun saveAllBuffersSync() {
    for (oasisacPlayer in players.values) {
      persistentBufferService.saveOnShutdown(oasisacPlayer)
    }
  }

  fun getPlayer(player: Player?): OasisPlayer? {
    if (player == null) {
      return null
    }
    return players[player.uniqueId]
  }

  fun getPlayer(uuid: UUID): OasisPlayer? {
    return players[uuid]
  }

  fun getPlayers(): Collection<OasisPlayer> {
    return players.values
  }

  fun handleUserLogin(
    user: com.github.retrooper.packetevents.protocol.player.User,
    player: Player,
  ) {
    scheduler.runSync(
      player,
      Runnable {
        if (!player.isOnline || players.containsKey(player.uniqueId)) {
          return@Runnable
        }

        val loginTimestamp = System.currentTimeMillis()
        val playerUuid = player.uniqueId
        scheduler.runAsync { databaseManager.database.recordLogin(playerUuid, loginTimestamp) }

        val oasisacPlayer =
          OasisPlayer(
            player = player,
            user = user,
            plugin = plugin,
            configManager = configManager,
            aiSequence = configManager.aiSequence,
            alertManager = alertManager,
            dataCollectorManager = dataCollectorManager,
            aiServerProvider = aiServerProvider,
            exemptManager = exemptManager,
            scheduler = scheduler,
            checkManagerFactory = checkManagerFactory,
            punishmentManagerFactory = punishmentManagerFactory,
            eventBus = eventBus,
          )
        players[player.uniqueId] = oasisacPlayer
        persistentBufferService.restoreOnLogin(oasisacPlayer)

        if (
          player.hasPermission("oasisac.alerts") &&
            player.hasPermission("oasisac.alerts.enable-on-join")
        ) {
          if (!alertManager.hasAlertsEnabled(player, AlertType.REGULAR)) {
            alertManager.toggle(player, AlertType.REGULAR, true)
          }
        }

        if (
          player.hasPermission("oasisac.brand") &&
            player.hasPermission("oasisac.brand.enable-on-join")
        ) {
          if (!alertManager.hasAlertsEnabled(player, AlertType.BRAND)) {
            alertManager.toggle(player, AlertType.BRAND, true)
          }
        }

        if (
          player.hasPermission("oasisac.suspicious.alerts") &&
            player.hasPermission("oasisac.suspicious.alerts.enable-on-join")
        ) {
          if (!alertManager.hasAlertsEnabled(player, AlertType.SUSPICIOUS)) {
            alertManager.toggle(player, AlertType.SUSPICIOUS, true)
          }
        }
      },
    )
  }

  fun handleUserDisconnect(user: com.github.retrooper.packetevents.protocol.player.User) {
    val uuid = user.uuid ?: return
    cleanupPlayer(uuid, players[uuid]?.player)
  }

  fun reloadAllPlayers() {
    for (oasisacPlayer in players.values) {
      oasisacPlayer.reload()
    }
  }
}
