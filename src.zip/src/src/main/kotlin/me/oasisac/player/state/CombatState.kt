package me.oasisac.player.state

class CombatState(initialTicksSinceAttack: Int) {
  var ticksSinceAttack: Int = initialTicksSinceAttack
  var damageMultiplier: Double = 1.0
}
