package me.oasisac.player.state

import com.github.retrooper.packetevents.PacketEvents
import com.github.retrooper.packetevents.protocol.player.User
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerPing
import com.github.retrooper.packetevents.wrapper.play.server.WrapperPlayServerWindowConfirmation
import it.unimi.dsi.fastutil.ints.IntArraySet
import java.util.Queue
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import me.oasisac.player.TransactionStamp

class TransactionTracker {
  val transactionsSent: Queue<TransactionStamp> = ConcurrentLinkedQueue()
  val entitiesDespawnedThisTransaction: IntArraySet = IntArraySet()
  val didWeSendThatTrans: MutableSet<Short> = ConcurrentHashMap.newKeySet<Short>()
  val lastTransactionSent: AtomicInteger = AtomicInteger(0)
  val lastTransactionReceived: AtomicInteger = AtomicInteger(0)
  private val transactionIdCounter: AtomicInteger = AtomicInteger(0)

  fun sendTransaction(user: User) {
    if (user.connectionState != com.github.retrooper.packetevents.protocol.ConnectionState.PLAY) {
      return
    }

    val transactionId = (-1 * (transactionIdCounter.getAndIncrement() and 0x7FFF)).toShort()
    didWeSendThatTrans.add(transactionId)

    val packet =
      if (
        PacketEvents.getAPI()
          .serverManager
          .version
          .isNewerThanOrEquals(
            com.github.retrooper.packetevents.manager.server.ServerVersion.V_1_17
          )
      ) {
        WrapperPlayServerPing(transactionId.toInt())
      } else {
        WrapperPlayServerWindowConfirmation(0, transactionId, false)
      }
    user.sendPacket(packet)
  }
}
