package me.oasisac.player.state

class MovementState {
  var x: Double = 0.0
  var y: Double = 0.0
  var z: Double = 0.0
  var yaw: Float = 0f
  var pitch: Float = 0f
  var lastYaw: Float = 0f
  var lastPitch: Float = 0f
}
