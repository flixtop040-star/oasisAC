package me.oasisac.player

data class TransactionStamp(val id: Short, val timeNanos: Long)
