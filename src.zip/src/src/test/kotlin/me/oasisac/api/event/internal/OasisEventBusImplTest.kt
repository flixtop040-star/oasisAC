package me.oasisac.api.event.internal

import kotlin.test.assertEquals
import kotlin.test.assertTrue
import me.oasisac.api.event.OasisCancellableEvent
import me.oasisac.api.event.OasisEvent
import me.oasisac.api.event.OasisEventListener
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test

class OasisEventBusImplTest {

  private lateinit var bus: OasisEventBusImpl
  private val context = Any()

  @BeforeEach
  fun setUp() {
    bus = OasisEventBusImpl()
  }

  // --- Test event types ---

  private class SimpleEvent : OasisEvent

  private open class ParentEvent : OasisEvent

  private class ChildEvent : ParentEvent()

  private class CancellableTestEvent : OasisCancellableEvent {
    override var cancelled: Boolean = false
  }

  // --- Basic dispatch ---

  @Test
  fun `post delivers event to subscriber`() {
    val received = mutableListOf<OasisEvent>()
    bus.subscribe(context, SimpleEvent::class.java, OasisEventListener { received.add(it) })

    bus.post(SimpleEvent())
    assertEquals(1, received.size)
  }

  @Test
  fun `post with no subscribers does not throw`() {
    bus.post(SimpleEvent())
  }

  @Test
  fun `multiple subscribers all receive event`() {
    var count = 0
    bus.subscribe(context, SimpleEvent::class.java, OasisEventListener { count++ })
    bus.subscribe(context, SimpleEvent::class.java, OasisEventListener { count++ })
    bus.subscribe(context, SimpleEvent::class.java, OasisEventListener { count++ })

    bus.post(SimpleEvent())
    assertEquals(3, count)
  }

  // --- Priority ordering ---

  @Test
  fun `higher priority listeners execute first`() {
    val order = mutableListOf<String>()

    bus.subscribe(
      context,
      SimpleEvent::class.java,
      OasisEventListener { order.add("low") },
      priority = 1,
      ignoreCancelled = false,
    )
    bus.subscribe(
      context,
      SimpleEvent::class.java,
      OasisEventListener { order.add("high") },
      priority = 10,
      ignoreCancelled = false,
    )
    bus.subscribe(
      context,
      SimpleEvent::class.java,
      OasisEventListener { order.add("mid") },
      priority = 5,
      ignoreCancelled = false,
    )

    bus.post(SimpleEvent())
    assertEquals(listOf("high", "mid", "low"), order)
  }

  @Test
  fun `same priority listeners all execute`() {
    var count = 0
    bus.subscribe(
      context,
      SimpleEvent::class.java,
      OasisEventListener { count++ },
      priority = 5,
      ignoreCancelled = false,
    )
    bus.subscribe(
      context,
      SimpleEvent::class.java,
      OasisEventListener { count++ },
      priority = 5,
      ignoreCancelled = false,
    )

    bus.post(SimpleEvent())
    assertEquals(2, count)
  }

  // --- Cancellable events ---

  @Test
  fun `cancelled event skips non-ignoreCancelled listeners`() {
    val received = mutableListOf<String>()

    bus.subscribe(
      context,
      CancellableTestEvent::class.java,
      OasisEventListener {
        it.cancelled = true
        received.add("canceller")
      },
      priority = 10,
      ignoreCancelled = false,
    )

    bus.subscribe(
      context,
      CancellableTestEvent::class.java,
      OasisEventListener { received.add("skipped") },
      priority = 1,
      ignoreCancelled = false,
    )

    bus.post(CancellableTestEvent())
    assertEquals(listOf("canceller"), received)
  }

  @Test
  fun `ignoreCancelled listener still receives cancelled event`() {
    val received = mutableListOf<String>()

    bus.subscribe(
      context,
      CancellableTestEvent::class.java,
      OasisEventListener {
        it.cancelled = true
        received.add("canceller")
      },
      priority = 10,
      ignoreCancelled = false,
    )

    bus.subscribe(
      context,
      CancellableTestEvent::class.java,
      OasisEventListener { received.add("monitor") },
      priority = 1,
      ignoreCancelled = true,
    )

    bus.post(CancellableTestEvent())
    assertEquals(listOf("canceller", "monitor"), received)
  }

  // --- Hierarchy dispatch ---

  @Test
  fun `child event dispatched to parent subscriber`() {
    var parentReceived = false
    bus.subscribe(context, ParentEvent::class.java, OasisEventListener { parentReceived = true })

    bus.post(ChildEvent())
    assertTrue(parentReceived)
  }

  @Test
  fun `child event dispatched to both child and parent subscribers`() {
    val received = mutableListOf<String>()
    bus.subscribe(context, ChildEvent::class.java, OasisEventListener { received.add("child") })
    bus.subscribe(context, ParentEvent::class.java, OasisEventListener { received.add("parent") })

    bus.post(ChildEvent())
    assertTrue(received.contains("child"))
    assertTrue(received.contains("parent"))
  }

  // --- Unregister ---

  @Test
  fun `unregisterListener removes specific listener`() {
    var count = 0
    val listener = OasisEventListener<SimpleEvent> { count++ }
    bus.subscribe(context, SimpleEvent::class.java, listener)

    bus.post(SimpleEvent())
    assertEquals(1, count)

    bus.unregisterListener(context, listener)
    bus.post(SimpleEvent())
    assertEquals(1, count)
  }

  @Test
  fun `unregisterAll removes all listeners for context`() {
    var count = 0
    val ctx1 = Any()
    val ctx2 = Any()
    bus.subscribe(ctx1, SimpleEvent::class.java, OasisEventListener { count++ })
    bus.subscribe(ctx2, SimpleEvent::class.java, OasisEventListener { count++ })

    bus.post(SimpleEvent())
    assertEquals(2, count)

    bus.unregisterAll(ctx1)
    bus.post(SimpleEvent())
    assertEquals(3, count) // only ctx2 listener fires
  }

  @Test
  fun `unregisterAll with unknown context does not throw`() {
    bus.unregisterAll(Any())
  }

  // --- Error isolation ---

  @Test
  fun `listener exception does not prevent other listeners from running`() {
    val received = mutableListOf<String>()

    bus.subscribe(
      context,
      SimpleEvent::class.java,
      OasisEventListener { received.add("before") },
      priority = 10,
      ignoreCancelled = false,
    )

    bus.subscribe(
      context,
      SimpleEvent::class.java,
      OasisEventListener { throw IllegalStateException("boom") },
      priority = 5,
      ignoreCancelled = false,
    )

    bus.subscribe(
      context,
      SimpleEvent::class.java,
      OasisEventListener { received.add("after") },
      priority = 1,
      ignoreCancelled = false,
    )

    bus.post(SimpleEvent())
    assertEquals(listOf("before", "after"), received)
  }
}
