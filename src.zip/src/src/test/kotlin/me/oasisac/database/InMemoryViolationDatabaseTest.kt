package me.oasisac.database

import io.mockk.every
import io.mockk.mockk
import java.util.UUID
import kotlin.test.assertEquals
import kotlin.test.assertNull
import me.oasisac.config.ConfigManager
import me.oasisac.monitor.MonitorMode
import me.oasisac.monitor.MonitorNameMode
import me.oasisac.monitor.MonitorSettings
import me.oasisac.monitor.MonitorTheme
import me.oasisac.player.OasisPlayer
import org.bukkit.entity.Player
import org.junit.jupiter.api.Test

class InMemoryViolationDatabaseTest {

  @Test
  fun `stores alerts in memory with working counts paging and time filters`() {
    val configManager = mockk<ConfigManager>(relaxed = true)
    every { configManager.config.getString("history.server-name", any()) } returns "test-server"
    val database = InMemoryViolationDatabase(configManager)
    val firstPlayer = createPlayer(UUID.fromString("00000000-0000-0000-0000-000000000001"), "Alpha")
    val secondPlayer =
      createPlayer(UUID.fromString("00000000-0000-0000-0000-000000000002"), "Bravo")

    database.logAlert(firstPlayer, "first", "Aim", 1)
    val afterFirstInsert =
      database
        .getViolations(firstPlayer.uuid, page = 1, limit = 1)
        .single()
        .createdAt
        .toEpochMilli() + 1
    Thread.sleep(5)
    database.logAlert(secondPlayer, "second", "Reach", 2)

    assertEquals(1, database.getLogCount(firstPlayer.uuid))
    assertEquals(1, database.getLogCount(secondPlayer.uuid))
    assertEquals(2, database.getLogCount(0))
    assertEquals(1, database.getLogCount(afterFirstInsert))
    assertEquals(2, database.getUniqueViolatorsSince(0))
    assertEquals(1, database.getUniqueViolatorsSince(afterFirstInsert))
    assertEquals(
      1,
      database.getLogCounts(listOf(firstPlayer.uuid, secondPlayer.uuid))[firstPlayer.uuid],
    )
    assertEquals(
      listOf("second", "first"),
      database.getViolations(page = 1, limit = 10, since = 0).map(Violation::verbose),
    )
    assertEquals(
      listOf("first"),
      database.getViolations(firstPlayer.uuid, page = 1, limit = 10).map(Violation::verbose),
    )
  }

  @Test
  fun `stores punishment levels and monitor settings in degraded runtime`() {
    val configManager = mockk<ConfigManager>(relaxed = true)
    every { configManager.config.getString("history.server-name", any()) } returns "test-server"
    val database = InMemoryViolationDatabase(configManager)
    val playerId = UUID.randomUUID()
    val settings =
      MonitorSettings(
        mode = MonitorMode.COMPACT,
        theme = MonitorTheme.CALM,
        showPing = true,
        showDmg = true,
        showTrend = false,
        showName = MonitorNameMode.AUTO,
      )

    assertEquals(1, database.incrementViolationLevel(playerId, "default"))
    assertEquals(2, database.incrementViolationLevel(playerId, "default"))
    assertEquals(2, database.getViolationLevel(playerId, "default"))

    database.saveMonitorSettings(playerId, settings)
    assertEquals(settings, database.loadMonitorSettings(playerId))

    database.resetViolationLevel(playerId, "default")
    assertEquals(0, database.getViolationLevel(playerId, "default"))

    database.incrementViolationLevel(playerId, "combat")
    database.incrementViolationLevel(playerId, "movement")
    database.resetAllViolationLevels(playerId)
    assertEquals(0, database.getViolationLevel(playerId, "combat"))
    assertEquals(0, database.getViolationLevel(playerId, "movement"))
    assertNull(database.loadMonitorSettings(UUID.randomUUID()))
  }

  private fun createPlayer(uuid: UUID, name: String): OasisPlayer {
    val bukkitPlayer = mockk<Player>(relaxed = true)
    every { bukkitPlayer.name } returns name

    val oasisacPlayer = mockk<OasisPlayer>(relaxed = true)
    every { oasisacPlayer.uuid } returns uuid
    every { oasisacPlayer.player } returns bukkitPlayer
    return oasisacPlayer
  }
}
