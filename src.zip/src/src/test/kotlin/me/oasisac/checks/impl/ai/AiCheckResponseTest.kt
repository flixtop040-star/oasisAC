package me.oasisac.checks.impl.ai

import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import java.lang.reflect.Method
import java.util.UUID
import java.util.logging.Logger
import kotlin.test.assertEquals
import me.oasisac.OasisAC
import me.oasisac.ai.AiResult
import me.oasisac.ai.AiService
import me.oasisac.alert.AlertManager
import me.oasisac.api.event.OasisEventBus
import me.oasisac.config.ConfigManager
import me.oasisac.damage.DamageProcessor
import me.oasisac.debug.DebugCategory
import me.oasisac.debug.DebugManager
import me.oasisac.player.OasisPlayer
import me.oasisac.player.state.CombatState
import me.oasisac.punishment.PunishmentManager
import me.oasisac.region.RegionProvider
import me.oasisac.scheduler.SchedulerService
import me.oasisac.server.AIResponse
import org.bukkit.entity.Player
import org.junit.jupiter.api.Test

class AiCheckResponseTest {

  @Test
  fun `probability debug log uses fixed formatting only when enabled`() {
    val fixture =
      createFixture(debugEnabled = true, enabledCategories = setOf(DebugCategory.AI_PROBABILITY))

    fixture.invokeOnResponse(0.42)

    verify(exactly = 1) {
      fixture.logger.info(
        "[DEBUG | AI_PROBABILITY] [TestPlayer] Prob: 0.4200 | Buffer: 0.00 -> 0.00 | Damage Multiplier: 1.00"
      )
    }
  }

  @Test
  fun `flag debug string uses compact fixed formatting`() {
    val fixture = createFixture(aiFlag = 0.5, bufferMultiplier = 20.0)

    fixture.invokeOnResponse(0.95)

    verify(exactly = 1) {
      fixture.punishmentManager.handleFlag(fixture.check, "prob=0.95 buffer=1.0")
    }
    assertEquals(0.0, fixture.check.buffer)
  }

  @Test
  fun `ai formatting helpers use stable decimal output`() {
    assertEquals("1.0", formatAiBuffer(1.04))
    assertEquals("0.95", formatAiProbability(0.945))
    assertEquals("0.4200", formatAiProbabilityVerbose(0.42))
  }

  private fun createFixture(
    debugEnabled: Boolean = false,
    enabledCategories: Set<DebugCategory> = emptySet(),
    aiFlag: Double = 10.0,
    bufferMultiplier: Double = 1.0,
  ): Fixture {
    val logger = mockk<Logger>(relaxed = true)
    val plugin = mockk<OasisAC>(relaxed = true)
    every { plugin.logger } returns logger

    val aiService = mockk<AiService>(relaxed = true)
    every { aiService.isEnabled } returns true

    val configManager = mockk<ConfigManager>(relaxed = true)
    every { configManager.aiSequence } returns 40
    every { configManager.aiStep } returns 1
    every { configManager.aiFlag } returns aiFlag
    every { configManager.aiResetOnFlag } returns 0.0
    every { configManager.aiBufferMultiplier } returns bufferMultiplier
    every { configManager.aiBufferDecrease } returns 0.25
    every { configManager.suspiciousAlertsBuffer } returns 25.0
    every { configManager.enabledDebugCategories } returns enabledCategories
    every { configManager.isDebugEnabled() } returns debugEnabled

    val player = mockk<Player>(relaxed = true)
    every { player.name } returns "TestPlayer"
    every { player.uniqueId } returns UUID.fromString("00000000-0000-0000-0000-000000000001")

    val eventBus = mockk<OasisEventBus>(relaxed = true)
    val punishmentManager = mockk<PunishmentManager>(relaxed = true)
    val combat = CombatState(0)

    val oasisacPlayer = mockk<OasisPlayer>(relaxed = true)
    every { oasisacPlayer.player } returns player
    every { oasisacPlayer.uuid } returns player.uniqueId
    every { oasisacPlayer.eventBus } returns eventBus
    every { oasisacPlayer.punishmentManager } returns punishmentManager
    every { oasisacPlayer.combat } returns combat

    val check =
      AiCheck(
        oasisacPlayer = oasisacPlayer,
        plugin = plugin,
        aiService = aiService,
        configManager = configManager,
        regionProvider = mockk<RegionProvider>(relaxed = true),
        alertManager = mockk<AlertManager>(relaxed = true),
        damageProcessor = mockk<DamageProcessor>(relaxed = true),
        debugManager = DebugManager(plugin, configManager),
        scheduler = mockk<SchedulerService>(relaxed = true),
      )

    return Fixture(check, logger, punishmentManager)
  }

  private data class Fixture(
    val check: AiCheck,
    val logger: Logger,
    val punishmentManager: PunishmentManager,
  ) {
    fun invokeOnResponse(probability: Double) {
      onResponseMethod.invoke(
        check,
        AiResult(AIResponse(probability), """{"probability":$probability}""", null, false),
      )
    }
  }

  private companion object {
    val onResponseMethod: Method =
      AiCheck::class.java.getDeclaredMethod("onResponse", AiResult::class.java).apply {
        isAccessible = true
      }
  }
}
