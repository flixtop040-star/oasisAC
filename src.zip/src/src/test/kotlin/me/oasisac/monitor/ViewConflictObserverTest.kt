package me.oasisac.monitor

import com.github.retrooper.packetevents.event.PacketSendEvent
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import java.util.UUID
import kotlin.test.Test
import me.oasisac.scheduler.SchedulerService

class ViewConflictObserverTest {
  @Test
  fun `send event without bukkit player is ignored`() {
    val scheduler = mockk<SchedulerService>(relaxed = true)
    val coordinator = mockk<ViewSessionCoordinator>(relaxed = true)
    val belowNameConflicts = mockk<ViewBelowNameConflictCoordinator>(relaxed = true)
    val event = mockk<PacketSendEvent>()
    every { event.getPlayer<Any>() } returns Any()

    val observer =
      ViewConflictObserver(scheduler, coordinator, belowNameConflicts) { _: UUID -> null }

    observer.onPacketSend(event)

    verify(exactly = 0) { coordinator.session(any()) }
  }
}
