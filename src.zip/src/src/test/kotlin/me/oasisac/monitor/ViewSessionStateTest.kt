package me.oasisac.monitor

import java.util.UUID
import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertNull

class ViewSessionStateTest {
  @Test
  fun `tracked entity ids are replaced and cleaned up consistently`() {
    val targetId = UUID.randomUUID()
    val session = ViewSession(TEST_CONFIG, ViewPlacement.ABOVE_NAME, null)

    session.updateTrackedEntityId(targetId, 17)
    assertEquals(targetId, session.targetIdByEntityId(17))

    session.updateTrackedEntityId(targetId, 23)
    assertNull(session.targetIdByEntityId(17))
    assertEquals(targetId, session.targetIdByEntityId(23))

    session.removeTrackedEntityId(targetId)
    assertNull(session.targetIdByEntityId(23))
  }

  private companion object {
    private val TEST_CONFIG =
      ViewRuntimeConfig(
        updateTicks = 2,
        rebindCycles = 10,
        resyncCycles = 50,
        pingRefreshCycles = 20,
        pingBucketMs = 10,
        placement = ViewPlacement.ABOVE_NAME,
        belowTitle = "<white>AI</white>",
        fallbackProb = "--",
        fallbackBuffer = "--",
        probDecimals = 1,
        bufferDecimals = 1,
        prefixTemplate = "<white>{prob}</white>",
        suffixTemplate = "<white>{buffer}</white>",
        belowTemplate = "<white>{prob}</white>",
        defaultBelowText = "<white>--</white>",
        usesPing = false,
      )
  }
}
